delimiter //
Create Trigger insAlm After Insert On Almacen for each row
Begin
  Declare idCo int;
  Declare bool boolean Default False;
  Declare almC Cursor For Select idColor From colores;
  Declare Continue handler For Not Found Set bool=true;
  open almC;
  Fetch almC into idCo;
  While bool = false Do
    Insert Into almacenColor Values ('',new.codArticulo, idCo, 0);
	Fetch almC into idCo;
  End While;
  close almC;
End//



Create Trigger dropAlm After Update On Almacen for each row
Begin
  If new.borrado=true Then
    Delete From proveedorAlmacenWhere Where codArticulo=old.CodArticulo;
	Delete From almacenColor Where codArticulo=old.CodArticulo;
  End If;
End//



Create Trigger dropProv after update On proveedor for each row
Begin
  If new.borrado = true Then
    If old.tipoProveedor="Bordados" Then
      Delete From proveedorBordado Where codProveedor=old.codProveedor;
    Else
      Delete From proveedorAlmacen Where codProveedor=old.codProveedor;
    End If;
  End If;
End//



Create Trigger dropTal After update On talles for each row
Begin
  Declare aux int;
  Declare bool boolean Default False;
  Declare roTa cursor for select codRT from ropaTalles
    Where codTalle=old.codTalle;
  Declare Continue Handler For Not Found Set bool=true;
  open roTa;
  Fetch roTa into aux;
  While bool = false Do
    If new.borrado=true Then
	  Update ropaTalles Set borrado=true Where codRT=aux;
	  Update ropaTallesColor Set borrado=true Where codRT=aux;
	End If;
  Fetch roTa Into aux;
  End While;
  close roTa;
End//



Create Trigger dropRop After update On ropa for each row
Begin
  Declare aux int;
  Declare bool boolean Default False;
  Declare roTa cursor for select codRT from ropaTalles
    Where codRopa=old.codRopa;
  Declare Continue Handler For Not Found Set bool=true;
  open roTa;
  Fetch roTa into aux;
  While bool = false Do
    If new.borrado=true Then
	  Update ropaTalles Set borrado=true Where codRT=aux;
	  Update ropaTallesColor Set borrado=true Where codRT=aux;
	End If;
  Fetch roTa Into aux;
  End While;
  close roTa;
End//



Create Trigger insCol After Insert On colores for each row
Begin
  Declare codA int;
  Declare bool boolean Default False;
  Declare ColA Cursor For Select codArticulo From almacen;
  Declare Continue handler For Not Found Set bool=true;
  open ColA;
  Fetch ColA into codA;
  While bool = false Do
    Insert Into almacenColor Values ('',codA, new.idColor, 0);
	Fetch ColA into codA;
  End While;
  close ColA;
End//



Create Trigger dropCol After update On colores for each row
Begin
  If new.borrado=true Then
    Delete From almacenColor Where idColor=old.idColor;
	Update ropaTallesColor Set borrado=true Where idColor=old.idColor;
  End If;
End//
delimiter ;