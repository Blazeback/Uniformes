delimiter //
CREATE PROCEDURE tiempo2(np int)
BEGIN
	DECLARE codRTE int;
	DECLARE codRTCE int;
	DECLARE stock int;
	DECLARE tiempo1 time;
	DECLARE talle int;
	DECLARE npE int;
	DECLARE idNPE int;
	DECLARE cantidadE int;
	DECLARE articuloE varchar(255);
	DECLARE preciounitarioE int;
	DECLARE totalE int;
	DECLARE detalleE boolean;
	DECLARE bordadoE boolean;
	DECLARE idE int;
	DECLARE maxCPR int;
	DECLARE detallin int;
	DECLARE codPR int;
	
	DECLARE X boolean default false;
	DECLARE jaja CURSOR FOR SELECT* FROM NPDETALLE WHERE idNP=np;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET X=true;
	
	OPEN jaja;
	FETCH jaja INTO idE, idNPE, codRTCE, detallin;
	WHILE X=false DO
			SET codPR=(SELECT codPedidoRopa FROM pedidoropa WHERE numNotaPedido=np AND codRTC=codRTCE);
			INSERT INTO pedidoropadetalle VALUES('', codPR, detallin);
			FETCH jaja INTO idE, idNPE, codRTCE, detallin;
	END WHILE;
	CLOSE jaja;
END //
delimiter ;

delimiter //
CREATE PROCEDURE tiempo1(np int, tempo time)
BEGIN
	DECLARE codRTE int;
	DECLARE codRTCE int;
	DECLARE stock int;
	DECLARE tiempo1 time;
	DECLARE talle int;
	DECLARE npE int;
	DECLARE idNPE int;
	DECLARE cantidadE int;
	DECLARE articuloE varchar(255);
	DECLARE preciounitarioE int;
	DECLARE totalE int;
	DECLARE detalleE boolean;
	DECLARE bordadoE boolean;
	DECLARE idE int;
	
	DECLARE X boolean default false;
	DECLARE jaja CURSOR FOR SELECT* FROM NP WHERE idNP=np;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET X=true;
	OPEN jaja;
	FETCH jaja INTO idE, idNPE, codRTE, codRTCE, cantidadE, articuloE, preciounitarioE, totalE, detalleE, bordadoE;
		WHILE X=false DO
			SET stock=(SELECT stock FROM ropatallescolor WHERE codRTC=codRTCE);
			IF cantidadE<=stock THEN
				SET talle=(SELECT codTalle FROM ropatalles WHERE codRT=codRTE);
				SET tiempo1=(SELECT tiempo FROM talles WHERE codTalle=talle);
				UPDATE NPTOTAL
				SET tiempo=tiempo-tiempo1
				WHERE idNP=np;
				
				UPDATE ropatallescolor
				SET stock=stock-cantidadE
				WHERE codRTC=codRTCE;
			END IF;
			INSERT INTO pedidoropa VALUES('', codRTCE, np, cantidadE);
			IF detalleE=false OR bordadoE=0 THEN
				INSERT INTO CONFECCION VALUES('', idNPE,cantidadE, articuloE, 1);
			END IF;
			FETCH jaja INTO idE, idNPE, codRTE, codRTCe, cantidadE, articuloE, preciounitarioE, totalE, detalleE, bordadoE;
		END WHILE;
	CLOSE jaja;
END //
delimiter ;

delimiter //
CREATE PROCEDURE contador(IN c int, IN n int)
BEGIN
	DECLARE i int;
	
	DECLARE X boolean default false;
	DECLARE jaja CURSOR FOR SELECT id FROM (SELECT* FROM NP ORDER BY id DESC LIMIT c) XD ORDER BY id ASC;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET X=true;
	OPEN jaja;
	FETCH jaja INTO i;
		WHILE X=false DO
			DELETE FROM NPTOTAL WHERE idNP=n AND id=i;
			DELETE FROM NPDETALLE WHERE idNP=n AND id=i;
			FETCH jaja INTO i;
		END WHILE;
	CLOSE jaja;
END //
delimiter ;

delimiter //
CREATE PROCEDURE cuotas(c int, f int, p int)
BEGIN
	DECLARE i int;
	DECLARE fecha date;
	DECLARE valorcuota int;
	DECLARE contador int;
	
	SET i=0;
	SET fecha=(SELECT curdate());
	SET valorcuota=(p/c);
	SET contador=0;
	
	REPEAT
	SET i=i+1;
	SET fecha=(SELECT DATE_ADD(curdate(),INTERVAL 1 MONTH));
	INSERT INTO cuotas VALUES('', i, f, fecha, null, valorcuota);
	SET contador=contador+1;
	UNTIL contador=c+1
	END REPEAT;
END //
delimiter ;