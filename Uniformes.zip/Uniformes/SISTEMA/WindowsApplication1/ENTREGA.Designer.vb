﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ENTREGA
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.btn2V = New System.Windows.Forms.Button()
        Me.btnFinENT = New System.Windows.Forms.Button()
        Me.fechaENT = New System.Windows.Forms.Label()
        Me.lbl1ENT = New System.Windows.Forms.Label()
        Me.grdENT = New System.Windows.Forms.DataGridView()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.mskENT = New System.Windows.Forms.MaskedTextBox()
        Me.btnVALIDARENT = New System.Windows.Forms.Button()
        CType(Me.grdENT, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(6, 5)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(444, 293)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(455, 304)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'btn2V
        '
        Me.btn2V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2V.Location = New System.Drawing.Point(131, 252)
        Me.btn2V.Name = "btn2V"
        Me.btn2V.Size = New System.Drawing.Size(155, 39)
        Me.btn2V.TabIndex = 89
        Me.btn2V.Text = "Cancelar"
        Me.btn2V.UseVisualStyleBackColor = True
        '
        'btnFinENT
        '
        Me.btnFinENT.Enabled = False
        Me.btnFinENT.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnFinENT.Location = New System.Drawing.Point(131, 182)
        Me.btnFinENT.Name = "btnFinENT"
        Me.btnFinENT.Size = New System.Drawing.Size(155, 64)
        Me.btnFinENT.TabIndex = 88
        Me.btnFinENT.Text = "Satisfacer pedido y ver documentos"
        Me.btnFinENT.UseVisualStyleBackColor = True
        '
        'fechaENT
        '
        Me.fechaENT.AutoSize = True
        Me.fechaENT.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fechaENT.Location = New System.Drawing.Point(12, 9)
        Me.fechaENT.Name = "fechaENT"
        Me.fechaENT.Size = New System.Drawing.Size(21, 25)
        Me.fechaENT.TabIndex = 87
        Me.fechaENT.Text = "-"
        '
        'lbl1ENT
        '
        Me.lbl1ENT.AutoSize = True
        Me.lbl1ENT.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1ENT.Location = New System.Drawing.Point(106, 9)
        Me.lbl1ENT.Name = "lbl1ENT"
        Me.lbl1ENT.Size = New System.Drawing.Size(237, 25)
        Me.lbl1ENT.TabIndex = 84
        Me.lbl1ENT.Text = "ENTREGA DEL PRODUCTO"
        '
        'grdENT
        '
        Me.grdENT.AllowUserToAddRows = False
        Me.grdENT.AllowUserToDeleteRows = False
        Me.grdENT.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdENT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdENT.Location = New System.Drawing.Point(17, 37)
        Me.grdENT.Name = "grdENT"
        Me.grdENT.ReadOnly = True
        Me.grdENT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdENT.Size = New System.Drawing.Size(426, 91)
        Me.grdENT.TabIndex = 83
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(61, 137)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(140, 23)
        Me.Label1.TabIndex = 91
        Me.Label1.Text = "Código de pedido"
        '
        'mskENT
        '
        Me.mskENT.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.mskENT.Location = New System.Drawing.Point(208, 134)
        Me.mskENT.Mask = "99999"
        Me.mskENT.Name = "mskENT"
        Me.mskENT.Size = New System.Drawing.Size(63, 31)
        Me.mskENT.TabIndex = 90
        Me.mskENT.ValidatingType = GetType(Integer)
        '
        'btnVALIDARENT
        '
        Me.btnVALIDARENT.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnVALIDARENT.Location = New System.Drawing.Point(277, 134)
        Me.btnVALIDARENT.Name = "btnVALIDARENT"
        Me.btnVALIDARENT.Size = New System.Drawing.Size(88, 31)
        Me.btnVALIDARENT.TabIndex = 92
        Me.btnVALIDARENT.Text = "VALIDAR"
        Me.btnVALIDARENT.UseVisualStyleBackColor = True
        '
        'ENTREGA
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(455, 304)
        Me.Controls.Add(Me.btnVALIDARENT)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.mskENT)
        Me.Controls.Add(Me.btn2V)
        Me.Controls.Add(Me.btnFinENT)
        Me.Controls.Add(Me.fechaENT)
        Me.Controls.Add(Me.lbl1ENT)
        Me.Controls.Add(Me.grdENT)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "ENTREGA"
        Me.Text = "ENTREGA"
        CType(Me.grdENT, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents btn2V As System.Windows.Forms.Button
    Friend WithEvents btnFinENT As System.Windows.Forms.Button
    Friend WithEvents fechaENT As System.Windows.Forms.Label
    Friend WithEvents lbl1ENT As System.Windows.Forms.Label
    Friend WithEvents grdENT As System.Windows.Forms.DataGridView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents mskENT As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btnVALIDARENT As System.Windows.Forms.Button
End Class
