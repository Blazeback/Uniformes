﻿Imports System.Data.Odbc
Public Class Precios

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        Me.Hide()
        Control.Show()
        cmb1.Items.Clear()
        cmb3.Items.Clear()
        cmb4.Items.Clear()
        cmb5.Items.Clear()
        msk1.Clear()
        msk2.Clear()
    End Sub

    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click

        If cmb1.Text = "" Or cmb3.Text = "" Or msk1.Text = "" Then
            MsgBox("Faltan ingresar datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            sql = "Select codRT from ropaTalles RT, ropa R, talles T Where RT.codRopa=R.codRopa and RT.codTalle=T.codTalle and R.nombre='" & cmb1.Text & "' and T.talle='" & cmb3.Text & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                sql = "Update ropaTalles Set precio=" & Trim(msk1.Text) & " Where codRT=" & rs(0)
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
            Else
                sql = "Insert into ropaTalles Values ('', " & cmb1.Text & ", " & cmb3.Text & ", null, null, false"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
            End If
            MsgBox("La operacion a sido realizada exitosamente", MsgBoxStyle.Exclamation, "EXITO")
        End If
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call conexion()
        sql = "select nombre from ropa where borrado= false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb1.Items.Add(rs(0))
        End While
        sql = "Select talle from talles where borrado= false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb3.Items.Add(rs(0))
        End While
        sql = "Select nombre from almacen where borrado= false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb4.Items.Add(rs(0))
        End While
        sql = "Select nombre from proveedor where borrado=false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb5.Items.Add(rs(0))
        End While
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        Dim codP As Integer
        Dim codA As Integer
        If cmb4.Text = "" Or cmb5.Text = "" Or msk2.Text = "" Then
            MsgBox("Faltan ingresar datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            sql = "Select codProveedor from proveedor where nombre='" & cmb5.Text & "' and tipoProveedor='Materiales'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                codP = rs(0)
            End If
            sql = "Select codArticulo from Almacen Where nombre='" & cmb4.Text & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                codA = rs(0)
            End If
                sql = "Select precio from proveedorAlmacen where codProveedor=" & codP & " and codArticulo=" & codA
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    sql = "update proveedorAlmacen Set precio=" & Trim(msk2.Text) & "Where codArticulo=" & codA & "and codProveedor = " & codP
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    MsgBox("La operacion a sido realizada exitosamente", MsgBoxStyle.Exclamation, "EXITO")
                Else
                    MsgBox("La operacion no se pudo realizar debido a que el proveedor no suministra ese articulo", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
    End Sub
End Class