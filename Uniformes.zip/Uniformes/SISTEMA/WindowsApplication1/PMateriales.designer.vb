﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PMateriales
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        Me.SuspendLayout()
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(218, 19)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(89, 32)
        Me.btn2.TabIndex = 0
        Me.btn2.Text = "Finalizar"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn3.Location = New System.Drawing.Point(218, 95)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(89, 32)
        Me.btn3.TabIndex = 1
        Me.btn3.Text = "Volver"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(218, 57)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(89, 32)
        Me.btn1.TabIndex = 2
        Me.btn1.Text = "Ingresar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1.Location = New System.Drawing.Point(12, 9)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(173, 23)
        Me.lbl1.TabIndex = 3
        Me.lbl1.Text = "Seleccione el articulo"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(12, 71)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(139, 23)
        Me.lbl2.TabIndex = 4
        Me.lbl2.Text = "Ingrese el precio"
        '
        'cmb1
        '
        Me.cmb1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Location = New System.Drawing.Point(16, 36)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(121, 31)
        Me.cmb1.TabIndex = 5
        '
        'msk1
        '
        Me.msk1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(16, 98)
        Me.msk1.Mask = "0000000"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(75, 31)
        Me.msk1.TabIndex = 6
        '
        'PMateriales
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(318, 134)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.cmb1)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Name = "PMateriales"
        Me.Text = "MATERIALES"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents cmb1 As System.Windows.Forms.ComboBox
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btn3 As System.Windows.Forms.Button
End Class
