﻿Imports System.Data.Odbc
Imports System.Globalization

Public Class Ventas4
    Dim b As Integer
    Dim num As Integer
    Dim bseña As Integer
    Dim tiempo As Date
    Dim contfor As Integer
    Dim facturita As Integer

    Private Sub btn1V4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1V4.Click
        b = 0
        bseña = 0
        If rb1V4.Checked = False And rb2V4.Checked = False Then
            b = 1
        End If

        If rb1V4.Checked = True And msk1V4.Text = "" Then
            b = 1
        End If

        If rb2V4.Checked = True Then
            num = 0
            bseña = 0
        Else
            num = CInt(msk1V4.Text)
        End If

        If num < (preciototal * 0.3) Then
            bseña = 1
        Else
            b = 0
        End If

        If rb2V4.Checked = True Then
            num = 0
            bseña = 0
        End If

        If b = 0 Then
            If bseña = 0 Then
                If banderadni = 1 Then
                    sql = "Insert Into cliente Values ('" & codigoxd & "', '" & Trim(Ventas.msk2V1.Text) & "', '" & Trim(Ventas.msk3V1.Text) & "', '" & Ventas.msk4V1.Text & "', '" & Trim(Ventas.msk1V1.Text) & "', '" & Trim(Ventas.msk5V1.Text) & "', '" & Ventas.cbm3V.Text & "', '" & Ventas.cbm4V.Text & "', '" & Trim(Ventas.msk9V1.Text) & "', null)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    sql = "UPDATE cliente SET borrado=0 WHERE codCliente='" & codigoxd & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    Ventas.msk1V1.Text = ""
                    Ventas.msk2V1.Text = ""
                    Ventas.msk3V1.Text = ""
                    Ventas.msk4V1.Text = ""
                    Ventas.msk5V1.Text = ""
                    Ventas.cbm3V.Text = ""
                    Ventas.cbm4V.Text = ""
                    Ventas.lbl9V1.Text = ""
                    Ventas.cbm1V.SelectedIndex = -1
                    Ventas.cbm2V.SelectedIndex = -1
                    Ventas.panel1V.Visible = False
                    Ventas.rb1V.Checked = False
                    Ventas.rb2V.Checked = False
                    Ventas.rb3V.Checked = False
                End If

                banderacompra = 0
                banderaconfeccion = 0

                sql = "select curdate()"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    NotaPedido.FechaNP.Text = rs(0)
                End If

                NotaPedido.CodigoNP.Text = codigoxd
                FacturaCliente.CodClienteFactura.Text = codigoxd

                sql = "SELECT nombre, apellido FROM cliente WHERE codCliente='" & codigoxd & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    NotaPedido.NombreApellidoNP.Text = rs(1)
                    FacturaCliente.NombreFactura.Text = rs(1)
                End If

                sql = "SELECT direccion FROM cliente WHERE codCliente='" & codigoxd & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    NotaPedido.DireccionNP.Text = rs(0)
                    FacturaCliente.DirFactura.Text = rs(0)
                End If

                sql = "SELECT telefono FROM cliente WHERE codCliente='" & codigoxd & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    NotaPedido.TelNP.Text = rs(0)
                End If

                If msk1V4.Text <> "" Then
                    NotaPedido.SeñaNP.Text = msk1V4.Text
                End If

                NotaPedido.CodigoNPNP.Text = npglobal
                sql = "SELECT totaltotal FROM NPTOTAL WHERE idNP='" & npglobal & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    NotaPedido.TotalNP.Text = rs(0)
                End If

                sql = "INSERT INTO notapedido VALUES('" & npglobal & "', curdate(), null, 0)"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                sql = "CALL tiempo1('" & npglobal & "', '" & tiempocam & "')"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()

                sql = "SELECT DATE(ADDTIME(curdate(), TIME((SELECT tiempo FROM NPTOTAL WHERE idNP='" & npglobal & "'LIMIT 1)))) LIMIT 1"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    fechaentregaglobal = rs(0)
                End If

                MsgBox("El pedido se concretará dentro de " & tiempocam & " horas y en la fecha " & fechaentregaglobal & ".")
                sql = "UPDATE notapedido SET fechaEntrega='" & fechaentregaglobal & "' WHERE numNotaPedido='" & npglobal & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                NotaPedido.FechaEntregaNP.Text = fechaentregaglobal
                sql = "CALL tiempo2('" & npglobal & "')"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                sql = "SELECT CONCAT(nombre, ' ', apellido,' con DNI ', dni) FROM cliente WHERE codCliente='" & codigoxd & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    Principal.lst1P.Items.Add("Pedido del cliente " & rs(0) & " activo.")
                End If


                If banderabordado = 1 Then
                    MsgBox("El cliente debe mandar la imagen que desea para su bordado al mail sarmientouniformes@gmail.com.", MsgBoxStyle.Exclamation, "ADVERTENCIA")
                End If

                '_______________________________________________________________________________________________
                sql = "SELECT MAX(numFactura+1) FROM factura"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rb1V4.Checked = True Then
                        sql = "INSERT INTO factura VALUES ('" & rs(0) & "', '" & codigoxd & "', '" & npglobal & "', curdate(), '" & preciototal & "', '" & formapago & "', true, '" & msk1V4.Text & "')"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        FacturaCliente.SeñaFactura.Text = msk1V4.Text
                    End If
                    If rb2V4.Checked = True Then
                        sql = "INSERT INTO factura VALUES ('" & rs(0) & "', '" & codigoxd & "', '" & npglobal & "', curdate(), '" & preciototal & "', '" & formapago & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        FacturaCliente.SeñaFactura.Text = "0"
                    End If
                End If
                sql = "SELECT MAX(numFactura) FROM factura"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    FacturaCliente.NumFactura.Text = rs(0)
                    facturita = rs(0)
                End If
                
                sql = "SELECT curdate()"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    FacturaCliente.FechaFactura.Text = rs(0)
                End If
                FacturaCliente.lblCuotasFactura.Text = cuotas
                FacturaCliente.lblFormaPagoFactura.Text = formapago
                FacturaCliente.TotalFactura.Text = preciototal
                FacturaCliente.NPFactura.Text = npglobal
                FacturaCliente.lblFormaPagoFactura.Text = formapago
                FacturaCliente.lblCuotasFactura.Text = cuotas
                sql = "SELECT localidad FROM cliente WHERE codCliente='" & codigoxd & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    FacturaCliente.LocalidadFactura.Text = rs(0)
                End If
                sql = "SELECT provincia FROM cliente WHERE codCliente='" & codigoxd & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    FacturaCliente.ProvinciaFactura.Text = rs(0)
                End If


                If cuotas = 3 Then
                    sql = "CALL cuotas(3, '" & facturita & "', '" & preciototal & "')"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If cuotas = 6 Then
                        sql = "CALL cuotas(6, '" & facturita & "', '" & preciototal & "')"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If CInt(cuotas) = 12 Then
                            sql = "CALL cuotas(12, '" & facturita & "', '" & preciototal & "')"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If
                End If

                banderaconfeccion = 0
                sql = "SELECT COUNT(*) FROM pedidoropa WHERE numNotaPedido='" & npglobal & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        banderaconfeccion = 1
                        sql = "SELECT MAX(id) FROM CONFECCION"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            Try
                                OrdenConfeccion.lblCodOrdConf.Text = rs(0)
                            Catch ex As Exception
                                OrdenConfeccion.lblCodOrdConf.Text = "0"
                            End Try
                            'Principal.lst1P.Items.Add("Orden de confección (nota de pedido " & npglobal & ") activa.")
                        End If
                    End If
                End If

                sql = "SELECT COUNT(*) FROM NP WHERE bordado=1"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    banderacompra = 1
                End If

                sql = "DELETE FROM NPDETALLE"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                sql = "DELETE FROM NPTOTAL"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                Me.Close()
                NotaPedido.Show()
            Else
                MsgBox("La seña no cumple con el monto mínimo.", MsgBoxStyle.Exclamation, "ERROR")
            End If
        Else
            MsgBox("Usted ha dejado campos sin completar.", MsgBoxStyle.Exclamation, "ERROR")
        End If
    End Sub

    Private Sub btnCancelarV4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarV4.Click
        rb1V4.Checked = False
        rb2V4.Checked = False
        grb1V4.Visible = False
        msk1V4.Text = ""
    End Sub

    Private Sub rb1V4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If rb1V4.Checked = True Then
            msk1V4.Enabled = True
            grb1V4.Visible = True
        End If
    End Sub

    Private Sub rb2V4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        If rb2V4.Checked = True Then
            msk1V4.Enabled = False
            grb1V4.Visible = False
            msk1V4.Text = ""
        End If
    End Sub

    Private Sub rb2V4_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2V4.CheckedChanged
        If rb2V4.Checked = True Then
            grb1V4.Visible = False
            msk1V4.Text = ""
        End If
    End Sub

    Private Sub rb1V4_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1V4.CheckedChanged
        If rb1V4.Checked = True Then
            grb1V4.Visible = True
        End If
    End Sub

    Private Sub Ventas4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        precioV4.Text = preciototal
        minimoV4.Text = preciototal * 0.3
    End Sub
End Class