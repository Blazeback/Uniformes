﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ElimCliente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl4EUser = New System.Windows.Forms.Label()
        Me.lbl3EUser = New System.Windows.Forms.Label()
        Me.lbl1EUser = New System.Windows.Forms.Label()
        Me.btnCancelarEC = New System.Windows.Forms.Button()
        Me.btnEliminarCli = New System.Windows.Forms.Button()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.msk1VElC = New System.Windows.Forms.MaskedTextBox()
        Me.msk2VElC = New System.Windows.Forms.MaskedTextBox()
        Me.msk3VElC = New System.Windows.Forms.MaskedTextBox()
        Me.SuspendLayout()
        '
        'lbl4EUser
        '
        Me.lbl4EUser.AutoSize = True
        Me.lbl4EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4EUser.Location = New System.Drawing.Point(12, 140)
        Me.lbl4EUser.Name = "lbl4EUser"
        Me.lbl4EUser.Size = New System.Drawing.Size(34, 23)
        Me.lbl4EUser.TabIndex = 47
        Me.lbl4EUser.Text = "DNI"
        '
        'lbl3EUser
        '
        Me.lbl3EUser.AutoSize = True
        Me.lbl3EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3EUser.Location = New System.Drawing.Point(12, 79)
        Me.lbl3EUser.Name = "lbl3EUser"
        Me.lbl3EUser.Size = New System.Drawing.Size(71, 23)
        Me.lbl3EUser.TabIndex = 45
        Me.lbl3EUser.Text = "Apellido"
        '
        'lbl1EUser
        '
        Me.lbl1EUser.AutoSize = True
        Me.lbl1EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1EUser.Location = New System.Drawing.Point(12, 9)
        Me.lbl1EUser.Name = "lbl1EUser"
        Me.lbl1EUser.Size = New System.Drawing.Size(152, 23)
        Me.lbl1EUser.TabIndex = 41
        Me.lbl1EUser.Text = "Nombre del cliente"
        '
        'btnCancelarEC
        '
        Me.btnCancelarEC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelarEC.Location = New System.Drawing.Point(143, 213)
        Me.btnCancelarEC.Name = "btnCancelarEC"
        Me.btnCancelarEC.Size = New System.Drawing.Size(97, 39)
        Me.btnCancelarEC.TabIndex = 40
        Me.btnCancelarEC.Text = "Cancelar"
        Me.btnCancelarEC.UseVisualStyleBackColor = True
        '
        'btnEliminarCli
        '
        Me.btnEliminarCli.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminarCli.Location = New System.Drawing.Point(31, 213)
        Me.btnEliminarCli.Name = "btnEliminarCli"
        Me.btnEliminarCli.Size = New System.Drawing.Size(97, 39)
        Me.btnEliminarCli.TabIndex = 39
        Me.btnEliminarCli.Text = "Eliminar"
        Me.btnEliminarCli.UseVisualStyleBackColor = True
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(8, 4)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(258, 256)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(273, 267)
        Me.ShapeContainer1.TabIndex = 49
        Me.ShapeContainer1.TabStop = False
        '
        'msk1VElC
        '
        Me.msk1VElC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1VElC.Location = New System.Drawing.Point(16, 35)
        Me.msk1VElC.Mask = "LLLLLLLLLL"
        Me.msk1VElC.Name = "msk1VElC"
        Me.msk1VElC.Size = New System.Drawing.Size(122, 31)
        Me.msk1VElC.TabIndex = 50
        '
        'msk2VElC
        '
        Me.msk2VElC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2VElC.Location = New System.Drawing.Point(16, 106)
        Me.msk2VElC.Mask = "LLLLLLLLLL"
        Me.msk2VElC.Name = "msk2VElC"
        Me.msk2VElC.Size = New System.Drawing.Size(122, 31)
        Me.msk2VElC.TabIndex = 51
        '
        'msk3VElC
        '
        Me.msk3VElC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk3VElC.Location = New System.Drawing.Point(16, 166)
        Me.msk3VElC.Mask = "LLLLLLLLLL"
        Me.msk3VElC.Name = "msk3VElC"
        Me.msk3VElC.Size = New System.Drawing.Size(122, 31)
        Me.msk3VElC.TabIndex = 52
        '
        'ElimCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(273, 267)
        Me.Controls.Add(Me.msk3VElC)
        Me.Controls.Add(Me.msk2VElC)
        Me.Controls.Add(Me.msk1VElC)
        Me.Controls.Add(Me.lbl4EUser)
        Me.Controls.Add(Me.lbl3EUser)
        Me.Controls.Add(Me.lbl1EUser)
        Me.Controls.Add(Me.btnCancelarEC)
        Me.Controls.Add(Me.btnEliminarCli)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "ElimCliente"
        Me.Text = "ELIMINAR CLIENTE"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl4EUser As System.Windows.Forms.Label
    Friend WithEvents lbl3EUser As System.Windows.Forms.Label
    Friend WithEvents lbl1EUser As System.Windows.Forms.Label
    Friend WithEvents btnCancelarEC As System.Windows.Forms.Button
    Friend WithEvents btnEliminarCli As System.Windows.Forms.Button
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents msk1VElC As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2VElC As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk3VElC As System.Windows.Forms.MaskedTextBox
End Class
