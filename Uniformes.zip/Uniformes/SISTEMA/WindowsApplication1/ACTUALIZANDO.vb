﻿Public Class ACTUALIZANDO

    Private Sub ACTUALIZANDO_Activated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Activated
        Me.Close()
        Principal.Show()
    End Sub
End Class