﻿Imports System.Data.Odbc

Public Class Control
    Dim cont As Integer
    Dim errorcito As Integer

    Private Sub btnSalirC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirC.Click
        If cont > 0 Then
            Try
                grd1C.DataSource.clear()
            Catch ex As Exception
                Me.Hide()
                Principal.Show()
            End Try

        End If
        cbm1C.SelectedIndex = -1
        cont = 0
        errorcito = 0
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        btn16C.Visible = False
        btn19C.Visible = False
        Me.Close()
        Principal.Show()
    End Sub

    Private Sub btn2C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2C.Click
        btn3C.Visible = True
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        btn16C.Visible = False
        btn19C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM usuario"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT* FROM usuario"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Usuarios"))
                    Me.grd1C.DataSource = ds.Tables("Usuarios")
                Else
                    MsgBox("No hay usuarios.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM usuario"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT* FROM usuario"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Usuarios"))
                    Me.grd1C.DataSource = ds.Tables("Usuarios")
                Else
                    MsgBox("No hay usuarios.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub Control_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Tables.Add("Usuarios")
        ds.Tables.Add("Clientes")
        ds.Tables.Add("RopaTalleColor")
        ds.Tables.Add("Color")
        ds.Tables.Add("Talle")
        ds.Tables.Add("Ropa")
        ds.Tables.Add("Detalle")
        ds.Tables.Add("Factura")
        ds.Tables.Add("Confeccion")
        ds.Tables.Add("RemitoC")
        ds.Tables.Add("RemitoP")
        ds.Tables.Add("OrdCompraBord")
        ds.Tables.Add("OrdCompraMP")
        ds.Tables.Add("NotaPedido")
        ds.Tables.Add("Proveedor")
        ds.Tables.Add("Bordados")
        cont = 0
        errorcito = 0
    End Sub

    Private Sub btn3C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3C.Click
        If cont > 0 Then
            grd1C.DataSource.clear()
        End If
        cbm1C.SelectedIndex = -1
        cont = 0
        errorcito = 0
        Me.Hide()
        AgregElimUser.Show()
    End Sub

    Private Sub btn1C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1C.Click
        btn3C.Visible = False
        btn11C.Visible = True
        btn12C.Visible = False
        btn13C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        btn16C.Visible = False
        btn19C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM cliente WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT codCliente, nombre, apellido, telefono, DNI, direccion, localidad, provincia, codPostal FROM cliente WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Clientes"))
                    Me.grd1C.DataSource = ds.Tables("Clientes")
                Else
                    MsgBox("No hay clientes.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM cliente WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT codCliente, nombre, apellido, telefono, DNI, direccion, localidad, provincia, codPostal FROM cliente WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Clientes"))
                    Me.grd1C.DataSource = ds.Tables("Clientes")
                Else
                    MsgBox("No hay clientes.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub
    
    Private Sub btn8C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn8C.Click
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        btn16C.Visible = False
        btn19C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM ropaTallesColor"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select R.nombre Prenda, C.nombre Color, T.talle Talle, RTC.stock Stock, RT.precio Precio From ropaTallesColor RTC, ropaTalles RT, talles T, ropa R, colores C Where(R.codRopa = RT.codRopa And T.codTalle = RT.codTalle) and C.idColor=RTC.idColor and RTC.codRT=RT.codRT"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("RopaTalleColor"))
                    Me.grd1C.DataSource = ds.Tables("RopaTalleColor")
                Else
                    MsgBox("No hay clientes.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM ropaTallesColor"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select R.nombre Prenda, C.nombre Color, T.talle Talle, RTC.stock Stock, RT.precio Precio From ropaTallesColor RTC, ropaTalles RT, talles T, ropa R, colores C Where(R.codRopa = RT.codRopa And T.codTalle = RT.codTalle) and C.idColor=RTC.idColor and RTC.codRT=RT.codRT"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("RopaTalleColor"))
                    Me.grd1C.DataSource = ds.Tables("RopaTalleColor")
                Else
                    MsgBox("No hay clientes.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub btn6C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn6C.Click
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn14C.Visible = True
        btn15C.Visible = False
        btn16C.Visible = False
        btn19C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM detalle WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select nombre Nombre FROM detalle WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Detalle"))
                    Me.grd1C.DataSource = ds.Tables("Detalle")
                Else
                    MsgBox("No hay detalles.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM detalle WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select nombre Nombre FROM detalle WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Detalle"))
                    Me.grd1C.DataSource = ds.Tables("Detalle")
                Else
                    MsgBox("No hay detalles.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub btn7C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn7C.Click
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = True
        btn16C.Visible = False
        btn19C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM colores WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select nombre Nombre FROM detalle WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Color"))
                    Me.grd1C.DataSource = ds.Tables("Color")
                Else
                    MsgBox("No hay colores.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM colores WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select nombre Nombre FROM colores WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Color"))
                    Me.grd1C.DataSource = ds.Tables("Color")
                Else
                    MsgBox("No hay colores.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub btn5C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn5C.Click
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = True
        btn14C.Visible = False
        btn19C.Visible = False
        btn15C.Visible = False
        btn16C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM talles WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select talle Talle FROM talles WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Talle"))
                    Me.grd1C.DataSource = ds.Tables("Talle")
                Else
                    MsgBox("No hay talles.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM talles WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select talle Talle FROM talles WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Talle"))
                    Me.grd1C.DataSource = ds.Tables("Talle")
                Else
                    MsgBox("No hay talles.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub btn4C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4C.Click
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn19C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        btn16C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM ropa WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select nombre Nombre FROM ropa WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Ropa"))
                    Me.grd1C.DataSource = ds.Tables("Ropa")
                Else
                    MsgBox("No hay tipos de ropa.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM ropa WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Select nombre Nombre FROM ropa WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Ropa"))
                    Me.grd1C.DataSource = ds.Tables("Ropa")
                Else
                    MsgBox("No hay tipos de ropa.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub cbm1C_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbm1C.SelectedIndexChanged
        If cbm1C.Text = "Facturas" Then
            btn3C.Visible = False
            btn11C.Visible = False
            btn12C.Visible = False
            btn13C.Visible = False
            btn19C.Visible = False
            btn14C.Visible = False
            btn15C.Visible = False
            btn16C.Visible = False
            If cont = 0 Then
                sql = "SELECT COUNT(*) FROM factura"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM factura"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("Factura"))
                        Me.grd1C.DataSource = ds.Tables("Factura")
                    Else
                        MsgBox("No hay facturas.", MsgBoxStyle.Exclamation, "ERROR")
                        errorcito = 1
                    End If
                End If
                cont = 1
            Else
                If errorcito = 0 Then
                    grd1C.DataSource.clear()
                End If
                sql = "SELECT COUNT(*) FROM factura"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM factura"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("Factura"))
                        Me.grd1C.DataSource = ds.Tables("Factura")
                    Else
                        MsgBox("No hay facturas.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            End If
        End If

        If cbm1C.Text = "Órdenes de compra" Then
            btn3C.Visible = False
            btn11C.Visible = False
            btn12C.Visible = False
            btn13C.Visible = False
            btn19C.Visible = False
            btn14C.Visible = False
            btn15C.Visible = False
            btn16C.Visible = False
            If cont = 0 Then
                sql = "SELECT COUNT(*) FROM ordenCompra"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM ordenCompra"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("OrdCompraMP"))
                        Me.grd1C.DataSource = ds.Tables("OrdCompraMP")
                    Else
                        MsgBox("No hay órdenes de compra.", MsgBoxStyle.Exclamation, "ERROR")
                        errorcito = 1
                    End If
                End If
                cont = 1
            Else
                If errorcito = 0 Then
                    grd1C.DataSource.clear()
                End If
                sql = "SELECT COUNT(*) FROM ordenCompra"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM ordenCompra"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("OrdCompraMP"))
                        Me.grd1C.DataSource = ds.Tables("OrdCompraMP")
                    Else
                        MsgBox("No hay órdenes de compra.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            End If
        End If


        If cbm1C.Text = "Remitos cliente" Then
            btn3C.Visible = False
            btn11C.Visible = False
            btn12C.Visible = False
            btn19C.Visible = False
            btn13C.Visible = False
            btn14C.Visible = False
            btn15C.Visible = False
            btn16C.Visible = False
            If cont = 0 Then
                sql = "SELECT COUNT(*) FROM remitocliente"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM remitocliente"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("RemitoC"))
                        Me.grd1C.DataSource = ds.Tables("RemitoC")
                    Else
                        MsgBox("No hay remitos de cliente.", MsgBoxStyle.Exclamation, "ERROR")
                        errorcito = 1
                    End If
                End If
                cont = 1
            Else
                If errorcito = 0 Then
                    grd1C.DataSource.clear()
                End If
                sql = "SELECT COUNT(*) FROM remitocliente"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM remitocliente"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("RemitoC"))
                        Me.grd1C.DataSource = ds.Tables("RemitoC")
                    Else
                        MsgBox("No remitos de cliente.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            End If
        End If

        If cbm1C.Text = "Remitos prov." Then
            btn3C.Visible = False
            btn11C.Visible = False
            btn12C.Visible = False
            btn13C.Visible = False
            btn19C.Visible = False
            btn14C.Visible = False
            btn15C.Visible = False
            btn16C.Visible = False
            If cont = 0 Then
                sql = "SELECT COUNT(*) FROM remitoproveedor"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM remitoproveedor"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("RemitoP"))
                        Me.grd1C.DataSource = ds.Tables("RemitoP")
                    Else
                        MsgBox("No hay remitos de proveedor.", MsgBoxStyle.Exclamation, "ERROR")
                        errorcito = 1
                    End If
                End If
                cont = 1
            Else
                If errorcito = 0 Then
                    grd1C.DataSource.clear()
                End If
                sql = "SELECT COUNT(*) FROM remitoproveedor"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM remitoproveedor"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("RemitoP"))
                        Me.grd1C.DataSource = ds.Tables("RemitoP")
                    Else
                        MsgBox("No remitos de proveedor.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            End If
        End If

        If cbm1C.Text = "Órdenes confección" Then
            btn3C.Visible = False
            btn11C.Visible = False
            btn12C.Visible = False
            btn19C.Visible = False
            btn13C.Visible = False
            btn14C.Visible = False
            btn15C.Visible = False
            btn16C.Visible = False
            If cont = 0 Then
                sql = "SELECT COUNT(*) FROM CONFECCION"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM CONFECCION"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("Confeccion"))
                        Me.grd1C.DataSource = ds.Tables("Confeccion")
                    Else
                        MsgBox("No hay órdenes de confección.", MsgBoxStyle.Exclamation, "ERROR")
                        errorcito = 1
                    End If
                End If
                cont = 1
            Else
                If errorcito = 0 Then
                    grd1C.DataSource.clear()
                End If
                sql = "SELECT COUNT(*) FROM CONFECCION"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT* FROM CONFECCION"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("Confeccion"))
                        Me.grd1C.DataSource = ds.Tables("Confeccion")
                    Else
                        MsgBox("No hay órdenes de confección.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            End If
        End If

        If cbm1C.Text = "Notas de pedido" Then
            btn3C.Visible = False
            btn11C.Visible = False
            btn12C.Visible = False
            btn19C.Visible = False
            btn13C.Visible = False
            btn14C.Visible = False
            btn15C.Visible = False
            btn16C.Visible = False
            If cont = 0 Then
                sql = "SELECT COUNT(*) FROM notapedido"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT C.nombre, C.apellido, C.DNI, F.numNotaPedido, NP.fechaEntrega, NP.finalizado, PR.cantidad, D.nombre, R.nombre, T.talle, CL.nombre FROM cliente C, factura F, notapedido NP, pedidoropa PR, pedidoropadetalle PRD, detalle D, ropatallescolor RTC, colores CL, ropatalles RT, ropa R, talles T WHERE NP.numNotaPedido=F.numNotaPedido AND F.codCliente=C.codCliente AND NP.numNotaPedido=PR.numNotaPedido AND PR.codPedidoRopa=PRD.codPedidoRopa  AND PRD.codDetalle=D.codDetalle AND PR.codRTC=RTC.codRTC AND RTC.idColor=CL.idColor AND RTC.codRT=RT.codRT AND RT.codRopa=R.codRopa AND RT.codTalle=T.codTalle"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("NotaPedido"))
                        Me.grd1C.DataSource = ds.Tables("NotaPedido")
                    Else
                        MsgBox("No hay notas de pedido.", MsgBoxStyle.Exclamation, "ERROR")
                        errorcito = 1
                    End If
                End If
                cont = 1
            Else
                If errorcito = 0 Then
                    grd1C.DataSource.clear()
                End If
                sql = "SELECT COUNT(*) FROM notapedido"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        sql = "SELECT C.nombre, C.apellido, C.DNI, F.numNotaPedido, NP.fechaEntrega, NP.finalizado, PR.cantidad, D.nombre, R.nombre, T.talle, CL.nombre FROM cliente C, factura F, notapedido NP, pedidoropa PR, pedidoropadetalle PRD, detalle D, ropatallescolor RTC, colores CL, ropatalles RT, ropa R, talles T WHERE NP.numNotaPedido=F.numNotaPedido AND F.codCliente=C.codCliente AND NP.numNotaPedido=PR.numNotaPedido AND PR.codPedidoRopa=PRD.codPedidoRopa  AND PRD.codDetalle=D.codDetalle AND PR.codRTC=RTC.codRTC AND RTC.idColor=CL.idColor AND RTC.codRT=RT.codRT AND RT.codRopa=R.codRopa AND RT.codTalle=T.codTalle"
                        adp = New OdbcDataAdapter(sql, cnn)
                        adp.Fill(ds.Tables("NotaPedido"))
                        Me.grd1C.DataSource = ds.Tables("NotaPedido")
                    Else
                        MsgBox("No hay notas de pedido.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btn10C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn10C.Click
        btn16C.Visible = True
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn13C.Visible = False
        btn19C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM proveedor WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT* FROM proveedor WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Proveedor"))
                    Me.grd1C.DataSource = ds.Tables("Proveedor")
                Else
                    MsgBox("No hay proveedores.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM proveedor WHERE borrado=0"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT* FROM proveedor WHERE borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Proveedor"))
                    Me.grd1C.DataSource = ds.Tables("Proveedor")
                Else
                    MsgBox("No hay proveedores.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub

    Private Sub btn9C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn9C.Click
        btn16C.Visible = False
        btn3C.Visible = False
        btn11C.Visible = False
        btn12C.Visible = False
        btn19C.Visible = True
        btn13C.Visible = False
        btn14C.Visible = False
        btn15C.Visible = False
        cbm1C.SelectedIndex = -1
        If cont = 0 Then
            sql = "SELECT COUNT(*) FROM pedidobordado"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT PB.fechaSalida 'Fecha de salida', PB.fechaRecibido 'Fecha de recibo', PD.precio 'Precio', PD.tiempo 'Tiempo', P.nombre 'Nombre del proveedor' FROM proveedor P, pedidobordado PB, proveedorbordado PD WHERE PB.codPB=PB.codPB AND PD.codProveedor=P.codProveedor AND PD.borrado=0 AND P.borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Bordados"))
                    Me.grd1C.DataSource = ds.Tables("Bordados")
                Else
                    MsgBox("No hay bordados encargados.", MsgBoxStyle.Exclamation, "ERROR")
                    errorcito = 1
                End If
            End If
            cont = 1
        Else
            If errorcito = 0 Then
                grd1C.DataSource.clear()
            End If
            sql = "SELECT COUNT(*) FROM pedidobordado"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT PB.fechaSalida 'Fecha de salida', PB.fechaRecibido 'Fecha de recibo', PD.precio 'Precio', PD.tiempo 'Tiempo', P.nombre 'Nombre del proveedor' FROM proveedor P, pedidobordado PB, proveedorbordado PD WHERE PB.codPB=PB.codPB AND PD.codProveedor=P.codProveedor AND PD.borrado=0 AND P.borrado=0"
                    adp = New OdbcDataAdapter(sql, cnn)
                    adp.Fill(ds.Tables("Bordados"))
                    Me.grd1C.DataSource = ds.Tables("Bordados")
                Else
                    MsgBox("No hay bordados encargados.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        End If
    End Sub


    Private Sub cuotasC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cuotasC.Click
        Me.Hide()
        Cuotass.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Hide()
        Cuotass.Show()
    End Sub

    Private Sub btn11C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn11C.Click
        Me.Hide()
        ElimCliente.Show()
    End Sub

    Private Sub btn12C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn12C.Click
        Me.Hide()
        AERopa.Show()
    End Sub

    Private Sub btn13C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn13C.Click
        Me.Hide()
        AETalles.Show()
    End Sub

    Private Sub btn14C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn14C.Click
        Me.Hide()
        AEDetalles.Show()
    End Sub

    Private Sub btn15C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn15C.Click
        Me.Hide()
        AEColores.Show()
    End Sub

    Private Sub btn16C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn16C.Click
        Me.Hide()
        AEProveedores.Show()
    End Sub

    Private Sub btn17C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn17C.Click
        Me.Hide()
        Stock.Show()
    End Sub

    Private Sub btn18C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn18C.Click
        Me.Hide()
        Precios.Show()
    End Sub

    Private Sub btn19C_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn19C.Click
        Me.Hide()
        LlegadaBordados.Show()
    End Sub
End Class