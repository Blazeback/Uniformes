﻿Imports System.Data.Odbc

Public Class LlegadaBordados

    Private Sub LlegadaBordados_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Tables.Add("LB")
        sql = "SELECT curdate()"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            fechaLB.Text = rs(0)
        End If
        sql = "SELECT PB.fechaSalida 'Fecha de salida', PB.fechaRecibido 'Fecha de recibo', PD.precio 'Precio', PD.tiempo 'Tiempo', P.nombre 'Nombre del proveedor' FROM proveedor P, pedidobordado PB, proveedorbordado PD WHERE PB.codPB=PB.codPB AND PD.codProveedor=P.codProveedor AND PD.borrado=0 AND P.borrado=0"
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("LB"))
        Me.grdLB.DataSource = ds.Tables("LB")
    End Sub

    Private Sub btnLB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLB.Click
        Me.Close()
        Try
            grdLB.DataSource.clear()
            Control.Show()
        Catch ex As Exception
            Control.Show()
        End Try
    End Sub

    Private Sub registrarLB_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles registrarLB.Click
        sql = "SELECT COUNT(*) FROM proveedor P, pedidobordado PB, proveedorbordado PD WHERE PB.codPB=PB.codPB AND PD.codProveedor=P.codProveedor AND PD.borrado=0 AND P.borrado=0"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) > 0 Then
                sql = "SELECT PB.codPB, PB.fechaSalida 'Fecha de salida', PB.fechaRecibido 'Fecha de recibo', PD.precio 'Precio', PD.tiempo 'Tiempo', P.nombre 'Nombre del proveedor' FROM proveedor P, pedidobordado PB, proveedorbordado PD WHERE PB.codPB=PB.codPB AND PD.codProveedor=P.codProveedor AND PD.borrado=0 AND P.borrado=0 AND P.nombre='" & Trim(mskBordadoLB.Text) & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    sql = "UPDATE pedidobordado SET fecharecibido=(SELECT curdate()) WHERE codPB='" & rs(0) & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                        MsgBox("¡Pedido registrado!", MsgBoxStyle.Exclamation, "EXITO")
                        mskBordadoLB.Text = ""
                        Me.Close()
                        Control.Show()
                Else
                    MsgBox("¡El proveedor ingresado no existe!.", MsgBoxStyle.Exclamation, "ERROR")
                End If
            End If
        Else
            MsgBox("¡No hay bordados!.", MsgBoxStyle.Exclamation, "ERROR")
            mskBordadoLB.Text = ""
        End If
    End Sub
End Class