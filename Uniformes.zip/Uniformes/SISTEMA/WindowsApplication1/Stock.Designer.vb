﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Stock
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmb3 = New System.Windows.Forms.ComboBox()
        Me.cmb2 = New System.Windows.Forms.ComboBox()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.cmb5 = New System.Windows.Forms.ComboBox()
        Me.cmb4 = New System.Windows.Forms.ComboBox()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk2 = New System.Windows.Forms.MaskedTextBox()
        Me.SuspendLayout()
        '
        'cmb3
        '
        Me.cmb3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb3.FormattingEnabled = True
        Me.cmb3.Location = New System.Drawing.Point(270, 67)
        Me.cmb3.Name = "cmb3"
        Me.cmb3.Size = New System.Drawing.Size(121, 31)
        Me.cmb3.TabIndex = 0
        '
        'cmb2
        '
        Me.cmb2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb2.FormattingEnabled = True
        Me.cmb2.Location = New System.Drawing.Point(143, 67)
        Me.cmb2.Name = "cmb2"
        Me.cmb2.Size = New System.Drawing.Size(121, 31)
        Me.cmb2.TabIndex = 1
        '
        'cmb1
        '
        Me.cmb1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Location = New System.Drawing.Point(16, 67)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(121, 31)
        Me.cmb1.TabIndex = 2
        '
        'cmb5
        '
        Me.cmb5.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb5.FormattingEnabled = True
        Me.cmb5.Location = New System.Drawing.Point(143, 150)
        Me.cmb5.Name = "cmb5"
        Me.cmb5.Size = New System.Drawing.Size(121, 31)
        Me.cmb5.TabIndex = 3
        '
        'cmb4
        '
        Me.cmb4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb4.FormattingEnabled = True
        Me.cmb4.Location = New System.Drawing.Point(16, 150)
        Me.cmb4.Name = "cmb4"
        Me.cmb4.Size = New System.Drawing.Size(121, 31)
        Me.cmb4.TabIndex = 4
        '
        'btn3
        '
        Me.btn3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn3.Location = New System.Drawing.Point(528, 153)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(75, 33)
        Me.btn3.TabIndex = 5
        Me.btn3.Text = "Volver"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(376, 152)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(104, 32)
        Me.btn2.TabIndex = 6
        Me.btn2.Text = "Actualizar"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(503, 66)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(104, 32)
        Me.btn1.TabIndex = 7
        Me.btn1.Text = "Actualizar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(12, 9)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(405, 23)
        Me.lbl1.TabIndex = 8
        Me.lbl1.Text = "Seleccione según lo que tenga que actualizar"
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl8.Location = New System.Drawing.Point(266, 123)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(75, 23)
        Me.lbl8.TabIndex = 9
        Me.lbl8.Text = "Cantidad"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl6.Location = New System.Drawing.Point(12, 123)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(71, 23)
        Me.lbl6.TabIndex = 10
        Me.lbl6.Text = "Artículo"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4.Location = New System.Drawing.Point(266, 40)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(48, 23)
        Me.lbl4.TabIndex = 11
        Me.lbl4.Text = "Talle"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3.Location = New System.Drawing.Point(139, 40)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(49, 23)
        Me.lbl3.TabIndex = 12
        Me.lbl3.Text = "Color"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(12, 40)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(63, 23)
        Me.lbl2.TabIndex = 13
        Me.lbl2.Text = "Prenda"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5.Location = New System.Drawing.Point(393, 40)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(75, 23)
        Me.lbl5.TabIndex = 14
        Me.lbl5.Text = "Cantidad"
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl7.Location = New System.Drawing.Point(139, 123)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(49, 23)
        Me.lbl7.TabIndex = 15
        Me.lbl7.Text = "Color"
        '
        'msk1
        '
        Me.msk1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(397, 70)
        Me.msk1.Mask = "0000"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(100, 31)
        Me.msk1.TabIndex = 16
        '
        'msk2
        '
        Me.msk2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2.Location = New System.Drawing.Point(270, 153)
        Me.msk2.Mask = "0000"
        Me.msk2.Name = "msk2"
        Me.msk2.Size = New System.Drawing.Size(100, 31)
        Me.msk2.TabIndex = 17
        '
        'Stock
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(615, 198)
        Me.Controls.Add(Me.msk2)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.cmb4)
        Me.Controls.Add(Me.cmb5)
        Me.Controls.Add(Me.cmb1)
        Me.Controls.Add(Me.cmb2)
        Me.Controls.Add(Me.cmb3)
        Me.Name = "Stock"
        Me.Text = "STOCK"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmb3 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb2 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb5 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb4 As System.Windows.Forms.ComboBox
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2 As System.Windows.Forms.MaskedTextBox
End Class
