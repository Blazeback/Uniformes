﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PBordado
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk2 = New System.Windows.Forms.MaskedTextBox()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.msk3 = New System.Windows.Forms.MaskedTextBox()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1.Location = New System.Drawing.Point(15, 9)
        Me.lbl1.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(202, 23)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "Ingrese por cada prenda:"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3.Location = New System.Drawing.Point(45, 68)
        Me.lbl3.Margin = New System.Windows.Forms.Padding(6, 0, 6, 0)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(14, 23)
        Me.lbl3.TabIndex = 1
        Me.lbl3.Text = ":"
        '
        'msk1
        '
        Me.msk1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(19, 63)
        Me.msk1.Margin = New System.Windows.Forms.Padding(6)
        Me.msk1.Mask = "00"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(27, 31)
        Me.msk1.TabIndex = 2
        '
        'msk2
        '
        Me.msk2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2.Location = New System.Drawing.Point(58, 63)
        Me.msk2.Margin = New System.Windows.Forms.Padding(6)
        Me.msk2.Mask = "00"
        Me.msk2.Name = "msk2"
        Me.msk2.Size = New System.Drawing.Size(28, 31)
        Me.msk2.TabIndex = 3
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(239, 58)
        Me.btn1.Margin = New System.Windows.Forms.Padding(6)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(138, 42)
        Me.btn1.TabIndex = 4
        Me.btn1.Text = "Continuar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(239, 112)
        Me.btn2.Margin = New System.Windows.Forms.Padding(6)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(138, 42)
        Me.btn2.TabIndex = 5
        Me.btn2.Text = "Cancelar"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'msk3
        '
        Me.msk3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk3.Location = New System.Drawing.Point(19, 125)
        Me.msk3.Mask = "000"
        Me.msk3.Name = "msk3"
        Me.msk3.Size = New System.Drawing.Size(39, 31)
        Me.msk3.TabIndex = 6
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(15, 33)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(155, 23)
        Me.lbl2.TabIndex = 7
        Me.lbl2.Text = "Tiempo de bordado"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4.Location = New System.Drawing.Point(15, 98)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(56, 23)
        Me.lbl4.TabIndex = 8
        Me.lbl4.Text = "Precio"
        '
        'PBordado
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(386, 162)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.msk3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.msk2)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(6)
        Me.Name = "PBordado"
        Me.Text = "BORDADO"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents msk3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
End Class
