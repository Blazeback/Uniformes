﻿Imports System.Data.Odbc
Public Class EBordados
    Dim sql As String
    Dim ds As New DataSet
    Dim adp As OdbcDataAdapter
    Dim rs2 As OdbcDataReader
    Dim tiempito As Date
    Dim fecha As Date

    Dim Flag As Integer
    Dim Flag2 As Integer

    Private Sub Form3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call conexion()
        'SELECT C.nombre, C.apellido, C.DNI, NP. fechaInicio FROM cliente C, factura F, notapedido NP, pedidoropa PR, pedidoropadetalle PRD WHERE C.codCliente=F.codCliente AND F.numNotaPedido=NP.numNotaPedido AND NP.numNotaPedido=PR.numNotaPedido AND PR.codPedidoRopa=PRD.codPedidoRopa AND PRD.codPRD NOT IN (SELECT codPRD FROM pedidobordado) GROUP BY C.codCliente
        sql = "Select C.nombre, C.apellido, C.DNI, NP.fechaInicio From cliente C, factura F, notaPedido NP, (Select NP.numNotaPedido A from notaPedido NP, pedidoRopa PR, pedidoRopaDetalle PRD, pedidoBordado PB where NP.numNotaPedido=PR.numNotaPedido and PR.codPedidoRopa=PRD.codPedidoRopa and PRD.codPRD=PB.codPRD) X Where finalizado=false and C.codCliente=F.codCliente and F.numNotaPedido=NP.numNotaPedido and NP.numNotaPedido NOT IN (X.A) group by NP.numNotaPedido"
        ds.Tables.Add("Pedidos")
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("Pedidos"))
        Me.grd1B.DataSource = ds.Tables("Pedidos")

        sql = "Select P.nombre, P.numCuit, PB.precio, PB.tiempo From proveedor P, proveedorBordado PB Where P.codProveedor=PB.codProveedor"
        ds.Tables.Add("Proveedores")
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("Proveedores"))
        Me.grd2B.DataSource = ds.Tables("Proveedores")

        lst1.Items.Add("Pedido")
        lst2.Items.Add("Proveedor")
    End Sub

    Dim DNI As Integer
    Private Sub grd1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grd1B.CellContentClick
        Dim nombre As String
        Dim apellido As String


        If Flag = 0 Then
            nombre = (grd1B.Rows(e.RowIndex).Cells("nombre").Value.ToString())
            apellido = (grd1B.Rows(e.RowIndex).Cells("apellido").Value.ToString())
            DNI = (grd1B.Rows(e.RowIndex).Cells("DNI").Value.ToString())
            lst1.Items.Add(nombre & " " & apellido)
            Flag = 1
        Else
            lst1.Items.RemoveAt(1)
            Flag = 0
        End If
    End Sub

    Dim numCuit As String
    Dim precio As Integer
    Dim tiempo As String
    Private Sub grd2_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grd2B.CellContentClick
        Dim nombre As String

        If Flag2 = 0 Then
            nombre = (grd2B.Rows(e.RowIndex).Cells("nombre").Value.ToString())
            numCuit = (grd2B.Rows(e.RowIndex).Cells("numCuit").Value.ToString())
            precio = (grd2B.Rows(e.RowIndex).Cells("precio").Value.ToString())
            tiempo = (grd2B.Rows(e.RowIndex).Cells("tiempo").Value.ToString())
            lst2.Items.Add(nombre & " " & numCuit & " " & precio & " " & tiempo)
            Flag2 = 1
        Else
            lst2.Items.RemoveAt(1)
            Flag2 = 0
        End If
    End Sub

    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        Dim codP As Integer
        Dim b As Integer

        tiempito = TimeOfDay
        tiempito = "00:00:00"

        If Flag = 0 Or Flag2 = 0 Then
            MsgBox("Faltan seleccionar datos.", MsgBoxStyle.Exclamation, "Error")
        Else
            b = 1
            sql = "Select CodPB, tiempo from proveedorBordado PB, proveedor P Where PB.codProveedor=P.codProveedor and P.numCuit='" & numCuit & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                codP = rs(0)
                'tiempito = rs(1)
            End If
            sql = "Select codPRD from pedidoRopaDetalle PRD, pedidoRopa PR, notaPedido NP, factura F, Cliente C, Detalle D Where NP.finalizado=false and C.codCliente=F.codCliente and F.numNotaPedido=NP.numNotaPedido and NP.numNotaPedido=PR.numNotaPedido and PR.codPedidoRopa=PRD.codPedidoRopa and PRD.codDetalle=D.codDetalle and D.nombre='Escudo' and C.DNI=" & DNI
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            While rs.Read = True
                sql = "Insert into pedidoBordado Values (" & rs(0) & ", " & codP & ", curdate(), null)"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs2 = comando.ExecuteReader
                comando.Dispose()
            End While
        End If
        If b = 1 Then
            lst1.Items.Remove(1)
            lst2.Items.Remove(1)
            Flag = 0
            Flag2 = 0
            b = 0
            grd1B.DataSource.clear()
            grd2B.DataSource.clear()
            MsgBox("El pedido ha sido ingresado exitosamente", MsgBoxStyle.Exclamation, "EXITO")
            Principal.Show()
            Me.Close()
        End If
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        If Flag = 1 Then
            lst1.Items.Remove(1)
            Flag = 0
        End If
        If Flag2 = 1 Then
            lst2.Items.Remove(1)
            Flag2 = 0
        End If
        Me.Close()
        Principal.Show()
    End Sub
End Class