﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AgregarUser
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.lbl1User = New System.Windows.Forms.Label()
        Me.btnCancelarUser = New System.Windows.Forms.Button()
        Me.btnAgregarUser = New System.Windows.Forms.Button()
        Me.cbm1User = New System.Windows.Forms.ComboBox()
        Me.lbl2User = New System.Windows.Forms.Label()
        Me.lbl3User = New System.Windows.Forms.Label()
        Me.lbl4User = New System.Windows.Forms.Label()
        Me.txt4User = New System.Windows.Forms.TextBox()
        Me.txt3User = New System.Windows.Forms.TextBox()
        Me.txt1User = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(7, 7)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(237, 344)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(252, 358)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'lbl1User
        '
        Me.lbl1User.AutoSize = True
        Me.lbl1User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1User.Location = New System.Drawing.Point(24, 23)
        Me.lbl1User.Name = "lbl1User"
        Me.lbl1User.Size = New System.Drawing.Size(153, 23)
        Me.lbl1User.TabIndex = 14
        Me.lbl1User.Text = "Nombre de usuario"
        '
        'btnCancelarUser
        '
        Me.btnCancelarUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelarUser.Location = New System.Drawing.Point(138, 301)
        Me.btnCancelarUser.Name = "btnCancelarUser"
        Me.btnCancelarUser.Size = New System.Drawing.Size(97, 39)
        Me.btnCancelarUser.TabIndex = 13
        Me.btnCancelarUser.Text = "Cancelar"
        Me.btnCancelarUser.UseVisualStyleBackColor = True
        '
        'btnAgregarUser
        '
        Me.btnAgregarUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAgregarUser.Location = New System.Drawing.Point(28, 301)
        Me.btnAgregarUser.Name = "btnAgregarUser"
        Me.btnAgregarUser.Size = New System.Drawing.Size(97, 39)
        Me.btnAgregarUser.TabIndex = 12
        Me.btnAgregarUser.Text = "Agregar"
        Me.btnAgregarUser.UseVisualStyleBackColor = True
        '
        'cbm1User
        '
        Me.cbm1User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbm1User.FormattingEnabled = True
        Me.cbm1User.Location = New System.Drawing.Point(28, 111)
        Me.cbm1User.Name = "cbm1User"
        Me.cbm1User.Size = New System.Drawing.Size(140, 31)
        Me.cbm1User.TabIndex = 24
        '
        'lbl2User
        '
        Me.lbl2User.AutoSize = True
        Me.lbl2User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2User.Location = New System.Drawing.Point(24, 84)
        Me.lbl2User.Name = "lbl2User"
        Me.lbl2User.Size = New System.Drawing.Size(59, 23)
        Me.lbl2User.TabIndex = 23
        Me.lbl2User.Text = "Sector"
        '
        'lbl3User
        '
        Me.lbl3User.AutoSize = True
        Me.lbl3User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3User.Location = New System.Drawing.Point(24, 156)
        Me.lbl3User.Name = "lbl3User"
        Me.lbl3User.Size = New System.Drawing.Size(189, 23)
        Me.lbl3User.TabIndex = 25
        Me.lbl3User.Text = "Contraseña del usuario"
        '
        'lbl4User
        '
        Me.lbl4User.AutoSize = True
        Me.lbl4User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4User.Location = New System.Drawing.Point(24, 217)
        Me.lbl4User.Name = "lbl4User"
        Me.lbl4User.Size = New System.Drawing.Size(173, 23)
        Me.lbl4User.TabIndex = 27
        Me.lbl4User.Text = "Confirmar contraseña"
        '
        'txt4User
        '
        Me.txt4User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt4User.Location = New System.Drawing.Point(28, 244)
        Me.txt4User.Name = "txt4User"
        Me.txt4User.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt4User.Size = New System.Drawing.Size(121, 31)
        Me.txt4User.TabIndex = 28
        '
        'txt3User
        '
        Me.txt3User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt3User.Location = New System.Drawing.Point(28, 183)
        Me.txt3User.Name = "txt3User"
        Me.txt3User.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt3User.Size = New System.Drawing.Size(121, 31)
        Me.txt3User.TabIndex = 26
        '
        'txt1User
        '
        Me.txt1User.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt1User.Location = New System.Drawing.Point(28, 50)
        Me.txt1User.Name = "txt1User"
        Me.txt1User.Size = New System.Drawing.Size(121, 31)
        Me.txt1User.TabIndex = 15
        '
        'AgregarUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(252, 358)
        Me.Controls.Add(Me.txt4User)
        Me.Controls.Add(Me.lbl4User)
        Me.Controls.Add(Me.txt3User)
        Me.Controls.Add(Me.lbl3User)
        Me.Controls.Add(Me.cbm1User)
        Me.Controls.Add(Me.lbl2User)
        Me.Controls.Add(Me.txt1User)
        Me.Controls.Add(Me.lbl1User)
        Me.Controls.Add(Me.btnCancelarUser)
        Me.Controls.Add(Me.btnAgregarUser)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "AgregarUser"
        Me.Text = "AGREGAR USUARIO"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents lbl1User As System.Windows.Forms.Label
    Friend WithEvents btnCancelarUser As System.Windows.Forms.Button
    Friend WithEvents btnAgregarUser As System.Windows.Forms.Button
    Friend WithEvents cbm1User As System.Windows.Forms.ComboBox
    Friend WithEvents lbl2User As System.Windows.Forms.Label
    Friend WithEvents lbl3User As System.Windows.Forms.Label
    Friend WithEvents lbl4User As System.Windows.Forms.Label
    Friend WithEvents txt4User As System.Windows.Forms.TextBox
    Friend WithEvents txt3User As System.Windows.Forms.TextBox
    Friend WithEvents txt1User As System.Windows.Forms.TextBox
End Class
