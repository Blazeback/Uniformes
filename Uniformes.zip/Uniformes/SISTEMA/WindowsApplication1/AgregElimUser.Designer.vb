﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AgregElimUser
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.btn2AEUser = New System.Windows.Forms.Button()
        Me.btn1AEUser = New System.Windows.Forms.Button()
        Me.lblVolverAgregElimUser = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(7, 3)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(249, 121)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(261, 127)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'btn2AEUser
        '
        Me.btn2AEUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2AEUser.Location = New System.Drawing.Point(140, 12)
        Me.btn2AEUser.Name = "btn2AEUser"
        Me.btn2AEUser.Size = New System.Drawing.Size(97, 59)
        Me.btn2AEUser.TabIndex = 15
        Me.btn2AEUser.Text = "Eliminar usuarios"
        Me.btn2AEUser.UseVisualStyleBackColor = True
        '
        'btn1AEUser
        '
        Me.btn1AEUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1AEUser.Location = New System.Drawing.Point(27, 12)
        Me.btn1AEUser.Name = "btn1AEUser"
        Me.btn1AEUser.Size = New System.Drawing.Size(97, 58)
        Me.btn1AEUser.TabIndex = 14
        Me.btn1AEUser.Text = "Agregar usuarios"
        Me.btn1AEUser.UseVisualStyleBackColor = True
        '
        'lblVolverAgregElimUser
        '
        Me.lblVolverAgregElimUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblVolverAgregElimUser.Location = New System.Drawing.Point(82, 77)
        Me.lblVolverAgregElimUser.Name = "lblVolverAgregElimUser"
        Me.lblVolverAgregElimUser.Size = New System.Drawing.Size(97, 39)
        Me.lblVolverAgregElimUser.TabIndex = 16
        Me.lblVolverAgregElimUser.Text = "Volver"
        Me.lblVolverAgregElimUser.UseVisualStyleBackColor = True
        '
        'AgregElimUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(261, 127)
        Me.Controls.Add(Me.lblVolverAgregElimUser)
        Me.Controls.Add(Me.btn2AEUser)
        Me.Controls.Add(Me.btn1AEUser)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "AgregElimUser"
        Me.Text = "¿?"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents btn2AEUser As System.Windows.Forms.Button
    Friend WithEvents btn1AEUser As System.Windows.Forms.Button
    Friend WithEvents lblVolverAgregElimUser As System.Windows.Forms.Button
End Class
