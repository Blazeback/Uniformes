﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrdenConfeccion
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OrdenConfeccion))
        Me.pcbOrdConf1 = New System.Windows.Forms.PictureBox()
        Me.lblCodOrdConf = New System.Windows.Forms.Label()
        Me.grdCONF = New System.Windows.Forms.DataGridView()
        Me.btnSalirConfeccion = New System.Windows.Forms.Button()
        Me.btn1Confeccion = New System.Windows.Forms.Button()
        Me.pf1Confeccion = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        CType(Me.pcbOrdConf1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdCONF, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pcbOrdConf1
        '
        Me.pcbOrdConf1.Image = CType(resources.GetObject("pcbOrdConf1.Image"), System.Drawing.Image)
        Me.pcbOrdConf1.Location = New System.Drawing.Point(-3, -1)
        Me.pcbOrdConf1.Name = "pcbOrdConf1"
        Me.pcbOrdConf1.Size = New System.Drawing.Size(550, 421)
        Me.pcbOrdConf1.TabIndex = 0
        Me.pcbOrdConf1.TabStop = False
        '
        'lblCodOrdConf
        '
        Me.lblCodOrdConf.AutoSize = True
        Me.lblCodOrdConf.BackColor = System.Drawing.Color.White
        Me.lblCodOrdConf.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodOrdConf.Location = New System.Drawing.Point(307, 32)
        Me.lblCodOrdConf.Name = "lblCodOrdConf"
        Me.lblCodOrdConf.Size = New System.Drawing.Size(56, 17)
        Me.lblCodOrdConf.TabIndex = 5
        Me.lblCodOrdConf.Text = "NÚMERO"
        '
        'grdCONF
        '
        Me.grdCONF.AllowUserToAddRows = False
        Me.grdCONF.AllowUserToDeleteRows = False
        Me.grdCONF.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdCONF.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdCONF.Location = New System.Drawing.Point(-3, 125)
        Me.grdCONF.Name = "grdCONF"
        Me.grdCONF.ReadOnly = True
        Me.grdCONF.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdCONF.Size = New System.Drawing.Size(532, 260)
        Me.grdCONF.TabIndex = 73
        '
        'btnSalirConfeccion
        '
        Me.btnSalirConfeccion.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalirConfeccion.Location = New System.Drawing.Point(260, 426)
        Me.btnSalirConfeccion.Name = "btnSalirConfeccion"
        Me.btnSalirConfeccion.Size = New System.Drawing.Size(141, 39)
        Me.btnSalirConfeccion.TabIndex = 75
        Me.btnSalirConfeccion.Text = "Salir"
        Me.btnSalirConfeccion.UseVisualStyleBackColor = True
        '
        'btn1Confeccion
        '
        Me.btn1Confeccion.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1Confeccion.Location = New System.Drawing.Point(98, 426)
        Me.btn1Confeccion.Name = "btn1Confeccion"
        Me.btn1Confeccion.Size = New System.Drawing.Size(141, 39)
        Me.btn1Confeccion.TabIndex = 74
        Me.btn1Confeccion.Text = "Imprimir"
        Me.btn1Confeccion.UseVisualStyleBackColor = True
        '
        'pf1Confeccion
        '
        Me.pf1Confeccion.DocumentName = "document"
        Me.pf1Confeccion.Form = Me
        Me.pf1Confeccion.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.pf1Confeccion.PrinterSettings = CType(resources.GetObject("pf1Confeccion.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.pf1Confeccion.PrintFileName = Nothing
        '
        'OrdenConfeccion
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(529, 465)
        Me.Controls.Add(Me.btnSalirConfeccion)
        Me.Controls.Add(Me.btn1Confeccion)
        Me.Controls.Add(Me.grdCONF)
        Me.Controls.Add(Me.lblCodOrdConf)
        Me.Controls.Add(Me.pcbOrdConf1)
        Me.Name = "OrdenConfeccion"
        Me.Text = "OrdenConfeccion"
        CType(Me.pcbOrdConf1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdCONF, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pcbOrdConf1 As System.Windows.Forms.PictureBox
    Friend WithEvents lblCodOrdConf As System.Windows.Forms.Label
    Friend WithEvents grdCONF As System.Windows.Forms.DataGridView
    Friend WithEvents btnSalirConfeccion As System.Windows.Forms.Button
    Friend WithEvents btn1Confeccion As System.Windows.Forms.Button
    Friend WithEvents pf1Confeccion As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
End Class
