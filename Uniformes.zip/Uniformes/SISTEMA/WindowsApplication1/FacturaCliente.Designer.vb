﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FacturaCliente
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FacturaCliente))
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.FechaFactura = New System.Windows.Forms.Label()
        Me.NombreFactura = New System.Windows.Forms.Label()
        Me.CodClienteFactura = New System.Windows.Forms.Label()
        Me.LocalidadFactura = New System.Windows.Forms.Label()
        Me.DirFactura = New System.Windows.Forms.Label()
        Me.ProvinciaFactura = New System.Windows.Forms.Label()
        Me.TotalFactura = New System.Windows.Forms.Label()
        Me.IVAFactura = New System.Windows.Forms.Label()
        Me.SeñaFactura = New System.Windows.Forms.Label()
        Me.NPFactura = New System.Windows.Forms.Label()
        Me.NumFactura = New System.Windows.Forms.Label()
        Me.grdFAC = New System.Windows.Forms.DataGridView()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnSalirFactura = New System.Windows.Forms.Button()
        Me.btn1Factura = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblCuotasFactura = New System.Windows.Forms.Label()
        Me.pf1Factura = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.lblFormaPagoFactura = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdFAC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, -3)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(775, 681)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'FechaFactura
        '
        Me.FechaFactura.AutoSize = True
        Me.FechaFactura.BackColor = System.Drawing.Color.White
        Me.FechaFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FechaFactura.Location = New System.Drawing.Point(522, 57)
        Me.FechaFactura.Name = "FechaFactura"
        Me.FechaFactura.Size = New System.Drawing.Size(90, 21)
        Me.FechaFactura.TabIndex = 11
        Me.FechaFactura.Text = "0000-00-00"
        '
        'NombreFactura
        '
        Me.NombreFactura.AutoSize = True
        Me.NombreFactura.BackColor = System.Drawing.Color.White
        Me.NombreFactura.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NombreFactura.Location = New System.Drawing.Point(159, 153)
        Me.NombreFactura.Name = "NombreFactura"
        Me.NombreFactura.Size = New System.Drawing.Size(35, 17)
        Me.NombreFactura.TabIndex = 12
        Me.NombreFactura.Text = "NULO"
        '
        'CodClienteFactura
        '
        Me.CodClienteFactura.AutoSize = True
        Me.CodClienteFactura.BackColor = System.Drawing.Color.White
        Me.CodClienteFactura.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CodClienteFactura.Location = New System.Drawing.Point(159, 201)
        Me.CodClienteFactura.Name = "CodClienteFactura"
        Me.CodClienteFactura.Size = New System.Drawing.Size(35, 17)
        Me.CodClienteFactura.TabIndex = 13
        Me.CodClienteFactura.Text = "NULO"
        '
        'LocalidadFactura
        '
        Me.LocalidadFactura.AutoSize = True
        Me.LocalidadFactura.BackColor = System.Drawing.Color.White
        Me.LocalidadFactura.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LocalidadFactura.Location = New System.Drawing.Point(159, 185)
        Me.LocalidadFactura.Name = "LocalidadFactura"
        Me.LocalidadFactura.Size = New System.Drawing.Size(35, 17)
        Me.LocalidadFactura.TabIndex = 14
        Me.LocalidadFactura.Text = "NULO"
        '
        'DirFactura
        '
        Me.DirFactura.AutoSize = True
        Me.DirFactura.BackColor = System.Drawing.Color.White
        Me.DirFactura.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DirFactura.Location = New System.Drawing.Point(159, 169)
        Me.DirFactura.Name = "DirFactura"
        Me.DirFactura.Size = New System.Drawing.Size(35, 17)
        Me.DirFactura.TabIndex = 15
        Me.DirFactura.Text = "NULO"
        '
        'ProvinciaFactura
        '
        Me.ProvinciaFactura.AutoSize = True
        Me.ProvinciaFactura.BackColor = System.Drawing.Color.White
        Me.ProvinciaFactura.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProvinciaFactura.Location = New System.Drawing.Point(389, 185)
        Me.ProvinciaFactura.Name = "ProvinciaFactura"
        Me.ProvinciaFactura.Size = New System.Drawing.Size(35, 17)
        Me.ProvinciaFactura.TabIndex = 16
        Me.ProvinciaFactura.Text = "NULO"
        '
        'TotalFactura
        '
        Me.TotalFactura.AutoSize = True
        Me.TotalFactura.BackColor = System.Drawing.Color.White
        Me.TotalFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalFactura.Location = New System.Drawing.Point(659, 585)
        Me.TotalFactura.Name = "TotalFactura"
        Me.TotalFactura.Size = New System.Drawing.Size(17, 21)
        Me.TotalFactura.TabIndex = 46
        Me.TotalFactura.Text = "-"
        '
        'IVAFactura
        '
        Me.IVAFactura.AutoSize = True
        Me.IVAFactura.BackColor = System.Drawing.Color.White
        Me.IVAFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.IVAFactura.Location = New System.Drawing.Point(399, 538)
        Me.IVAFactura.Name = "IVAFactura"
        Me.IVAFactura.Size = New System.Drawing.Size(25, 21)
        Me.IVAFactura.TabIndex = 47
        Me.IVAFactura.Text = "21"
        '
        'SeñaFactura
        '
        Me.SeñaFactura.AutoSize = True
        Me.SeñaFactura.BackColor = System.Drawing.Color.White
        Me.SeñaFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SeñaFactura.Location = New System.Drawing.Point(74, 556)
        Me.SeñaFactura.Name = "SeñaFactura"
        Me.SeñaFactura.Size = New System.Drawing.Size(17, 21)
        Me.SeñaFactura.TabIndex = 48
        Me.SeñaFactura.Text = "-"
        '
        'NPFactura
        '
        Me.NPFactura.AutoSize = True
        Me.NPFactura.BackColor = System.Drawing.Color.White
        Me.NPFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NPFactura.Location = New System.Drawing.Point(169, 573)
        Me.NPFactura.Name = "NPFactura"
        Me.NPFactura.Size = New System.Drawing.Size(17, 21)
        Me.NPFactura.TabIndex = 49
        Me.NPFactura.Text = "-"
        '
        'NumFactura
        '
        Me.NumFactura.AutoSize = True
        Me.NumFactura.BackColor = System.Drawing.Color.White
        Me.NumFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NumFactura.Location = New System.Drawing.Point(473, 38)
        Me.NumFactura.Name = "NumFactura"
        Me.NumFactura.Size = New System.Drawing.Size(41, 21)
        Me.NumFactura.TabIndex = 51
        Me.NumFactura.Text = "NULO"
        '
        'grdFAC
        '
        Me.grdFAC.AllowUserToAddRows = False
        Me.grdFAC.AllowUserToDeleteRows = False
        Me.grdFAC.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdFAC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdFAC.Location = New System.Drawing.Point(0, 249)
        Me.grdFAC.Name = "grdFAC"
        Me.grdFAC.ReadOnly = True
        Me.grdFAC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdFAC.Size = New System.Drawing.Size(775, 286)
        Me.grdFAC.TabIndex = 73
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.White
        Me.Label2.Font = New System.Drawing.Font("ISOCPEUR", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(450, 538)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(309, 34)
        Me.Label2.TabIndex = 74
        Me.Label2.Text = "llllllllllllllllllllllllllllllllllllllllll"
        '
        'btnSalirFactura
        '
        Me.btnSalirFactura.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalirFactura.Location = New System.Drawing.Point(618, 639)
        Me.btnSalirFactura.Name = "btnSalirFactura"
        Me.btnSalirFactura.Size = New System.Drawing.Size(141, 39)
        Me.btnSalirFactura.TabIndex = 76
        Me.btnSalirFactura.Text = "Salir"
        Me.btnSalirFactura.UseVisualStyleBackColor = True
        '
        'btn1Factura
        '
        Me.btn1Factura.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1Factura.Location = New System.Drawing.Point(456, 639)
        Me.btn1Factura.Name = "btn1Factura"
        Me.btn1Factura.Size = New System.Drawing.Size(141, 39)
        Me.btn1Factura.TabIndex = 75
        Me.btn1Factura.Text = "Imprimir"
        Me.btn1Factura.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.White
        Me.Label1.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(444, 631)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(253, 27)
        Me.Label1.TabIndex = 52
        Me.Label1.Text = "XDDDDDDDDDDDDDDDDDDD"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.White
        Me.Label3.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(212, 573)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(61, 21)
        Me.Label3.TabIndex = 77
        Me.Label3.Text = "Cuotas:"
        '
        'lblCuotasFactura
        '
        Me.lblCuotasFactura.AutoSize = True
        Me.lblCuotasFactura.BackColor = System.Drawing.Color.White
        Me.lblCuotasFactura.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCuotasFactura.Location = New System.Drawing.Point(278, 573)
        Me.lblCuotasFactura.Name = "lblCuotasFactura"
        Me.lblCuotasFactura.Size = New System.Drawing.Size(18, 21)
        Me.lblCuotasFactura.TabIndex = 78
        Me.lblCuotasFactura.Text = "-"
        '
        'pf1Factura
        '
        Me.pf1Factura.DocumentName = "document"
        Me.pf1Factura.Form = Me
        Me.pf1Factura.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.pf1Factura.PrinterSettings = CType(resources.GetObject("pf1Factura.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.pf1Factura.PrintFileName = Nothing
        '
        'lblFormaPagoFactura
        '
        Me.lblFormaPagoFactura.AutoSize = True
        Me.lblFormaPagoFactura.BackColor = System.Drawing.Color.White
        Me.lblFormaPagoFactura.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormaPagoFactura.Location = New System.Drawing.Point(372, 567)
        Me.lblFormaPagoFactura.Name = "lblFormaPagoFactura"
        Me.lblFormaPagoFactura.Size = New System.Drawing.Size(23, 27)
        Me.lblFormaPagoFactura.TabIndex = 79
        Me.lblFormaPagoFactura.Text = "-"
        '
        'FacturaCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(771, 679)
        Me.Controls.Add(Me.lblFormaPagoFactura)
        Me.Controls.Add(Me.lblCuotasFactura)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnSalirFactura)
        Me.Controls.Add(Me.btn1Factura)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.grdFAC)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.NumFactura)
        Me.Controls.Add(Me.NPFactura)
        Me.Controls.Add(Me.SeñaFactura)
        Me.Controls.Add(Me.IVAFactura)
        Me.Controls.Add(Me.TotalFactura)
        Me.Controls.Add(Me.ProvinciaFactura)
        Me.Controls.Add(Me.DirFactura)
        Me.Controls.Add(Me.LocalidadFactura)
        Me.Controls.Add(Me.CodClienteFactura)
        Me.Controls.Add(Me.NombreFactura)
        Me.Controls.Add(Me.FechaFactura)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "FacturaCliente"
        Me.Text = "FACTURA A"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdFAC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents FechaFactura As System.Windows.Forms.Label
    Friend WithEvents NombreFactura As System.Windows.Forms.Label
    Friend WithEvents CodClienteFactura As System.Windows.Forms.Label
    Friend WithEvents LocalidadFactura As System.Windows.Forms.Label
    Friend WithEvents DirFactura As System.Windows.Forms.Label
    Friend WithEvents ProvinciaFactura As System.Windows.Forms.Label
    Friend WithEvents TotalFactura As System.Windows.Forms.Label
    Friend WithEvents IVAFactura As System.Windows.Forms.Label
    Friend WithEvents SeñaFactura As System.Windows.Forms.Label
    Friend WithEvents NPFactura As System.Windows.Forms.Label
    Friend WithEvents NumFactura As System.Windows.Forms.Label
    Friend WithEvents grdFAC As System.Windows.Forms.DataGridView
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents btnSalirFactura As System.Windows.Forms.Button
    Friend WithEvents btn1Factura As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblCuotasFactura As System.Windows.Forms.Label
    Friend WithEvents pf1Factura As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
    Friend WithEvents lblFormaPagoFactura As System.Windows.Forms.Label
End Class
