﻿Imports System.Data.Odbc
Public Class MPrima1

    Dim ds As New DataSet
    Dim adp As OdbcDataAdapter

    Private Sub btn2V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4.Click


        Principal.Show()
        sql = "delete from insertOCompra"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        cmb1.Enabled = True
        cmb2.Enabled = True
        msk1.Enabled = True
        msk1.Clear()
        Try
            grd1.DataSource.clear()
            cmb1.Items.Clear()
            cmb2.Items.Clear()
            cmb1.Text = ""
            cmb2.Text = ""
            msk1.Clear()
            lst1.Items.Clear()
            btn1.Enabled = True
            btn2.Enabled = False
            btn3.Enabled = False
        Catch ex As Exception
            cmb1.Items.Clear()
            cmb2.Items.Clear()
            cmb1.Text = ""
            cmb2.Text = ""
            msk1.Clear()
            lst1.Items.Clear()
            btn1.Enabled = True
            btn2.Enabled = False
            btn3.Enabled = False
        End Try
        Me.Close()
    End Sub

    Private Sub MPrima1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Tables.Add("Proveedores")
        Call conexion()
        sql = "Select nombre from almacen where borrado=false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb1.Items.Add(rs(0))
        End While

        sql = "Select nombre from colores where borrado = false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb2.Items.Add(rs(0))
        End While
        lst1.Items.Add("Pedido")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        Dim art As String
        Dim col As String
        art = cmb1.Text
        col = cmb2.Text
        If cmb1.Text = "" Or cmb2.Text = "" Or msk1.Text = "" Then
            MsgBox("Faltan seleccionar datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            grd1.Enabled = True
            sql = "Select P.nombre, P.numCuit, PA.precio from proveedor P, proveedorAlmacen PA, almacen A where P.codProveedor=PA.codProveedor and PA.codArticulo=A.codArticulo and A.nombre='" & art & "'"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("Proveedores"))
            Me.grd1.DataSource = ds.Tables("Proveedores")
            btn1.Enabled = False
            btn2.Enabled = True
            cmb1.Enabled = False
            cmb2.Enabled = False
            msk1.Enabled = False
        End If
    End Sub

    Dim nom As String
    Dim cuit As String
    Dim precio As Integer
    Dim flag As Integer

    Private Sub grd1_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grd1.CellContentClick
        nom = (grd1.Rows(e.RowIndex).Cells("nombre").Value.ToString())
        cuit = (grd1.Rows(e.RowIndex).Cells("numCuit").Value.ToString())
        precio = (grd1.Rows(e.RowIndex).Cells("precio").Value.ToString())
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        Dim codAC As Integer
        Dim codP As Integer
        Dim total As Integer
        If nom = "" Then
            MsgBox("Faltan seleccionar datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            sql = "Select codAlmacenColor from almacenColor AC, almacen A, colores C Where C.idColor=AC.idColor and A.codArticulo=AC.codArticulo and C.nombre='" & cmb2.Text & "' and A.nombre='" & cmb1.Text & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                codAC = rs(0)
            End If
            sql = "Select codProveedor from proveedor Where numCuit=" & cuit
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                codP = rs(0)
            End If
            total = precio * Trim(msk1.Text)
            sql = "Insert into insertOCompra values ('', " & codP & ", " & codAC & " , " & Trim(msk1.Text) & ", " & total & ")"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()

            grd1.DataSource.clear()

            lst1.Items.Add("Pedido: " & cmb1.Text & " " & cmb2.Text & " por " & Trim(msk1.Text) & " unidades")
            lst1.Items.Add("Proveedor:" & nom & ", cuit: " & cuit)
            lst1.Items.Add("Total: " & total)
            lst1.Items.Add("")

            btn3.Enabled = True
            btn1.Enabled = True
            btn2.Enabled = False
            cmb1.Enabled = True
            cmb2.Enabled = True
            msk1.Enabled = True
            cmb1.Text = ""
            cmb2.Text = ""
            msk1.Text = ""
        End If
    End Sub

    Dim rs2 As OdbcDataReader

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        Dim codP As Integer
        'Dim numR As Integer
        sql = "select * from insertOCompra"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs2 = comando.ExecuteReader
        comando.Dispose()
        While rs2.Read = True
            codP = rs2(1)
            sql = "Insert into facturaProveedor Values ('', " & rs2(4) & ", null, false)"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            sql = "select max(codFactura) from facturaProveedor"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                sql = "Insert into remitoProveedor Values ('', " & rs(0) & ", curdate(), null, null)"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
            End If
            sql = "select max(numRemitoP) from remitoProveedor"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()

            If rs.Read = True Then
                sql = "Insert Into ordenCompra Values('', " & rs(0) & ", " & rs2(2) & ", " & rs2(3) & ")"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
            End If
        End While
        MsgBox("Operacion exitosa", MsgBoxStyle.Exclamation, "EXITO")
        sql = "delete from insertOCompra"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        grd1.DataSource.clear()
        cmb1.Items.Clear()
        cmb2.Items.Clear()
        msk1.Clear()
        lst1.Items.Clear()
        btn1.Enabled = True
        btn2.Enabled = False
        btn3.Enabled = False
        Principal.Show()
        Me.Close()
    End Sub
End Class