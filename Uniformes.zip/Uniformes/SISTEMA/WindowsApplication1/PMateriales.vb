﻿Imports System.Data.Odbc
Public Class PMateriales
    Dim cod As Integer
    Dim b As Integer
    Private Sub PMateriales_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call conexion()
        sql = "Select nombre from articulos"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        While rs.Read = True
            cmb1.Items.Add(rs(0))
        End While
        sql = "Select max(codProveedor) from proveedor"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        cod = rs(0)
        btn1.Enabled = False
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        If cmb1.Text = "" Or msk1.Text <> "" Then
            MsgBox("Usted a dejado campos sin completar", MsgBoxStyle.Exclamation, "ERROR")
        Else
            sql = "Select codArticulo from almacen where nombre=" & cmb1.Text
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            sql = "Insert into proveedorAlmacen values(" & cod & ", " & rs(0) & ", " & Trim(msk1.Text)
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If b = 0 Then
                btn1.Enabled = True
                btn3.Enabled = False
                b = 1
            End If
        End If
    End Sub

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        sql = "Delete From proveedor Where codProveedor=" & rs(0)
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        msk1.Clear()
        Me.Hide()
        AEProveedores.Show()
    End Sub

    Private Sub btn2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        msk1.Clear()
        Me.Hide()
        AEProveedores.Show()
        MsgBox("¡El proveedor a sido ingresado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
    End Sub
End Class