﻿Imports System.Data.Odbc
Imports System.Globalization

Public Module Modulo
    Public cnn As OdbcConnection
    Public comando As OdbcCommand
    Public sql As String
    Public rs As OdbcDataReader
    Public ds As New DataSet
    Public adp As OdbcDataAdapter
    Public user As String
    Public sectoruser As String
    Public codigoxd As Integer
    Public cambio As New Globalization.CultureInfo("es-ES")
    Public banderadni As Integer
    Public preciocam As Integer
    Public cantidadcam As Integer
    Public tiempocam As Date
    Public preciototal As Integer
    Public npglobal As Integer
    Public banderabordado As Integer
    Public fechaentregaglobal As Date
    Public cuotas As Integer
    Public formapago As String
    Public banderaconfeccion As Integer
    Public banderacompra As Integer
    Public npentrega As Integer
    Public bnp As Integer
    Public bord As Integer
    Public bfact As Integer
    Public bcuot As Integer
    Public bcc As Integer
    Public bent As Integer

    Public Sub conexion()
        Try
            cnn = New OdbcConnection("DSN=uniformes")
            cnn.Open()
            Usuario.lbl7U.Visible = True
        Catch ex As Exception
            Usuario.lbl6U.Visible = True
        End Try

        cambio.NumberFormat.NumberDecimalSeparator = (".")
        System.Threading.Thread.CurrentThread.CurrentCulture = cambio
    End Sub
End Module
