﻿Imports System.Data.Odbc

Public Class Cuotass
    Dim dni As Integer
    Dim b As Integer
    Dim codcli As Integer

    Private Sub Cuotas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If bcuot <> 1 Then
            bcuot = 1
            ds.Tables.Add("Cuotas")
        End If

        b = 0
        Do While b = 0
            Try
                dni = CInt(InputBox("Ingrese el DNI del cliente."))
                sql = "SELECT COUNT(*) FROM cliente WHERE dni='" & dni & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    If rs(0) > 0 Then
                        b = 1
                    Else
                        b = 0
                        MsgBox("DNI inválido.", MsgBoxStyle.Exclamation, "ERROR")
                    End If
                End If
            Catch ex As Exception
                b = 1
                Me.Close()
                Control.Show()
            End Try
        Loop
        sql = "SELECT CONCAT(nombre, ' ' ,apellido) FROM cliente WHERE dni='" & dni & "'"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            lblClienteCuotas.Text = rs(0)
        End If
        sql = "SELECT codCliente FROM cliente WHERE dni='" & dni & "'"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            codcli = rs(0)
            sql = "SELECT COUNT(*) FROM factura WHERE codCliente='" & codcli & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "SELECT COUNT(*) FROM factura WHERE codCliente='" & codcli & "' AND numFactura IN (SELECT numFactura FROM cuotas WHERE fPago IS NULL)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        If rs(0) > 0 Then
                            sql = "SELECT* FROM cuotas WHERE fPago IS null AND numFactura IN (SELECT numFactura FROM factura WHERE codCliente='" & codcli & "')"
                            adp = New OdbcDataAdapter(sql, cnn)
                            adp.Fill(ds.Tables("Cuotas"))
                            Me.grdCuotas.DataSource = ds.Tables("Cuotas")
                            grdCuotas.DataSource.clear()
                            sql = "SELECT* FROM cuotas WHERE fPago IS null AND numFactura IN (SELECT numFactura FROM factura WHERE codCliente='" & codcli & "')"
                            adp = New OdbcDataAdapter(sql, cnn)
                            adp.Fill(ds.Tables("Cuotas"))
                            Me.grdCuotas.DataSource = ds.Tables("Cuotas")
                        Else
                            MsgBox("El cliente no tiene cuotas registradas.", MsgBoxStyle.Exclamation, "ERROR")
                            Me.Close()
                            Control.Show()
                        End If
                    End If
                Else
                    MsgBox("El cliente no tiene facturas registradas.", MsgBoxStyle.Exclamation, "ERROR")
                    Me.Hide()
                    Control.Show()
                End If
            End If
        End If
    End Sub

    Private Sub btnCancelarCuotas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarCuotas.Click
        Me.Close()
        grdCuotas.DataSource.clear()
        Control.Show()
    End Sub

    Private Sub btnPagoCuota_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPagoCuota.Click
        sql = "SELECT COUNT(*) FROM cuotas WHERE codCuota='" & Trim(mskCuota.Text) & "'and fPago IS NULL"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) > 0 Then
                sql = "UPDATE cuotas SET fPago=(SELECT curdate()) WHERE codCuota='" & Trim(mskCuota.Text) & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                sql = "SELECT monto FROM cuotas WHERE codCuota='" & Trim(mskCuota.Text) & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    sql = "INSERT INTO reciboc VALUES('', '" & Trim(mskCuota.Text) & "', (SELECT curdate()), '" & rs(0) & "', true)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                MsgBox("¡Cuota pagada exitosamente!", MsgBoxStyle.Exclamation, "ERROR")
                Me.Close()
                Control.Show()
            Else
                MsgBox("La cuota no existe.", MsgBoxStyle.Exclamation, "ERROR")
                mskCuota.Text = ""
            End If
        End If
    End Sub
End Class