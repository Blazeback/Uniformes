﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RemitoCliente
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(RemitoCliente))
        Me.pcb1RemitoC = New System.Windows.Forms.PictureBox()
        Me.lblLocalidadRemC = New System.Windows.Forms.Label()
        Me.lblDireccionRemC = New System.Windows.Forms.Label()
        Me.lblNombreRemC = New System.Windows.Forms.Label()
        Me.lblTelRemC = New System.Windows.Forms.Label()
        Me.lblCPRemC = New System.Windows.Forms.Label()
        Me.lblProvinciaRemC = New System.Windows.Forms.Label()
        Me.lblCodigoRemC = New System.Windows.Forms.Label()
        Me.lblFechaRemC = New System.Windows.Forms.Label()
        Me.lbl2RemC = New System.Windows.Forms.Label()
        Me.lbl1RemC = New System.Windows.Forms.Label()
        Me.lbl4RemC = New System.Windows.Forms.Label()
        Me.lbl7RemC = New System.Windows.Forms.Label()
        Me.lbl10RemC = New System.Windows.Forms.Label()
        Me.lbl13RemC = New System.Windows.Forms.Label()
        Me.lbl16RemC = New System.Windows.Forms.Label()
        Me.lbl19RemC = New System.Windows.Forms.Label()
        Me.lbl5RemC = New System.Windows.Forms.Label()
        Me.lbl8RemC = New System.Windows.Forms.Label()
        Me.lbl11RemC = New System.Windows.Forms.Label()
        Me.lbl14RemC = New System.Windows.Forms.Label()
        Me.lbl17RemC = New System.Windows.Forms.Label()
        Me.lbl20RemC = New System.Windows.Forms.Label()
        Me.lbl3RemC = New System.Windows.Forms.Label()
        Me.lbl6RemC = New System.Windows.Forms.Label()
        Me.lbl9RemC = New System.Windows.Forms.Label()
        Me.lbl12RemC = New System.Windows.Forms.Label()
        Me.lbl15RemC = New System.Windows.Forms.Label()
        Me.lbl18RemC = New System.Windows.Forms.Label()
        Me.lbl21RemC = New System.Windows.Forms.Label()
        Me.lblCodClienteRemC = New System.Windows.Forms.Label()
        Me.grdREMC = New System.Windows.Forms.DataGridView()
        Me.btnSalirREMC = New System.Windows.Forms.Button()
        Me.btn1REMC = New System.Windows.Forms.Button()
        Me.prf1REMC = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        CType(Me.pcb1RemitoC, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdREMC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pcb1RemitoC
        '
        Me.pcb1RemitoC.Image = CType(resources.GetObject("pcb1RemitoC.Image"), System.Drawing.Image)
        Me.pcb1RemitoC.Location = New System.Drawing.Point(-1, -5)
        Me.pcb1RemitoC.Name = "pcb1RemitoC"
        Me.pcb1RemitoC.Size = New System.Drawing.Size(667, 665)
        Me.pcb1RemitoC.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pcb1RemitoC.TabIndex = 0
        Me.pcb1RemitoC.TabStop = False
        '
        'lblLocalidadRemC
        '
        Me.lblLocalidadRemC.AutoSize = True
        Me.lblLocalidadRemC.BackColor = System.Drawing.Color.White
        Me.lblLocalidadRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLocalidadRemC.Location = New System.Drawing.Point(105, 184)
        Me.lblLocalidadRemC.Name = "lblLocalidadRemC"
        Me.lblLocalidadRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblLocalidadRemC.TabIndex = 7
        Me.lblLocalidadRemC.Text = "-"
        '
        'lblDireccionRemC
        '
        Me.lblDireccionRemC.AutoSize = True
        Me.lblDireccionRemC.BackColor = System.Drawing.Color.White
        Me.lblDireccionRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDireccionRemC.Location = New System.Drawing.Point(105, 160)
        Me.lblDireccionRemC.Name = "lblDireccionRemC"
        Me.lblDireccionRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblDireccionRemC.TabIndex = 8
        Me.lblDireccionRemC.Text = "-"
        '
        'lblNombreRemC
        '
        Me.lblNombreRemC.AutoSize = True
        Me.lblNombreRemC.BackColor = System.Drawing.Color.White
        Me.lblNombreRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblNombreRemC.Location = New System.Drawing.Point(105, 145)
        Me.lblNombreRemC.Name = "lblNombreRemC"
        Me.lblNombreRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblNombreRemC.TabIndex = 9
        Me.lblNombreRemC.Text = "-"
        '
        'lblTelRemC
        '
        Me.lblTelRemC.AutoSize = True
        Me.lblTelRemC.BackColor = System.Drawing.Color.White
        Me.lblTelRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTelRemC.Location = New System.Drawing.Point(383, 136)
        Me.lblTelRemC.Name = "lblTelRemC"
        Me.lblTelRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblTelRemC.TabIndex = 10
        Me.lblTelRemC.Text = "-"
        '
        'lblCPRemC
        '
        Me.lblCPRemC.AutoSize = True
        Me.lblCPRemC.BackColor = System.Drawing.Color.White
        Me.lblCPRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCPRemC.Location = New System.Drawing.Point(354, 156)
        Me.lblCPRemC.Name = "lblCPRemC"
        Me.lblCPRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblCPRemC.TabIndex = 11
        Me.lblCPRemC.Text = "-"
        '
        'lblProvinciaRemC
        '
        Me.lblProvinciaRemC.AutoSize = True
        Me.lblProvinciaRemC.BackColor = System.Drawing.Color.White
        Me.lblProvinciaRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProvinciaRemC.Location = New System.Drawing.Point(383, 175)
        Me.lblProvinciaRemC.Name = "lblProvinciaRemC"
        Me.lblProvinciaRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblProvinciaRemC.TabIndex = 12
        Me.lblProvinciaRemC.Text = "-"
        '
        'lblCodigoRemC
        '
        Me.lblCodigoRemC.AutoSize = True
        Me.lblCodigoRemC.BackColor = System.Drawing.Color.White
        Me.lblCodigoRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodigoRemC.Location = New System.Drawing.Point(549, 34)
        Me.lblCodigoRemC.Name = "lblCodigoRemC"
        Me.lblCodigoRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblCodigoRemC.TabIndex = 18
        Me.lblCodigoRemC.Text = "-"
        '
        'lblFechaRemC
        '
        Me.lblFechaRemC.AutoSize = True
        Me.lblFechaRemC.BackColor = System.Drawing.Color.White
        Me.lblFechaRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFechaRemC.Location = New System.Drawing.Point(561, 60)
        Me.lblFechaRemC.Name = "lblFechaRemC"
        Me.lblFechaRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblFechaRemC.TabIndex = 19
        Me.lblFechaRemC.Text = "-"
        '
        'lbl2RemC
        '
        Me.lbl2RemC.AutoSize = True
        Me.lbl2RemC.BackColor = System.Drawing.Color.White
        Me.lbl2RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2RemC.Location = New System.Drawing.Point(122, 242)
        Me.lbl2RemC.Name = "lbl2RemC"
        Me.lbl2RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl2RemC.TabIndex = 26
        Me.lbl2RemC.Text = "-"
        '
        'lbl1RemC
        '
        Me.lbl1RemC.AutoSize = True
        Me.lbl1RemC.BackColor = System.Drawing.Color.White
        Me.lbl1RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1RemC.Location = New System.Drawing.Point(47, 242)
        Me.lbl1RemC.Name = "lbl1RemC"
        Me.lbl1RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl1RemC.TabIndex = 27
        Me.lbl1RemC.Text = "-"
        '
        'lbl4RemC
        '
        Me.lbl4RemC.AutoSize = True
        Me.lbl4RemC.BackColor = System.Drawing.Color.White
        Me.lbl4RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4RemC.Location = New System.Drawing.Point(47, 271)
        Me.lbl4RemC.Name = "lbl4RemC"
        Me.lbl4RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl4RemC.TabIndex = 28
        Me.lbl4RemC.Text = "-"
        '
        'lbl7RemC
        '
        Me.lbl7RemC.AutoSize = True
        Me.lbl7RemC.BackColor = System.Drawing.Color.White
        Me.lbl7RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl7RemC.Location = New System.Drawing.Point(47, 299)
        Me.lbl7RemC.Name = "lbl7RemC"
        Me.lbl7RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl7RemC.TabIndex = 29
        Me.lbl7RemC.Text = "-"
        '
        'lbl10RemC
        '
        Me.lbl10RemC.AutoSize = True
        Me.lbl10RemC.BackColor = System.Drawing.Color.White
        Me.lbl10RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10RemC.Location = New System.Drawing.Point(47, 327)
        Me.lbl10RemC.Name = "lbl10RemC"
        Me.lbl10RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl10RemC.TabIndex = 30
        Me.lbl10RemC.Text = "-"
        '
        'lbl13RemC
        '
        Me.lbl13RemC.AutoSize = True
        Me.lbl13RemC.BackColor = System.Drawing.Color.White
        Me.lbl13RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl13RemC.Location = New System.Drawing.Point(47, 355)
        Me.lbl13RemC.Name = "lbl13RemC"
        Me.lbl13RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl13RemC.TabIndex = 31
        Me.lbl13RemC.Text = "-"
        '
        'lbl16RemC
        '
        Me.lbl16RemC.AutoSize = True
        Me.lbl16RemC.BackColor = System.Drawing.Color.White
        Me.lbl16RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl16RemC.Location = New System.Drawing.Point(47, 383)
        Me.lbl16RemC.Name = "lbl16RemC"
        Me.lbl16RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl16RemC.TabIndex = 32
        Me.lbl16RemC.Text = "-"
        '
        'lbl19RemC
        '
        Me.lbl19RemC.AutoSize = True
        Me.lbl19RemC.BackColor = System.Drawing.Color.White
        Me.lbl19RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl19RemC.Location = New System.Drawing.Point(47, 412)
        Me.lbl19RemC.Name = "lbl19RemC"
        Me.lbl19RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl19RemC.TabIndex = 33
        Me.lbl19RemC.Text = "-"
        '
        'lbl5RemC
        '
        Me.lbl5RemC.AutoSize = True
        Me.lbl5RemC.BackColor = System.Drawing.Color.White
        Me.lbl5RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl5RemC.Location = New System.Drawing.Point(122, 271)
        Me.lbl5RemC.Name = "lbl5RemC"
        Me.lbl5RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl5RemC.TabIndex = 34
        Me.lbl5RemC.Text = "-"
        '
        'lbl8RemC
        '
        Me.lbl8RemC.AutoSize = True
        Me.lbl8RemC.BackColor = System.Drawing.Color.White
        Me.lbl8RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl8RemC.Location = New System.Drawing.Point(122, 299)
        Me.lbl8RemC.Name = "lbl8RemC"
        Me.lbl8RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl8RemC.TabIndex = 35
        Me.lbl8RemC.Text = "-"
        '
        'lbl11RemC
        '
        Me.lbl11RemC.AutoSize = True
        Me.lbl11RemC.BackColor = System.Drawing.Color.White
        Me.lbl11RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl11RemC.Location = New System.Drawing.Point(122, 327)
        Me.lbl11RemC.Name = "lbl11RemC"
        Me.lbl11RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl11RemC.TabIndex = 36
        Me.lbl11RemC.Text = "-"
        '
        'lbl14RemC
        '
        Me.lbl14RemC.AutoSize = True
        Me.lbl14RemC.BackColor = System.Drawing.Color.White
        Me.lbl14RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl14RemC.Location = New System.Drawing.Point(122, 355)
        Me.lbl14RemC.Name = "lbl14RemC"
        Me.lbl14RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl14RemC.TabIndex = 37
        Me.lbl14RemC.Text = "-"
        '
        'lbl17RemC
        '
        Me.lbl17RemC.AutoSize = True
        Me.lbl17RemC.BackColor = System.Drawing.Color.White
        Me.lbl17RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl17RemC.Location = New System.Drawing.Point(122, 383)
        Me.lbl17RemC.Name = "lbl17RemC"
        Me.lbl17RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl17RemC.TabIndex = 38
        Me.lbl17RemC.Text = "-"
        '
        'lbl20RemC
        '
        Me.lbl20RemC.AutoSize = True
        Me.lbl20RemC.BackColor = System.Drawing.Color.White
        Me.lbl20RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl20RemC.Location = New System.Drawing.Point(122, 412)
        Me.lbl20RemC.Name = "lbl20RemC"
        Me.lbl20RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl20RemC.TabIndex = 39
        Me.lbl20RemC.Text = "-"
        '
        'lbl3RemC
        '
        Me.lbl3RemC.AutoSize = True
        Me.lbl3RemC.BackColor = System.Drawing.Color.White
        Me.lbl3RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3RemC.Location = New System.Drawing.Point(533, 242)
        Me.lbl3RemC.Name = "lbl3RemC"
        Me.lbl3RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl3RemC.TabIndex = 40
        Me.lbl3RemC.Text = "-"
        '
        'lbl6RemC
        '
        Me.lbl6RemC.AutoSize = True
        Me.lbl6RemC.BackColor = System.Drawing.Color.White
        Me.lbl6RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl6RemC.Location = New System.Drawing.Point(533, 271)
        Me.lbl6RemC.Name = "lbl6RemC"
        Me.lbl6RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl6RemC.TabIndex = 41
        Me.lbl6RemC.Text = "-"
        '
        'lbl9RemC
        '
        Me.lbl9RemC.AutoSize = True
        Me.lbl9RemC.BackColor = System.Drawing.Color.White
        Me.lbl9RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl9RemC.Location = New System.Drawing.Point(533, 299)
        Me.lbl9RemC.Name = "lbl9RemC"
        Me.lbl9RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl9RemC.TabIndex = 42
        Me.lbl9RemC.Text = "-"
        '
        'lbl12RemC
        '
        Me.lbl12RemC.AutoSize = True
        Me.lbl12RemC.BackColor = System.Drawing.Color.White
        Me.lbl12RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl12RemC.Location = New System.Drawing.Point(533, 327)
        Me.lbl12RemC.Name = "lbl12RemC"
        Me.lbl12RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl12RemC.TabIndex = 43
        Me.lbl12RemC.Text = "-"
        '
        'lbl15RemC
        '
        Me.lbl15RemC.AutoSize = True
        Me.lbl15RemC.BackColor = System.Drawing.Color.White
        Me.lbl15RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl15RemC.Location = New System.Drawing.Point(533, 355)
        Me.lbl15RemC.Name = "lbl15RemC"
        Me.lbl15RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl15RemC.TabIndex = 44
        Me.lbl15RemC.Text = "-"
        '
        'lbl18RemC
        '
        Me.lbl18RemC.AutoSize = True
        Me.lbl18RemC.BackColor = System.Drawing.Color.White
        Me.lbl18RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl18RemC.Location = New System.Drawing.Point(533, 383)
        Me.lbl18RemC.Name = "lbl18RemC"
        Me.lbl18RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl18RemC.TabIndex = 45
        Me.lbl18RemC.Text = "-"
        '
        'lbl21RemC
        '
        Me.lbl21RemC.AutoSize = True
        Me.lbl21RemC.BackColor = System.Drawing.Color.White
        Me.lbl21RemC.Font = New System.Drawing.Font("ISOCPEUR", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl21RemC.Location = New System.Drawing.Point(533, 412)
        Me.lbl21RemC.Name = "lbl21RemC"
        Me.lbl21RemC.Size = New System.Drawing.Size(16, 19)
        Me.lbl21RemC.TabIndex = 46
        Me.lbl21RemC.Text = "-"
        '
        'lblCodClienteRemC
        '
        Me.lblCodClienteRemC.AutoSize = True
        Me.lblCodClienteRemC.BackColor = System.Drawing.Color.White
        Me.lblCodClienteRemC.Font = New System.Drawing.Font("ISOCPEUR", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCodClienteRemC.Location = New System.Drawing.Point(524, 136)
        Me.lblCodClienteRemC.Name = "lblCodClienteRemC"
        Me.lblCodClienteRemC.Size = New System.Drawing.Size(12, 15)
        Me.lblCodClienteRemC.TabIndex = 47
        Me.lblCodClienteRemC.Text = "-"
        '
        'grdREMC
        '
        Me.grdREMC.AllowUserToAddRows = False
        Me.grdREMC.AllowUserToDeleteRows = False
        Me.grdREMC.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdREMC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdREMC.Location = New System.Drawing.Point(12, 214)
        Me.grdREMC.Name = "grdREMC"
        Me.grdREMC.ReadOnly = True
        Me.grdREMC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdREMC.Size = New System.Drawing.Size(640, 232)
        Me.grdREMC.TabIndex = 84
        '
        'btnSalirREMC
        '
        Me.btnSalirREMC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalirREMC.Location = New System.Drawing.Point(178, 569)
        Me.btnSalirREMC.Name = "btnSalirREMC"
        Me.btnSalirREMC.Size = New System.Drawing.Size(141, 39)
        Me.btnSalirREMC.TabIndex = 86
        Me.btnSalirREMC.Text = "Salir"
        Me.btnSalirREMC.UseVisualStyleBackColor = True
        '
        'btn1REMC
        '
        Me.btn1REMC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1REMC.Location = New System.Drawing.Point(31, 569)
        Me.btn1REMC.Name = "btn1REMC"
        Me.btn1REMC.Size = New System.Drawing.Size(141, 39)
        Me.btn1REMC.TabIndex = 85
        Me.btn1REMC.Text = "Imprimir"
        Me.btn1REMC.UseVisualStyleBackColor = True
        '
        'prf1REMC
        '
        Me.prf1REMC.DocumentName = "document"
        Me.prf1REMC.Form = Me
        Me.prf1REMC.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.prf1REMC.PrinterSettings = CType(resources.GetObject("prf1REMC.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.prf1REMC.PrintFileName = Nothing
        '
        'RemitoCliente
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(664, 608)
        Me.Controls.Add(Me.btnSalirREMC)
        Me.Controls.Add(Me.btn1REMC)
        Me.Controls.Add(Me.grdREMC)
        Me.Controls.Add(Me.lblCodClienteRemC)
        Me.Controls.Add(Me.lbl21RemC)
        Me.Controls.Add(Me.lbl18RemC)
        Me.Controls.Add(Me.lbl15RemC)
        Me.Controls.Add(Me.lbl12RemC)
        Me.Controls.Add(Me.lbl9RemC)
        Me.Controls.Add(Me.lbl6RemC)
        Me.Controls.Add(Me.lbl3RemC)
        Me.Controls.Add(Me.lbl20RemC)
        Me.Controls.Add(Me.lbl17RemC)
        Me.Controls.Add(Me.lbl14RemC)
        Me.Controls.Add(Me.lbl11RemC)
        Me.Controls.Add(Me.lbl8RemC)
        Me.Controls.Add(Me.lbl5RemC)
        Me.Controls.Add(Me.lbl19RemC)
        Me.Controls.Add(Me.lbl16RemC)
        Me.Controls.Add(Me.lbl13RemC)
        Me.Controls.Add(Me.lbl10RemC)
        Me.Controls.Add(Me.lbl7RemC)
        Me.Controls.Add(Me.lbl4RemC)
        Me.Controls.Add(Me.lbl1RemC)
        Me.Controls.Add(Me.lbl2RemC)
        Me.Controls.Add(Me.lblFechaRemC)
        Me.Controls.Add(Me.lblCodigoRemC)
        Me.Controls.Add(Me.lblProvinciaRemC)
        Me.Controls.Add(Me.lblCPRemC)
        Me.Controls.Add(Me.lblTelRemC)
        Me.Controls.Add(Me.lblNombreRemC)
        Me.Controls.Add(Me.lblDireccionRemC)
        Me.Controls.Add(Me.lblLocalidadRemC)
        Me.Controls.Add(Me.pcb1RemitoC)
        Me.Name = "RemitoCliente"
        Me.Text = "REMITO CLIENTE"
        CType(Me.pcb1RemitoC, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdREMC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pcb1RemitoC As System.Windows.Forms.PictureBox
    Friend WithEvents lblLocalidadRemC As System.Windows.Forms.Label
    Friend WithEvents lblDireccionRemC As System.Windows.Forms.Label
    Friend WithEvents lblNombreRemC As System.Windows.Forms.Label
    Friend WithEvents lblTelRemC As System.Windows.Forms.Label
    Friend WithEvents lblCPRemC As System.Windows.Forms.Label
    Friend WithEvents lblProvinciaRemC As System.Windows.Forms.Label
    Friend WithEvents lblCodigoRemC As System.Windows.Forms.Label
    Friend WithEvents lblFechaRemC As System.Windows.Forms.Label
    Friend WithEvents lbl2RemC As System.Windows.Forms.Label
    Friend WithEvents lbl1RemC As System.Windows.Forms.Label
    Friend WithEvents lbl4RemC As System.Windows.Forms.Label
    Friend WithEvents lbl7RemC As System.Windows.Forms.Label
    Friend WithEvents lbl10RemC As System.Windows.Forms.Label
    Friend WithEvents lbl13RemC As System.Windows.Forms.Label
    Friend WithEvents lbl16RemC As System.Windows.Forms.Label
    Friend WithEvents lbl19RemC As System.Windows.Forms.Label
    Friend WithEvents lbl5RemC As System.Windows.Forms.Label
    Friend WithEvents lbl8RemC As System.Windows.Forms.Label
    Friend WithEvents lbl11RemC As System.Windows.Forms.Label
    Friend WithEvents lbl14RemC As System.Windows.Forms.Label
    Friend WithEvents lbl17RemC As System.Windows.Forms.Label
    Friend WithEvents lbl20RemC As System.Windows.Forms.Label
    Friend WithEvents lbl3RemC As System.Windows.Forms.Label
    Friend WithEvents lbl6RemC As System.Windows.Forms.Label
    Friend WithEvents lbl9RemC As System.Windows.Forms.Label
    Friend WithEvents lbl12RemC As System.Windows.Forms.Label
    Friend WithEvents lbl15RemC As System.Windows.Forms.Label
    Friend WithEvents lbl18RemC As System.Windows.Forms.Label
    Friend WithEvents lbl21RemC As System.Windows.Forms.Label
    Friend WithEvents lblCodClienteRemC As System.Windows.Forms.Label
    Friend WithEvents grdREMC As System.Windows.Forms.DataGridView
    Friend WithEvents btnSalirREMC As System.Windows.Forms.Button
    Friend WithEvents btn1REMC As System.Windows.Forms.Button
    Friend WithEvents prf1REMC As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
End Class
