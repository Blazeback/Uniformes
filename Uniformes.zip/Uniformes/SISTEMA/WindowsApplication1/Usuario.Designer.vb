﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Usuario
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.txt1U = New System.Windows.Forms.TextBox()
        Me.lbl1U = New System.Windows.Forms.Label()
        Me.lbl2C = New System.Windows.Forms.Label()
        Me.lbl3U = New System.Windows.Forms.Label()
        Me.txt2U = New System.Windows.Forms.TextBox()
        Me.btnSalirU = New System.Windows.Forms.Button()
        Me.btn1U = New System.Windows.Forms.Button()
        Me.cbm1U = New System.Windows.Forms.ComboBox()
        Me.lbl6U = New System.Windows.Forms.Label()
        Me.lbl4U = New System.Windows.Forms.Label()
        Me.lbl5U = New System.Windows.Forms.Label()
        Me.lbl7U = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(290, 307)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(6, 6)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(278, 290)
        '
        'txt1U
        '
        Me.txt1U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt1U.Location = New System.Drawing.Point(25, 48)
        Me.txt1U.Name = "txt1U"
        Me.txt1U.Size = New System.Drawing.Size(121, 31)
        Me.txt1U.TabIndex = 13
        '
        'lbl1U
        '
        Me.lbl1U.AutoSize = True
        Me.lbl1U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1U.Location = New System.Drawing.Point(22, 21)
        Me.lbl1U.Name = "lbl1U"
        Me.lbl1U.Size = New System.Drawing.Size(67, 23)
        Me.lbl1U.TabIndex = 12
        Me.lbl1U.Text = "Usuario"
        '
        'lbl2C
        '
        Me.lbl2C.AutoSize = True
        Me.lbl2C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2C.Location = New System.Drawing.Point(22, 96)
        Me.lbl2C.Name = "lbl2C"
        Me.lbl2C.Size = New System.Drawing.Size(96, 23)
        Me.lbl2C.TabIndex = 14
        Me.lbl2C.Text = "Contraseña"
        '
        'lbl3U
        '
        Me.lbl3U.AutoSize = True
        Me.lbl3U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3U.Location = New System.Drawing.Point(21, 175)
        Me.lbl3U.Name = "lbl3U"
        Me.lbl3U.Size = New System.Drawing.Size(59, 23)
        Me.lbl3U.TabIndex = 15
        Me.lbl3U.Text = "Sector"
        '
        'txt2U
        '
        Me.txt2U.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.txt2U.Location = New System.Drawing.Point(26, 123)
        Me.txt2U.Name = "txt2U"
        Me.txt2U.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt2U.Size = New System.Drawing.Size(121, 29)
        Me.txt2U.TabIndex = 16
        '
        'btnSalirU
        '
        Me.btnSalirU.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnSalirU.Location = New System.Drawing.Point(148, 250)
        Me.btnSalirU.Name = "btnSalirU"
        Me.btnSalirU.Size = New System.Drawing.Size(104, 39)
        Me.btnSalirU.TabIndex = 19
        Me.btnSalirU.Text = "Cancelar"
        Me.btnSalirU.UseVisualStyleBackColor = True
        '
        'btn1U
        '
        Me.btn1U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1U.Location = New System.Drawing.Point(26, 250)
        Me.btn1U.Name = "btn1U"
        Me.btn1U.Size = New System.Drawing.Size(104, 39)
        Me.btn1U.TabIndex = 18
        Me.btn1U.Text = "Ingresar"
        Me.btn1U.UseVisualStyleBackColor = True
        '
        'cbm1U
        '
        Me.cbm1U.AllowDrop = True
        Me.cbm1U.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm1U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm1U.FormattingEnabled = True
        Me.cbm1U.Location = New System.Drawing.Point(25, 202)
        Me.cbm1U.Name = "cbm1U"
        Me.cbm1U.Size = New System.Drawing.Size(140, 31)
        Me.cbm1U.TabIndex = 22
        '
        'lbl6U
        '
        Me.lbl6U.AutoSize = True
        Me.lbl6U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl6U.ForeColor = System.Drawing.Color.Red
        Me.lbl6U.Location = New System.Drawing.Point(177, 142)
        Me.lbl6U.Name = "lbl6U"
        Me.lbl6U.Size = New System.Drawing.Size(80, 23)
        Me.lbl6U.TabIndex = 25
        Me.lbl6U.Text = "CERRADA"
        Me.lbl6U.Visible = False
        '
        'lbl4U
        '
        Me.lbl4U.AutoSize = True
        Me.lbl4U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4U.Location = New System.Drawing.Point(170, 96)
        Me.lbl4U.Name = "lbl4U"
        Me.lbl4U.Size = New System.Drawing.Size(87, 23)
        Me.lbl4U.TabIndex = 23
        Me.lbl4U.Text = "Estado de"
        '
        'lbl5U
        '
        Me.lbl5U.AutoSize = True
        Me.lbl5U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5U.Location = New System.Drawing.Point(170, 119)
        Me.lbl5U.Name = "lbl5U"
        Me.lbl5U.Size = New System.Drawing.Size(100, 23)
        Me.lbl5U.TabIndex = 24
        Me.lbl5U.Text = "la conexión:"
        '
        'lbl7U
        '
        Me.lbl7U.AutoSize = True
        Me.lbl7U.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl7U.ForeColor = System.Drawing.Color.Green
        Me.lbl7U.Location = New System.Drawing.Point(177, 142)
        Me.lbl7U.Name = "lbl7U"
        Me.lbl7U.Size = New System.Drawing.Size(75, 23)
        Me.lbl7U.TabIndex = 26
        Me.lbl7U.Text = "ABIERTA"
        Me.lbl7U.Visible = False
        '
        'Usuario
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(290, 307)
        Me.Controls.Add(Me.lbl7U)
        Me.Controls.Add(Me.lbl6U)
        Me.Controls.Add(Me.lbl4U)
        Me.Controls.Add(Me.lbl5U)
        Me.Controls.Add(Me.cbm1U)
        Me.Controls.Add(Me.btnSalirU)
        Me.Controls.Add(Me.btn1U)
        Me.Controls.Add(Me.txt2U)
        Me.Controls.Add(Me.lbl3U)
        Me.Controls.Add(Me.lbl2C)
        Me.Controls.Add(Me.txt1U)
        Me.Controls.Add(Me.lbl1U)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Usuario"
        Me.Text = "USUARIO"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents txt1U As System.Windows.Forms.TextBox
    Friend WithEvents lbl1U As System.Windows.Forms.Label
    Friend WithEvents lbl2C As System.Windows.Forms.Label
    Friend WithEvents lbl3U As System.Windows.Forms.Label
    Friend WithEvents txt2U As System.Windows.Forms.TextBox
    Friend WithEvents btnSalirU As System.Windows.Forms.Button
    Friend WithEvents btn1U As System.Windows.Forms.Button
    Friend WithEvents lbl6U As System.Windows.Forms.Label
    Friend WithEvents lbl4U As System.Windows.Forms.Label
    Friend WithEvents lbl5U As System.Windows.Forms.Label
    Friend WithEvents lbl7U As System.Windows.Forms.Label
    Friend WithEvents cbm1U As System.Windows.Forms.ComboBox
End Class
