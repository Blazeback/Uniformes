﻿Imports System.Data.Odbc
Public Class AEProveedores
    Private Sub rb2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2.CheckedChanged
        If rb2.Checked = True Then
            msk2.Enabled = False
            msk3.Enabled = False
            msk4.Enabled = False
            txt1.Enabled = False
            txt2.Enabled = False
            grb2.Enabled = False
        End If
    End Sub

    Private Sub rb1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1.CheckedChanged
        If rb1.Checked = True Then
            msk2.Enabled = True
            msk3.Enabled = True
            msk4.Enabled = True
            txt1.Enabled = True
            txt2.Enabled = True
            grb2.Enabled = True
        End If
    End Sub

    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        Call conexion()
        Dim b As Integer
        Dim b2 As Integer
        Dim tProv As String
        If rb1.Checked = True Then
            If msk1.Text = "" Or msk2.Text = "" Or msk3.Text = "" Or msk4.Text = "" Or txt1.Text = "" Or txt2.Text = "" Then
                MsgBox("Usted a dejado campos sin completar", MsgBoxStyle.Exclamation, "ERROR")
                b = 1
            Else
                If rb3.Checked = False And rb4.Checked = False Then
                    MsgBox("Usted a dejado campos sin completar", MsgBoxStyle.Exclamation, "ERROR")
                    b = 1
                End If
            End If
            If b <> 0 Then
                If rb3.Checked = True Then
                    tProv = "bordado"
                    b2 = 1
                Else
                    tProv = "materiales"
                    b2 = 2
                End If
                sql = "Insert Into proveedor Values ('', " & Trim(msk3.Text) & ", " & Trim(msk1.Text) & ", " & Trim(msk2.Text) & ", " & txt1.Text & ", " & txt2.Text & ", " & tProv & ", " & Trim(msk4.Text) & " false)"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
            End If
        Else
            If rb2.Checked = True Then
                If msk1.Text = "" Then
                    MsgBox("Usted a dejado campos sin completar", MsgBoxStyle.Exclamation, "ERROR")
                    b = 1
                Else
                    sql = "update proveedor set borrado=true where numCuit = " & Trim(msk1.Text)
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
            Else
                MsgBox("Usted a dejado campos sin completar", MsgBoxStyle.Exclamation, "ERROR")
                b = 1
            End If
        End If

        If b <> 1 Then
            Me.Hide()
            If b2 = 0 Then
                MsgBox("¡El proveedor a sido eliminado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
                Control.Show()
            Else
                If b2 = 1 Then
                    PBordado.Show()
                Else
                    PMateriales.Show()
                End If
            End If
        End If
        b = 0
        b2 = 0
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        msk1.Clear()
        msk2.Clear()
        msk3.Clear()
        msk4.Clear()
        txt1.Clear()
        txt2.Clear()
        rb1.Checked = False
        rb2.Checked = False
        rb3.Checked = False
        rb4.Checked = False
        Me.Hide()
        Control.Show()
    End Sub
End Class