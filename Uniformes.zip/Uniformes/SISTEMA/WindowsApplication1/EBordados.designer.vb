﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EBordados
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grd1B = New System.Windows.Forms.DataGridView()
        Me.grd2B = New System.Windows.Forms.DataGridView()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lst1 = New System.Windows.Forms.ListBox()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.lst2 = New System.Windows.Forms.ListBox()
        CType(Me.grd1B, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grd2B, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grd1B
        '
        Me.grd1B.AllowUserToAddRows = False
        Me.grd1B.AllowUserToDeleteRows = False
        Me.grd1B.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd1B.Location = New System.Drawing.Point(24, 36)
        Me.grd1B.Name = "grd1B"
        Me.grd1B.ReadOnly = True
        Me.grd1B.Size = New System.Drawing.Size(455, 150)
        Me.grd1B.TabIndex = 0
        '
        'grd2B
        '
        Me.grd2B.AllowUserToAddRows = False
        Me.grd2B.AllowUserToDeleteRows = False
        Me.grd2B.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd2B.Location = New System.Drawing.Point(24, 216)
        Me.grd2B.Name = "grd2B"
        Me.grd2B.ReadOnly = True
        Me.grd2B.Size = New System.Drawing.Size(455, 150)
        Me.grd2B.TabIndex = 1
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(20, 9)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(185, 24)
        Me.lbl1.TabIndex = 2
        Me.lbl1.Text = "Seleccione el pedido"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2.Location = New System.Drawing.Point(20, 189)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(216, 24)
        Me.lbl2.TabIndex = 3
        Me.lbl2.Text = "Seleccione el proveedor"
        '
        'lst1
        '
        Me.lst1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lst1.FormattingEnabled = True
        Me.lst1.ItemHeight = 24
        Me.lst1.Location = New System.Drawing.Point(24, 372)
        Me.lst1.Name = "lst1"
        Me.lst1.Size = New System.Drawing.Size(455, 52)
        Me.lst1.TabIndex = 4
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(273, 490)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(100, 35)
        Me.btn1.TabIndex = 5
        Me.btn1.Text = "Continuar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(379, 490)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(100, 35)
        Me.btn2.TabIndex = 6
        Me.btn2.Text = "Cancelar"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'lst2
        '
        Me.lst2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lst2.FormattingEnabled = True
        Me.lst2.ItemHeight = 24
        Me.lst2.Location = New System.Drawing.Point(24, 430)
        Me.lst2.Name = "lst2"
        Me.lst2.Size = New System.Drawing.Size(455, 52)
        Me.lst2.TabIndex = 7
        '
        'EBordados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(502, 537)
        Me.Controls.Add(Me.lst2)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.lst1)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.grd2B)
        Me.Controls.Add(Me.grd1B)
        Me.Name = "EBordados"
        Me.Text = "BORDADOS"
        CType(Me.grd1B, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grd2B, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grd1B As System.Windows.Forms.DataGridView
    Friend WithEvents grd2B As System.Windows.Forms.DataGridView
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lst1 As System.Windows.Forms.ListBox
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents lst2 As System.Windows.Forms.ListBox
End Class
