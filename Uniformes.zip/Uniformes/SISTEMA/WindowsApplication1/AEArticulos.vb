﻿Imports System.Data.Odbc
Public Class AEArticulos
    Dim nombre As String
    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        Call conexion()
        nombre = txt1.Text
        sql = "Select Count(*) From colores Where nombre='" & nombre & "' And borrado = false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If txt1.Text = "" Then
            MsgBox("No ingreso datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Update almacen Set borrado=1 Where nombre='" & nombre & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    MsgBox("¡El articulo ha sido eliminado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
                Else
                    btn3.Enabled = True
                    msk1.Enabled = True
                    lbl2.Visible = True
                    btn3.Visible = True
                    msk1.Visible = True
                    btn1.Enabled = False
                End If
            End If
        End If
    End Sub

    Private Sub btn3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3.Click
        If msk1.Text = "" Then
            MsgBox("Faltan ingreso datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            sql = "Insert into almacen Values ('', '" & nombre & "', " & Trim(msk1.Text) & ", false)"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            MsgBox("¡El articulo ha sido cargado exitosamente!.", MsgBoxStyle.Exclamation, "EXITO")
            txt1.Clear()
            msk1.Clear()
            lbl2.Visible = False
            btn3.Enabled = False
            msk1.Enabled = False
            btn3.Visible = False
            msk1.Visible = False
            btn1.Enabled = True
            Me.Hide()
            Control.Show()
        End If
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        txt1.Clear()
        msk1.Clear()
        lbl2.Visible = False
        btn3.Enabled = False
        msk1.Enabled = False
        btn3.Visible = False
        msk1.Visible = False
        btn1.Enabled = True
        Me.Hide()
        Control.Show()
    End Sub
End Class