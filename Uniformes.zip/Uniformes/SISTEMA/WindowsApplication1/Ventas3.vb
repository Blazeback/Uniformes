﻿Imports System.Data.Odbc
Imports System.Globalization

Public Class Ventas3
    Dim b As Integer
    Dim contador As Integer
    Dim codrt As Integer
    Dim codrtc As Integer
    Dim banderadetallecam As String
    Dim manguita As String
    Dim preciouncam As Integer
    Dim bbolsillo As Integer
    Dim bcuellov As Integer
    Dim bchomba As Integer
    Dim bbolsillos As Integer
    Dim belastico As Integer
    Dim bcordon As Integer
    Dim bcierre As Integer
    Dim bbolsillosint As Integer
    Dim bcapucha As Integer
    Dim bdetalle As Integer

    Private Sub btnCancelarV3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarV3.Click
        chkShorV3.Checked = False
        chkCamperaV3.Checked = False
        chkBuzoV3.Checked = False
        chkBuzoEV3.Checked = False

        If contador > 0 Then
            sql = "DELETE FROM NP WHERE idNP='" & npglobal & "' AND (articulo LIKE 'Short%' OR articulo LIKE 'Buzo%' OR articulo LIKE 'Campera%')"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()

            sql = "CALL contador('" & contador & "', '" & npglobal & "')"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
        End If

        Me.Hide()
        Ventas2.Show()
    End Sub

    Private Sub chkShorV2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkShorV3.CheckedChanged
        If chkShorV3.Checked = True Then
            grbShV3.Visible = True
        Else
            grbShV3.Visible = False
            grb1V3.Visible = False
            msk1V3.Enabled = False
            msk1V3.Text = ""
            msk2V3.Enabled = False
            msk2V3.Text = ""
            msk3V3.Enabled = False
            msk3V3.Text = ""
            msk4V3.Enabled = False
            msk4V3.Text = ""
            cbm1V3.SelectedIndex = -1
            chk1V3.Checked = False
            chk2V3.Checked = False
            chk3V3.Checked = False
            chk4V3.Checked = False
            chk5V3.Checked = False
            rb1V3.Checked = False
            rb2V3.Checked = False
            rb4V3.Checked = False
            rb5V3.Checked = False
        End If
    End Sub

    Private Sub chkBuzoV2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBuzoV3.CheckedChanged
        If chkBuzoV3.Checked = True Then
            grbBuzoV3.Visible = True
        Else
            grbBuzoV3.Visible = False
            grb2V3.Visible = False
            rb6V3.Checked = False
            rb7V3.Checked = False
            rb8V3.Checked = False
            rb9V3.Checked = False
            chk6V3.Checked = False
            chk7V3.Checked = False
            chk8V3.Checked = False
            chk9V3.Checked = False
            chk10V3.Checked = False
            chk11V3.Checked = False
            chk12V3.Checked = False
            msk1V3.Enabled = False
            msk5V3.Enabled = False
            msk5V3.Text = ""
            msk6V3.Enabled = False
            msk6V3.Text = ""
            msk7V3.Enabled = False
            msk7V3.Text = ""
            msk8V3.Enabled = False
            msk8V3.Text = ""
            cbm2V3.SelectedIndex = -1
        End If
    End Sub

    Private Sub rb1V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1V3.CheckedChanged
        If rb1V3.Checked = True Then
            grb1V3.Visible = False
            chk5V3.Checked = False
            rb4V3.Checked = False
            rb5V3.Checked = False
        End If
    End Sub

    Private Sub rb6V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb6V3.CheckedChanged
        If rb6V3.Checked = True Then
            grb2V3.Visible = False
            chk10V3.Checked = False
            chk11V3.Checked = False
            chk12V3.Checked = False
            rb8V3.Checked = False
            rb9V3.Checked = False
        End If
    End Sub

    Private Sub chkBuzoEV3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkBuzoEV3.CheckedChanged
        If chkBuzoEV3.Checked = True Then
            grbBuzoEV3.Visible = True
        Else
            grbBuzoEV3.Visible = False
            grb3V3.Visible = False
            msk9V3.Text = ""
            msk10V3.Enabled = False
            msk10V3.Text = ""
            msk11V3.Enabled = False
            msk11V3.Text = ""
            msk12V3.Enabled = False
            msk12V3.Text = ""
            cbm3V3.SelectedIndex = -1
            rb10V3.Checked = False
            rb11V3.Checked = False
            rb12V3.Checked = False
            rb13V3.Checked = False
            chk13V3.Checked = False
            chk14V3.Checked = False
            chk15V3.Checked = False
            chk16V3.Checked = False
            chk17V3.Checked = False
            chk18V3.Checked = False
            chk19V3.Checked = False
        End If
    End Sub

    Private Sub rb12V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb10V3.CheckedChanged
        If rb10V3.Checked = True Then
            grb3V3.Visible = False
            chk17V3.Checked = False
            chk18V3.Checked = False
            chk19V3.Checked = False
            rb12V3.Checked = False
            rb13V3.Checked = False 
        End If
    End Sub

    Private Sub chkCamperaV3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCamperaV3.CheckedChanged
        If chkCamperaV3.Checked = True Then
            grbCamperV3.Visible = True
        Else
            grbCamperV3.Visible = False
            grb4V3.Visible = False
            msk13V3.Enabled = False
            msk13V3.Text = ""
            msk14V3.Enabled = False
            msk14V3.Text = ""
            msk15V3.Enabled = False
            msk15V3.Text = ""
            msk16V3.Enabled = False
            msk16V3.Text = ""
            cbm4V3.SelectedIndex = -1
            chk20V3.Checked = False
            chk21V3.Checked = False
            chk22V3.Checked = False
            chk23V3.Checked = False
            chk24V3.Checked = False
            chk25V3.Checked = False
            chk26V3.Checked = False
            rb14V3.Checked = False
            rb15V3.Checked = False
            rb16V3.Checked = False
            rb17V3.Checked = False
        End If
    End Sub

    Private Sub rb18V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb14V3.CheckedChanged
        If rb14V3.Checked = True Then
            grb4V3.Visible = False
            chk24V3.Checked = False
            chk25V3.Checked = False
            chk26V3.Checked = False
            rb16V3.Checked = False
            rb17V3.Checked = False
        End If
    End Sub

    Private Sub chk1V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk1V3.CheckedChanged
        If chk1V3.Checked = True Then
            msk1V3.Enabled = True
        Else
            msk1V3.Enabled = False
            msk1V3.Text = ""
        End If
    End Sub

    Private Sub chk2V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk2V3.CheckedChanged
        If chk2V3.Checked = True Then
            msk2V3.Enabled = True
        Else
            msk2V3.Enabled = False
            msk2V3.Text = ""
        End If
    End Sub

    Private Sub chk3V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk3V3.CheckedChanged
        If chk3V3.Checked = True Then
            msk3V3.Enabled = True
        Else
            msk3V3.Enabled = False
            msk3V3.Text = ""
        End If
    End Sub

    Private Sub chk4V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk4V3.CheckedChanged
        If chk4V3.Checked = True Then
            msk4V3.Enabled = True
        Else
            msk4V3.Enabled = False
            msk4V3.Text = ""
        End If
    End Sub

    Private Sub chk6V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk6V3.CheckedChanged
        If chk6V3.Checked = True Then
            msk5V3.Enabled = True
        Else
            msk5V3.Enabled = False
            msk5V3.Text = ""
        End If
    End Sub

    Private Sub chk7V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk7V3.CheckedChanged
        If chk7V3.Checked = True Then
            msk6V3.Enabled = True
        Else
            msk6V3.Enabled = False
            msk6V3.Text = ""
        End If
    End Sub

    Private Sub chk8V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk8V3.CheckedChanged
        If chk8V3.Checked = True Then
            msk7V3.Enabled = True
        Else
            msk7V3.Enabled = False
            msk7V3.Text = ""
        End If
    End Sub

    Private Sub chk9V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk9V3.CheckedChanged
        If chk9V3.Checked = True Then
            msk8V3.Enabled = True
        Else
            msk8V3.Enabled = False
            msk8V3.Text = ""
        End If
    End Sub

    Private Sub chk13V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk13V3.CheckedChanged
        If chk13V3.Checked = True Then
            msk9V3.Enabled = True
        Else
            msk9V3.Enabled = False
            msk9V3.Text = ""
        End If
    End Sub

    Private Sub chk14V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk14V3.CheckedChanged
        If chk14V3.Checked = True Then
            msk10V3.Enabled = True
        Else
            msk10V3.Enabled = False
            msk10V3.Text = ""
        End If
    End Sub

    Private Sub chk15V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk15V3.CheckedChanged
        If chk15V3.Checked = True Then
            msk11V3.Enabled = True
        Else
            msk11V3.Enabled = False
            msk11V3.Text = ""
        End If
    End Sub

    Private Sub chk16V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk16V3.CheckedChanged
        If chk16V3.Checked = True Then
            msk12V3.Enabled = True
        Else
            msk12V3.Enabled = False
            msk12V3.Text = ""
        End If
    End Sub

    Private Sub chk20V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk20V3.CheckedChanged
        If chk20V3.Checked = True Then
            msk13V3.Enabled = True
        Else
            msk13V3.Enabled = False
            msk13V3.Text = ""
        End If
    End Sub

    Private Sub chk21V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk21V3.CheckedChanged
        If chk21V3.Checked = True Then
            msk14V3.Enabled = True
        Else
            msk14V3.Enabled = False
            msk14V3.Text = ""
        End If
    End Sub

    Private Sub chk22V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk22V3.CheckedChanged
        If chk22V3.Checked = True Then
            msk15V3.Enabled = True
        Else
            msk15V3.Enabled = False
            msk15V3.Text = ""
        End If
    End Sub

    Private Sub chk23V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk23V3.CheckedChanged
        If chk23V3.Checked = True Then
            msk16V3.Enabled = True
        Else
            msk16V3.Enabled = False
            msk16V3.Text = ""
        End If
    End Sub

    Private Sub msk1V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk1V3.MaskInputRejected
        msk1V3.BeepOnError = True
    End Sub

    Private Sub msk2V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk2V3.MaskInputRejected
        msk2V3.BeepOnError = True
    End Sub

    Private Sub msk3V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk3V3.MaskInputRejected
        msk3V3.BeepOnError = True
    End Sub

    Private Sub msk4V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk4V3.MaskInputRejected
        msk4V3.BeepOnError = True
    End Sub

    Private Sub msk5V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk5V3.MaskInputRejected
        msk5V3.BeepOnError = True
    End Sub

    Private Sub msk6V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk6V3.MaskInputRejected
        msk6V3.BeepOnError = True
    End Sub

    Private Sub msk7V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk7V3.MaskInputRejected
        msk7V3.BeepOnError = True
    End Sub

    Private Sub msk8V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk8V3.MaskInputRejected
        msk8V3.BeepOnError = True
    End Sub

    Private Sub msk9V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk9V3.MaskInputRejected
        msk9V3.BeepOnError = True
    End Sub

    Private Sub msk10V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk10V3.MaskInputRejected
        msk10V3.BeepOnError = True
    End Sub

    Private Sub msk11V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk11V3.MaskInputRejected
        msk11V3.BeepOnError = True
    End Sub

    Private Sub msk12V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk12V3.MaskInputRejected
        msk12V3.BeepOnError = True
    End Sub

    Private Sub msk13V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk13V3.MaskInputRejected
        msk13V3.BeepOnError = True
    End Sub

    Private Sub msk14V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk14V3.MaskInputRejected
        msk14V3.BeepOnError = True
    End Sub

    Private Sub msk15V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk15V3.MaskInputRejected
        msk15V3.BeepOnError = True
    End Sub

    Private Sub msk16V3_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk16V3.MaskInputRejected
        msk16V3.BeepOnError = True
    End Sub

    Private Sub btn1V3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1V3.Click
        b = 0
        If chkShorV3.Checked = True Then
            If (rb1V3.Checked = False And rb2V3.Checked = False) Then
                b = 1
            End If

            If chk1V3.Checked = True And msk1V3.Text = "" Then
                b = 1
            End If

            If chk2V3.Checked = True And msk2V3.Text = "" Then
                b = 1
            End If

            If chk3V3.Checked = True And msk3V3.Text = "" Then
                b = 1
            End If

            If chk4V3.Checked = True And msk4V3.Text = "" Then
                b = 1
            End If

            If cbm1V3.Text = "" Then
                b = 1
            End If

            If rb2V3.Checked = True Then
                If (rb4V3.Checked = False And rb5V3.Checked = False) Then
                    b = 1
                End If
            End If
        End If

        If chkBuzoV3.Checked = True Then
            If (rb6V3.Checked = False And rb7V3.Checked = False) Then
                b = 1
            End If

            If chk6V3.Checked = True And msk5V3.Text = "" Then
                b = 1
            End If

            If chk7V3.Checked = True And msk6V3.Text = "" Then
                b = 1
            End If

            If chk8V3.Checked = True And msk7V3.Text = "" Then
                b = 1
            End If

            If chk9V3.Checked = True And msk8V3.Text = "" Then
                b = 1
            End If

            If cbm2V3.Text = "" Then
                b = 1
            End If

            If rb7V3.Checked = True Then
                If (rb8V3.Checked = False And rb9V3.Checked = False) Then
                    b = 1
                End If
            End If
        End If

        If chkBuzoEV3.Checked = True Then
            If (rb10V3.Checked = False And rb11V3.Checked = False) Then
                b = 1
            End If

            If chk13V3.Checked = True And msk9V3.Text = "" Then
                b = 1
            End If

            If chk14V3.Checked = True And msk10V3.Text = "" Then
                b = 1
            End If

            If chk15V3.Checked = True And msk11V3.Text = "" Then
                b = 1
            End If

            If chk16V3.Checked = True And msk12V3.Text = "" Then
                b = 1
            End If

            If cbm3V3.Text = "" Then
                b = 1
            End If

            If rb11V3.Checked = True Then
                If (rb12V3.Checked = False And rb13V3.Checked = False) Then
                    b = 1
                End If
            End If
        End If

        If chkCamperaV3.Checked = True Then
            If (rb14V3.Checked = False And rb15V3.Checked = False) Then
                b = 1
            End If

            If chk20V3.Checked = True And msk13V3.Text = "" Then
                b = 1
            End If

            If chk21V3.Checked = True And msk14V3.Text = "" Then
                b = 1
            End If

            If chk22V3.Checked = True And msk15V3.Text = "" Then
                b = 1
            End If

            If chk23V3.Checked = True And msk16V3.Text = "" Then
                b = 1
            End If

            If cbm4V3.Text = "" Then
                b = 1
            End If

            If rb15V3.Checked = True Then
                If (rb16V3.Checked = False And rb17V3.Checked = False) Then
                    b = 1
                End If
            End If
        End If

        If b = 0 Then
            'GUARDA CON LOS ACUMULADORES preciototal npglobal y tiempocam
            If rb4V3.Checked = True Or rb8V3.Checked = True Or rb12V3.Checked = True Or rb16V3.Checked = True Then
                banderabordado = 1
            End If
            contador = 0

            banderadetallecam = "sin"
            preciouncam = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0
            preciocam = 0
            cantidadcam = 0
            

            If chkShorV3.Checked = True Then
                bdetalle = 0
                contador = 1
                If chk1V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk1V3.Text)
                    cantidadcam = CInt(msk1V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb4V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb4V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk2V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If

                    preciocam = preciocam * CInt(msk2V3.Text)
                    cantidadcam = CInt(msk2V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else
                        If rb4V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                   
                    banderadetallecam = "sin"
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb4V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk3V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If

                    preciocam = preciocam * CInt(msk3V3.Text)
                    cantidadcam = CInt(msk3V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else
                        If rb4V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & manguita & " " & cbm1V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb4V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk4V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Short'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If

                    preciocam = preciocam * CInt(msk4V3.Text)
                    cantidadcam = CInt(msk4V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else
                        If rb4V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Short " & cbm1V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb4V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            bdetalle = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            If chkBuzoV3.Checked = True Then
                contador = 1
                If chk6V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk10V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcordon = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk11V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If

                        If chk12V3.Checked = True Then
                            sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                            If rs.Read = True Then
                                preciocam = preciocam + rs(1)
                                banderadetallecam = "con"
                                preciouncam = preciouncam + rs(1)
                                tiempocam = tiempocam + rs(2)
                                bbolsillo = 1
                                bdetalle = 1
                            End If
                        End If

                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk5V3.Text)
                    cantidadcam = CInt(msk5V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb8V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb8V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If

                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk7V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk10V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcordon = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk11V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If

                        If chk12V3.Checked = True Then
                            sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                            If rs.Read = True Then
                                preciocam = preciocam + rs(1)
                                banderadetallecam = "con"
                                preciouncam = preciouncam + rs(1)
                                tiempocam = tiempocam + rs(2)
                                bbolsillo = 1
                                bdetalle = 1
                            End If
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk7V3.Text)
                    cantidadcam = CInt(msk7V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb8V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb8V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk8V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk10V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcordon = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk11V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If

                        If chk12V3.Checked = True Then
                            sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                            If rs.Read = True Then
                                preciocam = preciocam + rs(1)
                                banderadetallecam = "con"
                                preciouncam = preciouncam + rs(1)
                                tiempocam = tiempocam + rs(2)
                                bbolsillo = 1
                                bdetalle = 1
                            End If
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk7V3.Text)
                    cantidadcam = CInt(msk7V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb8V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb8V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk9V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk10V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcordon = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk11V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If

                        If chk12V3.Checked = True Then
                            sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                            If rs.Read = True Then
                                preciocam = preciocam + rs(1)
                                banderadetallecam = "con"
                                preciouncam = preciouncam + rs(1)
                                tiempocam = tiempocam + rs(2)
                                bbolsillo = 1
                                bdetalle = 1
                            End If
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk8V3.Text)
                    cantidadcam = CInt(msk8V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & cbm2V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb8V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & manguita & " " & cbm2V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo " & manguita & " " & cbm2V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb8V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            bdetalle = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            '________________________________________________________________________________________________________________

            If chkBuzoEV3.Checked = True Then
                contador = 1
                If chk13V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk17V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcordon = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk18V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If

                        If chk19V3.Checked = True Then
                            sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                            If rs.Read = True Then
                                preciocam = preciocam + rs(1)
                                banderadetallecam = "con"
                                preciouncam = preciouncam + rs(1)
                                tiempocam = tiempocam + rs(2)
                                bbolsillo = 1
                                bdetalle = 1
                            End If
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk9V3.Text)
                    cantidadcam = CInt(msk9V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb12V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            If chk14V3.Checked = True Then
                sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Buzo'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    preciocam = preciocam + rs(1)
                    tiempocam = tiempocam + rs(2)
                    codrt = rs(0)
                    sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V3.Text & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        codrtc = rs(0)
                    End If
                End If

                If chk17V3.Checked = True Then
                    sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        banderadetallecam = "con"
                        preciouncam = preciouncam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        bcordon = 1
                        bdetalle = 1
                    End If
                End If

                If chk18V3.Checked = True Then
                    sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        banderadetallecam = "con"
                        preciouncam = preciouncam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        bcapucha = 1
                        bdetalle = 1
                    End If

                    If chk19V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk10V3.Text)
                    cantidadcam = CInt(msk10V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb12V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            If chk15V3.Checked = True Then
                sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Buzo'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    preciocam = preciocam + rs(1)
                    tiempocam = tiempocam + rs(2)
                    codrt = rs(0)
                    sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V3.Text & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        codrtc = rs(0)
                    End If
                End If

                If chk17V3.Checked = True Then
                    sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        banderadetallecam = "con"
                        preciouncam = preciouncam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        bcordon = 1
                        bdetalle = 1
                    End If
                End If

                If chk18V3.Checked = True Then
                    sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        banderadetallecam = "con"
                        preciouncam = preciouncam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        bcapucha = 1
                        bdetalle = 1
                    End If

                    If chk19V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk11V3.Text)
                    cantidadcam = CInt(msk11V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb12V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If
            If chk16V3.Checked = True Then
                sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Buzo'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    preciocam = preciocam + rs(1)
                    tiempocam = tiempocam + rs(2)
                    codrt = rs(0)
                    sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V3.Text & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        codrtc = rs(0)
                    End If
                End If

                If chk17V3.Checked = True Then
                    sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cordon/Tirante Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        banderadetallecam = "con"
                        preciouncam = preciouncam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        bcordon = 1
                        bdetalle = 1
                    End If
                End If

                If chk18V3.Checked = True Then
                    sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        banderadetallecam = "con"
                        preciouncam = preciouncam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        bcapucha = 1
                        bdetalle = 1
                    End If

                    If chk19V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo canguro'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Buzo'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk12V3.Text)
                    cantidadcam = CInt(msk12V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Buzo de egresados " & cbm3V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcordon = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 6)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 7)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb12V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If


            '______________________________________________________________________________________________________________________
            bdetalle = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            If chkCamperaV3.Checked = True Then
                contador = 1
                If chk20V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk24V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo interior'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillosint = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk25V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk26V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo con cierre'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcierre = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk13V3.Text)
                    cantidadcam = CInt(msk13V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillosint = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 9)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcierre = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 8)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb16V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk21V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk24V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo interior'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillosint = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk25V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk26V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo con cierre'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcierre = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk14V3.Text)
                    cantidadcam = CInt(msk14V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillosint = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 9)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcierre = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 8)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb16V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk22V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk24V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo interior'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillosint = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk25V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk26V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo con cierre'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcierre = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk15V3.Text)
                    cantidadcam = CInt(msk15V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillosint = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 9)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcierre = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 8)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb16V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk23V3.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V3.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk24V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo interior'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillosint = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk25V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Capucha'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcapucha = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk26V3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo con cierre'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcierre = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Campera'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk16V3.Text)
                    cantidadcam = CInt(msk16V3.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb12V3.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Campera " & cbm4V3.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillosint = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 9)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcapucha = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 5)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcierre = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 8)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb16V3.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '.............................................................................................
            End If

            bdetalle = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            sql = "INSERT INTO NPTOTAL VALUES('', '" & npglobal & "', '" & preciototal & "', '" & tiempocam & "')"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()

            Me.Hide()
            Ventas4.Show()
        Else
            MsgBox("Usted ha dejado campos sin completar.", MsgBoxStyle.Exclamation, "ERROR")
        End If
    End Sub

    Private Sub Ventas3_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "SELECT nombre FROM colores"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            cbm1V3.Items.Add(rs(0))
            cbm2V3.Items.Add(rs(0))
            cbm3V3.Items.Add(rs(0))
            cbm4V3.Items.Add(rs(0))
        Loop
    End Sub

    Private Sub rb2V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2V3.CheckedChanged
        If rb2V3.Checked = True Then
            grb1V3.Visible = True
        End If
    End Sub

    Private Sub rb7V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb7V3.CheckedChanged
        If rb7V3.Checked = True Then
            grb2V3.Visible = True
        End If
    End Sub

    Private Sub rb11V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb11V3.CheckedChanged
        If rb11V3.Checked = True Then
            grb3V3.Visible = True
        End If
    End Sub

    Private Sub rb15V3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb15V3.CheckedChanged
        If rb15V3.Checked = True Then
            grb4V3.Visible = True
        End If
    End Sub
End Class