﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ventas2
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lineshape = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.btn1V2 = New System.Windows.Forms.Button()
        Me.btnCancelarV2 = New System.Windows.Forms.Button()
        Me.rb2V2 = New System.Windows.Forms.RadioButton()
        Me.rb1V2 = New System.Windows.Forms.RadioButton()
        Me.lbl2V2 = New System.Windows.Forms.Label()
        Me.chk2V2 = New System.Windows.Forms.CheckBox()
        Me.chk5V2 = New System.Windows.Forms.CheckBox()
        Me.chk1V2 = New System.Windows.Forms.CheckBox()
        Me.chk3V2 = New System.Windows.Forms.CheckBox()
        Me.chk4V2 = New System.Windows.Forms.CheckBox()
        Me.lbl5V2 = New System.Windows.Forms.Label()
        Me.rb5V2 = New System.Windows.Forms.RadioButton()
        Me.cbm1V2 = New System.Windows.Forms.ComboBox()
        Me.rb6V2 = New System.Windows.Forms.RadioButton()
        Me.lbl3V2 = New System.Windows.Forms.Label()
        Me.lbl4V2 = New System.Windows.Forms.Label()
        Me.grb1V2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox1 = New System.Windows.Forms.CheckBox()
        Me.panel1V2 = New System.Windows.Forms.Panel()
        Me.rb11V2 = New System.Windows.Forms.RadioButton()
        Me.lbl8V2 = New System.Windows.Forms.Label()
        Me.rb12V2 = New System.Windows.Forms.RadioButton()
        Me.cbm2V2 = New System.Windows.Forms.ComboBox()
        Me.chk8V2 = New System.Windows.Forms.CheckBox()
        Me.chk6V2 = New System.Windows.Forms.CheckBox()
        Me.chk7V2 = New System.Windows.Forms.CheckBox()
        Me.lbl9V2 = New System.Windows.Forms.Label()
        Me.chk9V2 = New System.Windows.Forms.CheckBox()
        Me.lbl6V2 = New System.Windows.Forms.Label()
        Me.lbl7V2 = New System.Windows.Forms.Label()
        Me.rb8V2 = New System.Windows.Forms.RadioButton()
        Me.rb7V2 = New System.Windows.Forms.RadioButton()
        Me.grb2V2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox3 = New System.Windows.Forms.CheckBox()
        Me.chk11V2 = New System.Windows.Forms.CheckBox()
        Me.panel2V2 = New System.Windows.Forms.Panel()
        Me.lbl12V2 = New System.Windows.Forms.Label()
        Me.cbm3V2 = New System.Windows.Forms.ComboBox()
        Me.chk12V2 = New System.Windows.Forms.CheckBox()
        Me.lbl13V2 = New System.Windows.Forms.Label()
        Me.chk14V2 = New System.Windows.Forms.CheckBox()
        Me.chk13V2 = New System.Windows.Forms.CheckBox()
        Me.chk17V2 = New System.Windows.Forms.CheckBox()
        Me.lbl10V2 = New System.Windows.Forms.Label()
        Me.rb13V2 = New System.Windows.Forms.RadioButton()
        Me.grb3V2 = New System.Windows.Forms.GroupBox()
        Me.rb15V2 = New System.Windows.Forms.RadioButton()
        Me.rb16V2 = New System.Windows.Forms.RadioButton()
        Me.chk16V2 = New System.Windows.Forms.CheckBox()
        Me.chk15V2 = New System.Windows.Forms.CheckBox()
        Me.lbl11V2 = New System.Windows.Forms.Label()
        Me.rb14V2 = New System.Windows.Forms.RadioButton()
        Me.lbl16V2 = New System.Windows.Forms.Label()
        Me.cbm4V2 = New System.Windows.Forms.ComboBox()
        Me.chk20V2 = New System.Windows.Forms.CheckBox()
        Me.chk18V2 = New System.Windows.Forms.CheckBox()
        Me.rb19V2 = New System.Windows.Forms.RadioButton()
        Me.chk19V2 = New System.Windows.Forms.CheckBox()
        Me.chk22V2 = New System.Windows.Forms.CheckBox()
        Me.lbl17V2 = New System.Windows.Forms.Label()
        Me.chk21V2 = New System.Windows.Forms.CheckBox()
        Me.lbl14V2 = New System.Windows.Forms.Label()
        Me.rb20V2 = New System.Windows.Forms.RadioButton()
        Me.lbl15V2 = New System.Windows.Forms.Label()
        Me.rb18V2 = New System.Windows.Forms.RadioButton()
        Me.rb17V2 = New System.Windows.Forms.RadioButton()
        Me.grb4V2 = New System.Windows.Forms.GroupBox()
        Me.chkCamV2 = New System.Windows.Forms.CheckBox()
        Me.grbCV2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox2 = New System.Windows.Forms.CheckBox()
        Me.msk4V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk3V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk2V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk1V2 = New System.Windows.Forms.MaskedTextBox()
        Me.chkRemV2 = New System.Windows.Forms.CheckBox()
        Me.chkPanV2 = New System.Windows.Forms.CheckBox()
        Me.chkPulV2 = New System.Windows.Forms.CheckBox()
        Me.grbRemV2 = New System.Windows.Forms.GroupBox()
        Me.CheckBox4 = New System.Windows.Forms.CheckBox()
        Me.msk8V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk7V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk6V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk5V2 = New System.Windows.Forms.MaskedTextBox()
        Me.grbPantV2 = New System.Windows.Forms.GroupBox()
        Me.msk12V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk11V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk10V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk9V2 = New System.Windows.Forms.MaskedTextBox()
        Me.grbPulV2 = New System.Windows.Forms.GroupBox()
        Me.msk16V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk15V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk14V2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk13V2 = New System.Windows.Forms.MaskedTextBox()
        Me.grb1V2.SuspendLayout()
        Me.panel1V2.SuspendLayout()
        Me.grb2V2.SuspendLayout()
        Me.panel2V2.SuspendLayout()
        Me.grb3V2.SuspendLayout()
        Me.grb4V2.SuspendLayout()
        Me.grbCV2.SuspendLayout()
        Me.grbRemV2.SuspendLayout()
        Me.grbPantV2.SuspendLayout()
        Me.grbPulV2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lineshape
        '
        Me.lineshape.BorderWidth = 2
        Me.lineshape.Location = New System.Drawing.Point(7, 9)
        Me.lineshape.Name = "lineshape"
        Me.lineshape.Size = New System.Drawing.Size(1018, 579)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.lineshape})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1020, 595)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'btn1V2
        '
        Me.btn1V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1V2.Location = New System.Drawing.Point(99, 544)
        Me.btn1V2.Name = "btn1V2"
        Me.btn1V2.Size = New System.Drawing.Size(381, 39)
        Me.btn1V2.TabIndex = 9
        Me.btn1V2.Text = "Continuar"
        Me.btn1V2.UseVisualStyleBackColor = True
        '
        'btnCancelarV2
        '
        Me.btnCancelarV2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnCancelarV2.Location = New System.Drawing.Point(566, 544)
        Me.btnCancelarV2.Name = "btnCancelarV2"
        Me.btnCancelarV2.Size = New System.Drawing.Size(380, 39)
        Me.btnCancelarV2.TabIndex = 10
        Me.btnCancelarV2.Text = "Volver"
        Me.btnCancelarV2.UseVisualStyleBackColor = True
        '
        'rb2V2
        '
        Me.rb2V2.AutoSize = True
        Me.rb2V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb2V2.Location = New System.Drawing.Point(125, 32)
        Me.rb2V2.Name = "rb2V2"
        Me.rb2V2.Size = New System.Drawing.Size(51, 28)
        Me.rb2V2.TabIndex = 13
        Me.rb2V2.TabStop = True
        Me.rb2V2.Text = "No."
        Me.rb2V2.UseVisualStyleBackColor = True
        '
        'rb1V2
        '
        Me.rb1V2.AutoSize = True
        Me.rb1V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb1V2.Location = New System.Drawing.Point(125, 9)
        Me.rb1V2.Name = "rb1V2"
        Me.rb1V2.Size = New System.Drawing.Size(48, 28)
        Me.rb1V2.TabIndex = 12
        Me.rb1V2.TabStop = True
        Me.rb1V2.Text = "Sí."
        Me.rb1V2.UseVisualStyleBackColor = True
        '
        'lbl2V2
        '
        Me.lbl2V2.AutoSize = True
        Me.lbl2V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2V2.Location = New System.Drawing.Point(25, 23)
        Me.lbl2V2.Name = "lbl2V2"
        Me.lbl2V2.Size = New System.Drawing.Size(94, 24)
        Me.lbl2V2.TabIndex = 15
        Me.lbl2V2.Text = "¿Estándar?"
        '
        'chk2V2
        '
        Me.chk2V2.AutoSize = True
        Me.chk2V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk2V2.Location = New System.Drawing.Point(13, 141)
        Me.chk2V2.Name = "chk2V2"
        Me.chk2V2.Size = New System.Drawing.Size(88, 28)
        Me.chk2V2.TabIndex = 17
        Me.chk2V2.Text = "Mediano"
        Me.chk2V2.UseVisualStyleBackColor = True
        '
        'chk5V2
        '
        Me.chk5V2.AutoSize = True
        Me.chk5V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk5V2.Location = New System.Drawing.Point(15, 9)
        Me.chk5V2.Name = "chk5V2"
        Me.chk5V2.Size = New System.Drawing.Size(85, 28)
        Me.chk5V2.TabIndex = 18
        Me.chk5V2.Text = "Bolsillo"
        Me.chk5V2.UseVisualStyleBackColor = True
        '
        'chk1V2
        '
        Me.chk1V2.AutoSize = True
        Me.chk1V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk1V2.Location = New System.Drawing.Point(14, 107)
        Me.chk1V2.Name = "chk1V2"
        Me.chk1V2.Size = New System.Drawing.Size(67, 28)
        Me.chk1V2.TabIndex = 19
        Me.chk1V2.Text = "Chico"
        Me.chk1V2.UseVisualStyleBackColor = True
        '
        'chk3V2
        '
        Me.chk3V2.AutoSize = True
        Me.chk3V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk3V2.Location = New System.Drawing.Point(13, 175)
        Me.chk3V2.Name = "chk3V2"
        Me.chk3V2.Size = New System.Drawing.Size(81, 28)
        Me.chk3V2.TabIndex = 20
        Me.chk3V2.Text = "Grande"
        Me.chk3V2.UseVisualStyleBackColor = True
        '
        'chk4V2
        '
        Me.chk4V2.AutoSize = True
        Me.chk4V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk4V2.Location = New System.Drawing.Point(13, 209)
        Me.chk4V2.Name = "chk4V2"
        Me.chk4V2.Size = New System.Drawing.Size(116, 28)
        Me.chk4V2.TabIndex = 21
        Me.chk4V2.Text = "Muy grande"
        Me.chk4V2.UseVisualStyleBackColor = True
        '
        'lbl5V2
        '
        Me.lbl5V2.AutoSize = True
        Me.lbl5V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5V2.Location = New System.Drawing.Point(8, 18)
        Me.lbl5V2.Name = "lbl5V2"
        Me.lbl5V2.Size = New System.Drawing.Size(89, 24)
        Me.lbl5V2.TabIndex = 24
        Me.lbl5V2.Text = "¿Bordado?"
        '
        'rb5V2
        '
        Me.rb5V2.AutoSize = True
        Me.rb5V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb5V2.Location = New System.Drawing.Point(108, 4)
        Me.rb5V2.Name = "rb5V2"
        Me.rb5V2.Size = New System.Drawing.Size(48, 28)
        Me.rb5V2.TabIndex = 22
        Me.rb5V2.TabStop = True
        Me.rb5V2.Text = "Sí."
        Me.rb5V2.UseVisualStyleBackColor = True
        '
        'cbm1V2
        '
        Me.cbm1V2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm1V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm1V2.FormattingEnabled = True
        Me.cbm1V2.Location = New System.Drawing.Point(101, 254)
        Me.cbm1V2.Name = "cbm1V2"
        Me.cbm1V2.Size = New System.Drawing.Size(121, 32)
        Me.cbm1V2.TabIndex = 27
        '
        'rb6V2
        '
        Me.rb6V2.AutoSize = True
        Me.rb6V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb6V2.Location = New System.Drawing.Point(108, 27)
        Me.rb6V2.Name = "rb6V2"
        Me.rb6V2.Size = New System.Drawing.Size(51, 28)
        Me.rb6V2.TabIndex = 23
        Me.rb6V2.TabStop = True
        Me.rb6V2.Text = "No."
        Me.rb6V2.UseVisualStyleBackColor = True
        '
        'lbl3V2
        '
        Me.lbl3V2.AutoSize = True
        Me.lbl3V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3V2.Location = New System.Drawing.Point(149, 68)
        Me.lbl3V2.Name = "lbl3V2"
        Me.lbl3V2.Size = New System.Drawing.Size(73, 24)
        Me.lbl3V2.TabIndex = 14
        Me.lbl3V2.Text = "Cantidad"
        '
        'lbl4V2
        '
        Me.lbl4V2.AutoSize = True
        Me.lbl4V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4V2.Location = New System.Drawing.Point(25, 257)
        Me.lbl4V2.Name = "lbl4V2"
        Me.lbl4V2.Size = New System.Drawing.Size(49, 24)
        Me.lbl4V2.TabIndex = 32
        Me.lbl4V2.Text = "Color"
        '
        'grb1V2
        '
        Me.grb1V2.Controls.Add(Me.chk5V2)
        Me.grb1V2.Controls.Add(Me.CheckBox1)
        Me.grb1V2.Controls.Add(Me.panel1V2)
        Me.grb1V2.Location = New System.Drawing.Point(14, 326)
        Me.grb1V2.Name = "grb1V2"
        Me.grb1V2.Size = New System.Drawing.Size(225, 128)
        Me.grb1V2.TabIndex = 33
        Me.grb1V2.TabStop = False
        Me.grb1V2.Visible = False
        '
        'CheckBox1
        '
        Me.CheckBox1.AutoSize = True
        Me.CheckBox1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.CheckBox1.Location = New System.Drawing.Point(101, 9)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(118, 28)
        Me.CheckBox1.TabIndex = 29
        Me.CheckBox1.Text = "Cuello en V"
        Me.CheckBox1.UseVisualStyleBackColor = True
        '
        'panel1V2
        '
        Me.panel1V2.Controls.Add(Me.rb5V2)
        Me.panel1V2.Controls.Add(Me.lbl5V2)
        Me.panel1V2.Controls.Add(Me.rb6V2)
        Me.panel1V2.Location = New System.Drawing.Point(27, 43)
        Me.panel1V2.Name = "panel1V2"
        Me.panel1V2.Size = New System.Drawing.Size(179, 60)
        Me.panel1V2.TabIndex = 28
        '
        'rb11V2
        '
        Me.rb11V2.AutoSize = True
        Me.rb11V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb11V2.Location = New System.Drawing.Point(113, 3)
        Me.rb11V2.Name = "rb11V2"
        Me.rb11V2.Size = New System.Drawing.Size(48, 28)
        Me.rb11V2.TabIndex = 22
        Me.rb11V2.TabStop = True
        Me.rb11V2.Text = "Sí."
        Me.rb11V2.UseVisualStyleBackColor = True
        '
        'lbl8V2
        '
        Me.lbl8V2.AutoSize = True
        Me.lbl8V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl8V2.Location = New System.Drawing.Point(20, 257)
        Me.lbl8V2.Name = "lbl8V2"
        Me.lbl8V2.Size = New System.Drawing.Size(49, 24)
        Me.lbl8V2.TabIndex = 48
        Me.lbl8V2.Text = "Color"
        '
        'rb12V2
        '
        Me.rb12V2.AutoSize = True
        Me.rb12V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb12V2.Location = New System.Drawing.Point(113, 26)
        Me.rb12V2.Name = "rb12V2"
        Me.rb12V2.Size = New System.Drawing.Size(51, 28)
        Me.rb12V2.TabIndex = 23
        Me.rb12V2.TabStop = True
        Me.rb12V2.Text = "No."
        Me.rb12V2.UseVisualStyleBackColor = True
        '
        'cbm2V2
        '
        Me.cbm2V2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm2V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm2V2.FormattingEnabled = True
        Me.cbm2V2.Location = New System.Drawing.Point(96, 254)
        Me.cbm2V2.Name = "cbm2V2"
        Me.cbm2V2.Size = New System.Drawing.Size(121, 32)
        Me.cbm2V2.TabIndex = 43
        '
        'chk8V2
        '
        Me.chk8V2.AutoSize = True
        Me.chk8V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk8V2.Location = New System.Drawing.Point(8, 175)
        Me.chk8V2.Name = "chk8V2"
        Me.chk8V2.Size = New System.Drawing.Size(81, 28)
        Me.chk8V2.TabIndex = 41
        Me.chk8V2.Text = "Grande"
        Me.chk8V2.UseVisualStyleBackColor = True
        '
        'chk6V2
        '
        Me.chk6V2.AutoSize = True
        Me.chk6V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk6V2.Location = New System.Drawing.Point(9, 107)
        Me.chk6V2.Name = "chk6V2"
        Me.chk6V2.Size = New System.Drawing.Size(67, 28)
        Me.chk6V2.TabIndex = 40
        Me.chk6V2.Text = "Chico"
        Me.chk6V2.UseVisualStyleBackColor = True
        '
        'chk7V2
        '
        Me.chk7V2.AutoSize = True
        Me.chk7V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk7V2.Location = New System.Drawing.Point(8, 141)
        Me.chk7V2.Name = "chk7V2"
        Me.chk7V2.Size = New System.Drawing.Size(88, 28)
        Me.chk7V2.TabIndex = 39
        Me.chk7V2.Text = "Mediano"
        Me.chk7V2.UseVisualStyleBackColor = True
        '
        'lbl9V2
        '
        Me.lbl9V2.AutoSize = True
        Me.lbl9V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl9V2.Location = New System.Drawing.Point(13, 17)
        Me.lbl9V2.Name = "lbl9V2"
        Me.lbl9V2.Size = New System.Drawing.Size(89, 24)
        Me.lbl9V2.TabIndex = 24
        Me.lbl9V2.Text = "¿Bordado?"
        '
        'chk9V2
        '
        Me.chk9V2.AutoSize = True
        Me.chk9V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk9V2.Location = New System.Drawing.Point(8, 209)
        Me.chk9V2.Name = "chk9V2"
        Me.chk9V2.Size = New System.Drawing.Size(116, 28)
        Me.chk9V2.TabIndex = 42
        Me.chk9V2.Text = "Muy grande"
        Me.chk9V2.UseVisualStyleBackColor = True
        '
        'lbl6V2
        '
        Me.lbl6V2.AutoSize = True
        Me.lbl6V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl6V2.Location = New System.Drawing.Point(20, 23)
        Me.lbl6V2.Name = "lbl6V2"
        Me.lbl6V2.Size = New System.Drawing.Size(94, 24)
        Me.lbl6V2.TabIndex = 38
        Me.lbl6V2.Text = "¿Estándar?"
        '
        'lbl7V2
        '
        Me.lbl7V2.AutoSize = True
        Me.lbl7V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl7V2.Location = New System.Drawing.Point(144, 68)
        Me.lbl7V2.Name = "lbl7V2"
        Me.lbl7V2.Size = New System.Drawing.Size(73, 24)
        Me.lbl7V2.TabIndex = 37
        Me.lbl7V2.Text = "Cantidad"
        '
        'rb8V2
        '
        Me.rb8V2.AutoSize = True
        Me.rb8V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb8V2.Location = New System.Drawing.Point(120, 32)
        Me.rb8V2.Name = "rb8V2"
        Me.rb8V2.Size = New System.Drawing.Size(51, 28)
        Me.rb8V2.TabIndex = 36
        Me.rb8V2.TabStop = True
        Me.rb8V2.Text = "No."
        Me.rb8V2.UseVisualStyleBackColor = True
        '
        'rb7V2
        '
        Me.rb7V2.AutoSize = True
        Me.rb7V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb7V2.Location = New System.Drawing.Point(120, 9)
        Me.rb7V2.Name = "rb7V2"
        Me.rb7V2.Size = New System.Drawing.Size(48, 28)
        Me.rb7V2.TabIndex = 35
        Me.rb7V2.TabStop = True
        Me.rb7V2.Text = "Sí."
        Me.rb7V2.UseVisualStyleBackColor = True
        '
        'grb2V2
        '
        Me.grb2V2.Controls.Add(Me.CheckBox3)
        Me.grb2V2.Controls.Add(Me.chk11V2)
        Me.grb2V2.Controls.Add(Me.panel2V2)
        Me.grb2V2.Location = New System.Drawing.Point(8, 320)
        Me.grb2V2.Name = "grb2V2"
        Me.grb2V2.Size = New System.Drawing.Size(225, 109)
        Me.grb2V2.TabIndex = 49
        Me.grb2V2.TabStop = False
        Me.grb2V2.Visible = False
        '
        'CheckBox3
        '
        Me.CheckBox3.AutoSize = True
        Me.CheckBox3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.CheckBox3.Location = New System.Drawing.Point(101, 19)
        Me.CheckBox3.Name = "CheckBox3"
        Me.CheckBox3.Size = New System.Drawing.Size(118, 28)
        Me.CheckBox3.TabIndex = 30
        Me.CheckBox3.Text = "Cuello en V"
        Me.CheckBox3.UseVisualStyleBackColor = True
        '
        'chk11V2
        '
        Me.chk11V2.AutoSize = True
        Me.chk11V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk11V2.Location = New System.Drawing.Point(6, 19)
        Me.chk11V2.Name = "chk11V2"
        Me.chk11V2.Size = New System.Drawing.Size(84, 28)
        Me.chk11V2.TabIndex = 27
        Me.chk11V2.Text = "Chomba"
        Me.chk11V2.UseVisualStyleBackColor = True
        '
        'panel2V2
        '
        Me.panel2V2.Controls.Add(Me.rb11V2)
        Me.panel2V2.Controls.Add(Me.lbl9V2)
        Me.panel2V2.Controls.Add(Me.rb12V2)
        Me.panel2V2.Location = New System.Drawing.Point(23, 48)
        Me.panel2V2.Name = "panel2V2"
        Me.panel2V2.Size = New System.Drawing.Size(185, 51)
        Me.panel2V2.TabIndex = 28
        '
        'lbl12V2
        '
        Me.lbl12V2.AutoSize = True
        Me.lbl12V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl12V2.Location = New System.Drawing.Point(23, 257)
        Me.lbl12V2.Name = "lbl12V2"
        Me.lbl12V2.Size = New System.Drawing.Size(49, 24)
        Me.lbl12V2.TabIndex = 64
        Me.lbl12V2.Text = "Color"
        '
        'cbm3V2
        '
        Me.cbm3V2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm3V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm3V2.FormattingEnabled = True
        Me.cbm3V2.Location = New System.Drawing.Point(99, 254)
        Me.cbm3V2.Name = "cbm3V2"
        Me.cbm3V2.Size = New System.Drawing.Size(121, 32)
        Me.cbm3V2.TabIndex = 59
        '
        'chk12V2
        '
        Me.chk12V2.AutoSize = True
        Me.chk12V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk12V2.Location = New System.Drawing.Point(12, 107)
        Me.chk12V2.Name = "chk12V2"
        Me.chk12V2.Size = New System.Drawing.Size(67, 28)
        Me.chk12V2.TabIndex = 56
        Me.chk12V2.Text = "Chico"
        Me.chk12V2.UseVisualStyleBackColor = True
        '
        'lbl13V2
        '
        Me.lbl13V2.AutoSize = True
        Me.lbl13V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl13V2.Location = New System.Drawing.Point(39, 97)
        Me.lbl13V2.Name = "lbl13V2"
        Me.lbl13V2.Size = New System.Drawing.Size(89, 24)
        Me.lbl13V2.TabIndex = 24
        Me.lbl13V2.Text = "¿Bordado?"
        '
        'chk14V2
        '
        Me.chk14V2.AutoSize = True
        Me.chk14V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk14V2.Location = New System.Drawing.Point(11, 175)
        Me.chk14V2.Name = "chk14V2"
        Me.chk14V2.Size = New System.Drawing.Size(81, 28)
        Me.chk14V2.TabIndex = 57
        Me.chk14V2.Text = "Grande"
        Me.chk14V2.UseVisualStyleBackColor = True
        '
        'chk13V2
        '
        Me.chk13V2.AutoSize = True
        Me.chk13V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk13V2.Location = New System.Drawing.Point(11, 141)
        Me.chk13V2.Name = "chk13V2"
        Me.chk13V2.Size = New System.Drawing.Size(88, 28)
        Me.chk13V2.TabIndex = 55
        Me.chk13V2.Text = "Mediano"
        Me.chk13V2.UseVisualStyleBackColor = True
        '
        'chk17V2
        '
        Me.chk17V2.AutoSize = True
        Me.chk17V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk17V2.Location = New System.Drawing.Point(6, 59)
        Me.chk17V2.Name = "chk17V2"
        Me.chk17V2.Size = New System.Drawing.Size(162, 28)
        Me.chk17V2.TabIndex = 27
        Me.chk17V2.Text = "Elástico ajustable"
        Me.chk17V2.UseVisualStyleBackColor = True
        '
        'lbl10V2
        '
        Me.lbl10V2.AutoSize = True
        Me.lbl10V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl10V2.Location = New System.Drawing.Point(23, 23)
        Me.lbl10V2.Name = "lbl10V2"
        Me.lbl10V2.Size = New System.Drawing.Size(94, 24)
        Me.lbl10V2.TabIndex = 54
        Me.lbl10V2.Text = "¿Estándar?"
        '
        'rb13V2
        '
        Me.rb13V2.AutoSize = True
        Me.rb13V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb13V2.Location = New System.Drawing.Point(133, 9)
        Me.rb13V2.Name = "rb13V2"
        Me.rb13V2.Size = New System.Drawing.Size(48, 28)
        Me.rb13V2.TabIndex = 51
        Me.rb13V2.TabStop = True
        Me.rb13V2.Text = "Sí."
        Me.rb13V2.UseVisualStyleBackColor = True
        '
        'grb3V2
        '
        Me.grb3V2.Controls.Add(Me.rb15V2)
        Me.grb3V2.Controls.Add(Me.lbl13V2)
        Me.grb3V2.Controls.Add(Me.chk17V2)
        Me.grb3V2.Controls.Add(Me.rb16V2)
        Me.grb3V2.Controls.Add(Me.chk16V2)
        Me.grb3V2.Location = New System.Drawing.Point(12, 292)
        Me.grb3V2.Name = "grb3V2"
        Me.grb3V2.Size = New System.Drawing.Size(225, 139)
        Me.grb3V2.TabIndex = 65
        Me.grb3V2.TabStop = False
        Me.grb3V2.Visible = False
        '
        'rb15V2
        '
        Me.rb15V2.AutoSize = True
        Me.rb15V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb15V2.Location = New System.Drawing.Point(139, 83)
        Me.rb15V2.Name = "rb15V2"
        Me.rb15V2.Size = New System.Drawing.Size(48, 28)
        Me.rb15V2.TabIndex = 22
        Me.rb15V2.TabStop = True
        Me.rb15V2.Text = "Sí."
        Me.rb15V2.UseVisualStyleBackColor = True
        '
        'rb16V2
        '
        Me.rb16V2.AutoSize = True
        Me.rb16V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb16V2.Location = New System.Drawing.Point(139, 106)
        Me.rb16V2.Name = "rb16V2"
        Me.rb16V2.Size = New System.Drawing.Size(51, 28)
        Me.rb16V2.TabIndex = 23
        Me.rb16V2.TabStop = True
        Me.rb16V2.Text = "No."
        Me.rb16V2.UseVisualStyleBackColor = True
        '
        'chk16V2
        '
        Me.chk16V2.AutoSize = True
        Me.chk16V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk16V2.Location = New System.Drawing.Point(6, 26)
        Me.chk16V2.Name = "chk16V2"
        Me.chk16V2.Size = New System.Drawing.Size(94, 28)
        Me.chk16V2.TabIndex = 18
        Me.chk16V2.Text = "Bolsillos"
        Me.chk16V2.UseVisualStyleBackColor = True
        '
        'chk15V2
        '
        Me.chk15V2.AutoSize = True
        Me.chk15V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk15V2.Location = New System.Drawing.Point(11, 209)
        Me.chk15V2.Name = "chk15V2"
        Me.chk15V2.Size = New System.Drawing.Size(116, 28)
        Me.chk15V2.TabIndex = 58
        Me.chk15V2.Text = "Muy grande"
        Me.chk15V2.UseVisualStyleBackColor = True
        '
        'lbl11V2
        '
        Me.lbl11V2.AutoSize = True
        Me.lbl11V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl11V2.Location = New System.Drawing.Point(147, 68)
        Me.lbl11V2.Name = "lbl11V2"
        Me.lbl11V2.Size = New System.Drawing.Size(73, 24)
        Me.lbl11V2.TabIndex = 53
        Me.lbl11V2.Text = "Cantidad"
        '
        'rb14V2
        '
        Me.rb14V2.AutoSize = True
        Me.rb14V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb14V2.Location = New System.Drawing.Point(133, 32)
        Me.rb14V2.Name = "rb14V2"
        Me.rb14V2.Size = New System.Drawing.Size(51, 28)
        Me.rb14V2.TabIndex = 52
        Me.rb14V2.TabStop = True
        Me.rb14V2.Text = "No."
        Me.rb14V2.UseVisualStyleBackColor = True
        '
        'lbl16V2
        '
        Me.lbl16V2.AutoSize = True
        Me.lbl16V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl16V2.Location = New System.Drawing.Point(21, 257)
        Me.lbl16V2.Name = "lbl16V2"
        Me.lbl16V2.Size = New System.Drawing.Size(49, 24)
        Me.lbl16V2.TabIndex = 80
        Me.lbl16V2.Text = "Color"
        '
        'cbm4V2
        '
        Me.cbm4V2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm4V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm4V2.FormattingEnabled = True
        Me.cbm4V2.Items.AddRange(New Object() {"Rojo", "Verde", "Marrón", "Blanco", "Negro", "Azul", "Amarillo", "Rosa"})
        Me.cbm4V2.Location = New System.Drawing.Point(97, 254)
        Me.cbm4V2.Name = "cbm4V2"
        Me.cbm4V2.Size = New System.Drawing.Size(121, 32)
        Me.cbm4V2.TabIndex = 75
        '
        'chk20V2
        '
        Me.chk20V2.AutoSize = True
        Me.chk20V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk20V2.Location = New System.Drawing.Point(9, 175)
        Me.chk20V2.Name = "chk20V2"
        Me.chk20V2.Size = New System.Drawing.Size(81, 28)
        Me.chk20V2.TabIndex = 73
        Me.chk20V2.Text = "Grande"
        Me.chk20V2.UseVisualStyleBackColor = True
        '
        'chk18V2
        '
        Me.chk18V2.AutoSize = True
        Me.chk18V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk18V2.Location = New System.Drawing.Point(10, 107)
        Me.chk18V2.Name = "chk18V2"
        Me.chk18V2.Size = New System.Drawing.Size(67, 28)
        Me.chk18V2.TabIndex = 72
        Me.chk18V2.Text = "Chico"
        Me.chk18V2.UseVisualStyleBackColor = True
        '
        'rb19V2
        '
        Me.rb19V2.AutoSize = True
        Me.rb19V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb19V2.Location = New System.Drawing.Point(125, 48)
        Me.rb19V2.Name = "rb19V2"
        Me.rb19V2.Size = New System.Drawing.Size(48, 28)
        Me.rb19V2.TabIndex = 22
        Me.rb19V2.TabStop = True
        Me.rb19V2.Text = "Sí."
        Me.rb19V2.UseVisualStyleBackColor = True
        '
        'chk19V2
        '
        Me.chk19V2.AutoSize = True
        Me.chk19V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk19V2.Location = New System.Drawing.Point(9, 141)
        Me.chk19V2.Name = "chk19V2"
        Me.chk19V2.Size = New System.Drawing.Size(88, 28)
        Me.chk19V2.TabIndex = 71
        Me.chk19V2.Text = "Mediano"
        Me.chk19V2.UseVisualStyleBackColor = True
        '
        'chk22V2
        '
        Me.chk22V2.AutoSize = True
        Me.chk22V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk22V2.Location = New System.Drawing.Point(15, 25)
        Me.chk22V2.Name = "chk22V2"
        Me.chk22V2.Size = New System.Drawing.Size(118, 28)
        Me.chk22V2.TabIndex = 18
        Me.chk22V2.Text = "Cuello en V"
        Me.chk22V2.UseVisualStyleBackColor = True
        '
        'lbl17V2
        '
        Me.lbl17V2.AutoSize = True
        Me.lbl17V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl17V2.Location = New System.Drawing.Point(25, 62)
        Me.lbl17V2.Name = "lbl17V2"
        Me.lbl17V2.Size = New System.Drawing.Size(89, 24)
        Me.lbl17V2.TabIndex = 24
        Me.lbl17V2.Text = "¿Bordado?"
        '
        'chk21V2
        '
        Me.chk21V2.AutoSize = True
        Me.chk21V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk21V2.Location = New System.Drawing.Point(9, 209)
        Me.chk21V2.Name = "chk21V2"
        Me.chk21V2.Size = New System.Drawing.Size(116, 28)
        Me.chk21V2.TabIndex = 74
        Me.chk21V2.Text = "Muy grande"
        Me.chk21V2.UseVisualStyleBackColor = True
        '
        'lbl14V2
        '
        Me.lbl14V2.AutoSize = True
        Me.lbl14V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl14V2.Location = New System.Drawing.Point(21, 23)
        Me.lbl14V2.Name = "lbl14V2"
        Me.lbl14V2.Size = New System.Drawing.Size(94, 24)
        Me.lbl14V2.TabIndex = 70
        Me.lbl14V2.Text = "¿Estándar?"
        '
        'rb20V2
        '
        Me.rb20V2.AutoSize = True
        Me.rb20V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb20V2.Location = New System.Drawing.Point(125, 71)
        Me.rb20V2.Name = "rb20V2"
        Me.rb20V2.Size = New System.Drawing.Size(51, 28)
        Me.rb20V2.TabIndex = 23
        Me.rb20V2.TabStop = True
        Me.rb20V2.Text = "No."
        Me.rb20V2.UseVisualStyleBackColor = True
        '
        'lbl15V2
        '
        Me.lbl15V2.AutoSize = True
        Me.lbl15V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl15V2.Location = New System.Drawing.Point(145, 68)
        Me.lbl15V2.Name = "lbl15V2"
        Me.lbl15V2.Size = New System.Drawing.Size(73, 24)
        Me.lbl15V2.TabIndex = 69
        Me.lbl15V2.Text = "Cantidad"
        '
        'rb18V2
        '
        Me.rb18V2.AutoSize = True
        Me.rb18V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb18V2.Location = New System.Drawing.Point(121, 32)
        Me.rb18V2.Name = "rb18V2"
        Me.rb18V2.Size = New System.Drawing.Size(51, 28)
        Me.rb18V2.TabIndex = 68
        Me.rb18V2.TabStop = True
        Me.rb18V2.Text = "No."
        Me.rb18V2.UseVisualStyleBackColor = True
        '
        'rb17V2
        '
        Me.rb17V2.AutoSize = True
        Me.rb17V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb17V2.Location = New System.Drawing.Point(121, 9)
        Me.rb17V2.Name = "rb17V2"
        Me.rb17V2.Size = New System.Drawing.Size(48, 28)
        Me.rb17V2.TabIndex = 67
        Me.rb17V2.TabStop = True
        Me.rb17V2.Text = "Sí."
        Me.rb17V2.UseVisualStyleBackColor = True
        '
        'grb4V2
        '
        Me.grb4V2.Controls.Add(Me.rb19V2)
        Me.grb4V2.Controls.Add(Me.lbl17V2)
        Me.grb4V2.Controls.Add(Me.chk22V2)
        Me.grb4V2.Controls.Add(Me.rb20V2)
        Me.grb4V2.Location = New System.Drawing.Point(10, 292)
        Me.grb4V2.Name = "grb4V2"
        Me.grb4V2.Size = New System.Drawing.Size(225, 111)
        Me.grb4V2.TabIndex = 81
        Me.grb4V2.TabStop = False
        Me.grb4V2.Visible = False
        '
        'chkCamV2
        '
        Me.chkCamV2.AutoSize = True
        Me.chkCamV2.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCamV2.Location = New System.Drawing.Point(84, 25)
        Me.chkCamV2.Name = "chkCamV2"
        Me.chkCamV2.Size = New System.Drawing.Size(98, 35)
        Me.chkCamV2.TabIndex = 114
        Me.chkCamV2.Text = "Camisa"
        Me.chkCamV2.UseVisualStyleBackColor = True
        '
        'grbCV2
        '
        Me.grbCV2.Controls.Add(Me.CheckBox2)
        Me.grbCV2.Controls.Add(Me.msk4V2)
        Me.grbCV2.Controls.Add(Me.msk3V2)
        Me.grbCV2.Controls.Add(Me.msk2V2)
        Me.grbCV2.Controls.Add(Me.msk1V2)
        Me.grbCV2.Controls.Add(Me.chk2V2)
        Me.grbCV2.Controls.Add(Me.grb1V2)
        Me.grbCV2.Controls.Add(Me.rb1V2)
        Me.grbCV2.Controls.Add(Me.rb2V2)
        Me.grbCV2.Controls.Add(Me.lbl3V2)
        Me.grbCV2.Controls.Add(Me.lbl2V2)
        Me.grbCV2.Controls.Add(Me.chk1V2)
        Me.grbCV2.Controls.Add(Me.chk3V2)
        Me.grbCV2.Controls.Add(Me.chk4V2)
        Me.grbCV2.Controls.Add(Me.cbm1V2)
        Me.grbCV2.Controls.Add(Me.lbl4V2)
        Me.grbCV2.Location = New System.Drawing.Point(12, 59)
        Me.grbCV2.Name = "grbCV2"
        Me.grbCV2.Size = New System.Drawing.Size(245, 443)
        Me.grbCV2.TabIndex = 115
        Me.grbCV2.TabStop = False
        Me.grbCV2.Visible = False
        '
        'CheckBox2
        '
        Me.CheckBox2.AutoSize = True
        Me.CheckBox2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.CheckBox2.Location = New System.Drawing.Point(20, 292)
        Me.CheckBox2.Name = "CheckBox2"
        Me.CheckBox2.Size = New System.Drawing.Size(118, 28)
        Me.CheckBox2.TabIndex = 54
        Me.CheckBox2.Text = "Manga larga"
        Me.CheckBox2.UseVisualStyleBackColor = True
        '
        'msk4V2
        '
        Me.msk4V2.Enabled = False
        Me.msk4V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk4V2.Location = New System.Drawing.Point(151, 212)
        Me.msk4V2.Mask = "99999"
        Me.msk4V2.Name = "msk4V2"
        Me.msk4V2.Size = New System.Drawing.Size(71, 31)
        Me.msk4V2.TabIndex = 53
        Me.msk4V2.ValidatingType = GetType(Integer)
        '
        'msk3V2
        '
        Me.msk3V2.Enabled = False
        Me.msk3V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk3V2.Location = New System.Drawing.Point(151, 175)
        Me.msk3V2.Mask = "99999"
        Me.msk3V2.Name = "msk3V2"
        Me.msk3V2.Size = New System.Drawing.Size(71, 31)
        Me.msk3V2.TabIndex = 52
        Me.msk3V2.ValidatingType = GetType(Integer)
        '
        'msk2V2
        '
        Me.msk2V2.Enabled = False
        Me.msk2V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2V2.Location = New System.Drawing.Point(151, 135)
        Me.msk2V2.Mask = "99999"
        Me.msk2V2.Name = "msk2V2"
        Me.msk2V2.Size = New System.Drawing.Size(71, 31)
        Me.msk2V2.TabIndex = 51
        Me.msk2V2.ValidatingType = GetType(Integer)
        '
        'msk1V2
        '
        Me.msk1V2.Enabled = False
        Me.msk1V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1V2.Location = New System.Drawing.Point(151, 98)
        Me.msk1V2.Mask = "99999"
        Me.msk1V2.Name = "msk1V2"
        Me.msk1V2.Size = New System.Drawing.Size(71, 31)
        Me.msk1V2.TabIndex = 50
        Me.msk1V2.ValidatingType = GetType(Integer)
        '
        'chkRemV2
        '
        Me.chkRemV2.AutoSize = True
        Me.chkRemV2.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkRemV2.Location = New System.Drawing.Point(328, 25)
        Me.chkRemV2.Name = "chkRemV2"
        Me.chkRemV2.Size = New System.Drawing.Size(102, 35)
        Me.chkRemV2.TabIndex = 116
        Me.chkRemV2.Text = "Remera"
        Me.chkRemV2.UseVisualStyleBackColor = True
        '
        'chkPanV2
        '
        Me.chkPanV2.AutoSize = True
        Me.chkPanV2.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPanV2.Location = New System.Drawing.Point(575, 25)
        Me.chkPanV2.Name = "chkPanV2"
        Me.chkPanV2.Size = New System.Drawing.Size(117, 35)
        Me.chkPanV2.TabIndex = 117
        Me.chkPanV2.Text = "Pantalón"
        Me.chkPanV2.UseVisualStyleBackColor = True
        '
        'chkPulV2
        '
        Me.chkPulV2.AutoSize = True
        Me.chkPulV2.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkPulV2.Location = New System.Drawing.Point(815, 25)
        Me.chkPulV2.Name = "chkPulV2"
        Me.chkPulV2.Size = New System.Drawing.Size(104, 35)
        Me.chkPulV2.TabIndex = 118
        Me.chkPulV2.Text = "Pulóver"
        Me.chkPulV2.UseVisualStyleBackColor = True
        '
        'grbRemV2
        '
        Me.grbRemV2.Controls.Add(Me.CheckBox4)
        Me.grbRemV2.Controls.Add(Me.msk8V2)
        Me.grbRemV2.Controls.Add(Me.grb2V2)
        Me.grbRemV2.Controls.Add(Me.msk7V2)
        Me.grbRemV2.Controls.Add(Me.rb7V2)
        Me.grbRemV2.Controls.Add(Me.msk6V2)
        Me.grbRemV2.Controls.Add(Me.rb8V2)
        Me.grbRemV2.Controls.Add(Me.msk5V2)
        Me.grbRemV2.Controls.Add(Me.lbl7V2)
        Me.grbRemV2.Controls.Add(Me.lbl6V2)
        Me.grbRemV2.Controls.Add(Me.chk9V2)
        Me.grbRemV2.Controls.Add(Me.chk7V2)
        Me.grbRemV2.Controls.Add(Me.chk6V2)
        Me.grbRemV2.Controls.Add(Me.chk8V2)
        Me.grbRemV2.Controls.Add(Me.cbm2V2)
        Me.grbRemV2.Controls.Add(Me.lbl8V2)
        Me.grbRemV2.Location = New System.Drawing.Point(263, 59)
        Me.grbRemV2.Name = "grbRemV2"
        Me.grbRemV2.Size = New System.Drawing.Size(246, 443)
        Me.grbRemV2.TabIndex = 119
        Me.grbRemV2.TabStop = False
        Me.grbRemV2.Visible = False
        '
        'CheckBox4
        '
        Me.CheckBox4.AutoSize = True
        Me.CheckBox4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.CheckBox4.Location = New System.Drawing.Point(65, 292)
        Me.CheckBox4.Name = "CheckBox4"
        Me.CheckBox4.Size = New System.Drawing.Size(118, 28)
        Me.CheckBox4.TabIndex = 55
        Me.CheckBox4.Text = "Manga larga"
        Me.CheckBox4.UseVisualStyleBackColor = True
        '
        'msk8V2
        '
        Me.msk8V2.Enabled = False
        Me.msk8V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk8V2.Location = New System.Drawing.Point(146, 212)
        Me.msk8V2.Mask = "99999"
        Me.msk8V2.Name = "msk8V2"
        Me.msk8V2.Size = New System.Drawing.Size(71, 31)
        Me.msk8V2.TabIndex = 57
        Me.msk8V2.ValidatingType = GetType(Integer)
        '
        'msk7V2
        '
        Me.msk7V2.Enabled = False
        Me.msk7V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk7V2.Location = New System.Drawing.Point(146, 175)
        Me.msk7V2.Mask = "99999"
        Me.msk7V2.Name = "msk7V2"
        Me.msk7V2.Size = New System.Drawing.Size(71, 31)
        Me.msk7V2.TabIndex = 56
        Me.msk7V2.ValidatingType = GetType(Integer)
        '
        'msk6V2
        '
        Me.msk6V2.Enabled = False
        Me.msk6V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk6V2.Location = New System.Drawing.Point(146, 135)
        Me.msk6V2.Mask = "99999"
        Me.msk6V2.Name = "msk6V2"
        Me.msk6V2.Size = New System.Drawing.Size(71, 31)
        Me.msk6V2.TabIndex = 55
        Me.msk6V2.ValidatingType = GetType(Integer)
        '
        'msk5V2
        '
        Me.msk5V2.Enabled = False
        Me.msk5V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk5V2.Location = New System.Drawing.Point(146, 98)
        Me.msk5V2.Mask = "99999"
        Me.msk5V2.Name = "msk5V2"
        Me.msk5V2.Size = New System.Drawing.Size(71, 31)
        Me.msk5V2.TabIndex = 54
        Me.msk5V2.ValidatingType = GetType(Integer)
        '
        'grbPantV2
        '
        Me.grbPantV2.Controls.Add(Me.msk12V2)
        Me.grbPantV2.Controls.Add(Me.chk14V2)
        Me.grbPantV2.Controls.Add(Me.msk11V2)
        Me.grbPantV2.Controls.Add(Me.chk13V2)
        Me.grbPantV2.Controls.Add(Me.msk10V2)
        Me.grbPantV2.Controls.Add(Me.lbl10V2)
        Me.grbPantV2.Controls.Add(Me.msk9V2)
        Me.grbPantV2.Controls.Add(Me.chk12V2)
        Me.grbPantV2.Controls.Add(Me.rb13V2)
        Me.grbPantV2.Controls.Add(Me.cbm3V2)
        Me.grbPantV2.Controls.Add(Me.grb3V2)
        Me.grbPantV2.Controls.Add(Me.lbl12V2)
        Me.grbPantV2.Controls.Add(Me.chk15V2)
        Me.grbPantV2.Controls.Add(Me.lbl11V2)
        Me.grbPantV2.Controls.Add(Me.rb14V2)
        Me.grbPantV2.Location = New System.Drawing.Point(515, 59)
        Me.grbPantV2.Name = "grbPantV2"
        Me.grbPantV2.Size = New System.Drawing.Size(252, 422)
        Me.grbPantV2.TabIndex = 50
        Me.grbPantV2.TabStop = False
        Me.grbPantV2.Visible = False
        '
        'msk12V2
        '
        Me.msk12V2.Enabled = False
        Me.msk12V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk12V2.Location = New System.Drawing.Point(149, 209)
        Me.msk12V2.Mask = "99999"
        Me.msk12V2.Name = "msk12V2"
        Me.msk12V2.Size = New System.Drawing.Size(71, 31)
        Me.msk12V2.TabIndex = 61
        Me.msk12V2.ValidatingType = GetType(Integer)
        '
        'msk11V2
        '
        Me.msk11V2.Enabled = False
        Me.msk11V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk11V2.Location = New System.Drawing.Point(149, 172)
        Me.msk11V2.Mask = "99999"
        Me.msk11V2.Name = "msk11V2"
        Me.msk11V2.Size = New System.Drawing.Size(71, 31)
        Me.msk11V2.TabIndex = 60
        Me.msk11V2.ValidatingType = GetType(Integer)
        '
        'msk10V2
        '
        Me.msk10V2.Enabled = False
        Me.msk10V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk10V2.Location = New System.Drawing.Point(149, 132)
        Me.msk10V2.Mask = "99999"
        Me.msk10V2.Name = "msk10V2"
        Me.msk10V2.Size = New System.Drawing.Size(71, 31)
        Me.msk10V2.TabIndex = 59
        Me.msk10V2.ValidatingType = GetType(Integer)
        '
        'msk9V2
        '
        Me.msk9V2.Enabled = False
        Me.msk9V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk9V2.Location = New System.Drawing.Point(149, 95)
        Me.msk9V2.Mask = "99999"
        Me.msk9V2.Name = "msk9V2"
        Me.msk9V2.Size = New System.Drawing.Size(71, 31)
        Me.msk9V2.TabIndex = 58
        Me.msk9V2.ValidatingType = GetType(Integer)
        '
        'grbPulV2
        '
        Me.grbPulV2.Controls.Add(Me.msk16V2)
        Me.grbPulV2.Controls.Add(Me.rb17V2)
        Me.grbPulV2.Controls.Add(Me.msk15V2)
        Me.grbPulV2.Controls.Add(Me.grb4V2)
        Me.grbPulV2.Controls.Add(Me.msk14V2)
        Me.grbPulV2.Controls.Add(Me.rb18V2)
        Me.grbPulV2.Controls.Add(Me.msk13V2)
        Me.grbPulV2.Controls.Add(Me.lbl16V2)
        Me.grbPulV2.Controls.Add(Me.lbl15V2)
        Me.grbPulV2.Controls.Add(Me.lbl14V2)
        Me.grbPulV2.Controls.Add(Me.chk21V2)
        Me.grbPulV2.Controls.Add(Me.cbm4V2)
        Me.grbPulV2.Controls.Add(Me.chk20V2)
        Me.grbPulV2.Controls.Add(Me.chk19V2)
        Me.grbPulV2.Controls.Add(Me.chk18V2)
        Me.grbPulV2.Location = New System.Drawing.Point(773, 59)
        Me.grbPulV2.Name = "grbPulV2"
        Me.grbPulV2.Size = New System.Drawing.Size(246, 403)
        Me.grbPulV2.TabIndex = 120
        Me.grbPulV2.TabStop = False
        Me.grbPulV2.Visible = False
        '
        'msk16V2
        '
        Me.msk16V2.Enabled = False
        Me.msk16V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk16V2.Location = New System.Drawing.Point(147, 209)
        Me.msk16V2.Mask = "99999"
        Me.msk16V2.Name = "msk16V2"
        Me.msk16V2.Size = New System.Drawing.Size(71, 31)
        Me.msk16V2.TabIndex = 69
        Me.msk16V2.ValidatingType = GetType(Integer)
        '
        'msk15V2
        '
        Me.msk15V2.Enabled = False
        Me.msk15V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk15V2.Location = New System.Drawing.Point(147, 172)
        Me.msk15V2.Mask = "99999"
        Me.msk15V2.Name = "msk15V2"
        Me.msk15V2.Size = New System.Drawing.Size(71, 31)
        Me.msk15V2.TabIndex = 68
        Me.msk15V2.ValidatingType = GetType(Integer)
        '
        'msk14V2
        '
        Me.msk14V2.Enabled = False
        Me.msk14V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk14V2.Location = New System.Drawing.Point(147, 132)
        Me.msk14V2.Mask = "99999"
        Me.msk14V2.Name = "msk14V2"
        Me.msk14V2.Size = New System.Drawing.Size(71, 31)
        Me.msk14V2.TabIndex = 67
        Me.msk14V2.ValidatingType = GetType(Integer)
        '
        'msk13V2
        '
        Me.msk13V2.Enabled = False
        Me.msk13V2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk13V2.Location = New System.Drawing.Point(147, 95)
        Me.msk13V2.Mask = "99999"
        Me.msk13V2.Name = "msk13V2"
        Me.msk13V2.Size = New System.Drawing.Size(71, 31)
        Me.msk13V2.TabIndex = 66
        Me.msk13V2.ValidatingType = GetType(Integer)
        '
        'Ventas2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1020, 595)
        Me.Controls.Add(Me.chkPulV2)
        Me.Controls.Add(Me.chkPanV2)
        Me.Controls.Add(Me.chkRemV2)
        Me.Controls.Add(Me.chkCamV2)
        Me.Controls.Add(Me.btnCancelarV2)
        Me.Controls.Add(Me.btn1V2)
        Me.Controls.Add(Me.grbCV2)
        Me.Controls.Add(Me.grbRemV2)
        Me.Controls.Add(Me.grbPantV2)
        Me.Controls.Add(Me.grbPulV2)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Ventas2"
        Me.Text = "PEDIDO 2"
        Me.grb1V2.ResumeLayout(False)
        Me.grb1V2.PerformLayout()
        Me.panel1V2.ResumeLayout(False)
        Me.panel1V2.PerformLayout()
        Me.grb2V2.ResumeLayout(False)
        Me.grb2V2.PerformLayout()
        Me.panel2V2.ResumeLayout(False)
        Me.panel2V2.PerformLayout()
        Me.grb3V2.ResumeLayout(False)
        Me.grb3V2.PerformLayout()
        Me.grb4V2.ResumeLayout(False)
        Me.grb4V2.PerformLayout()
        Me.grbCV2.ResumeLayout(False)
        Me.grbCV2.PerformLayout()
        Me.grbRemV2.ResumeLayout(False)
        Me.grbRemV2.PerformLayout()
        Me.grbPantV2.ResumeLayout(False)
        Me.grbPantV2.PerformLayout()
        Me.grbPulV2.ResumeLayout(False)
        Me.grbPulV2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lineshape As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents btn1V2 As System.Windows.Forms.Button
    Friend WithEvents btnCancelarV2 As System.Windows.Forms.Button
    Friend WithEvents rb2V2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1V2 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl2V2 As System.Windows.Forms.Label
    Friend WithEvents chk2V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk5V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk1V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk3V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk4V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl5V2 As System.Windows.Forms.Label
    Friend WithEvents rb5V2 As System.Windows.Forms.RadioButton
    Friend WithEvents cbm1V2 As System.Windows.Forms.ComboBox
    Friend WithEvents rb6V2 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl3V2 As System.Windows.Forms.Label
    Friend WithEvents lbl4V2 As System.Windows.Forms.Label
    Friend WithEvents grb1V2 As System.Windows.Forms.GroupBox
    Friend WithEvents rb11V2 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl8V2 As System.Windows.Forms.Label
    Friend WithEvents rb12V2 As System.Windows.Forms.RadioButton
    Friend WithEvents cbm2V2 As System.Windows.Forms.ComboBox
    Friend WithEvents chk8V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk6V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk7V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl9V2 As System.Windows.Forms.Label
    Friend WithEvents chk9V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl6V2 As System.Windows.Forms.Label
    Friend WithEvents lbl7V2 As System.Windows.Forms.Label
    Friend WithEvents rb8V2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb7V2 As System.Windows.Forms.RadioButton
    Friend WithEvents grb2V2 As System.Windows.Forms.GroupBox
    Friend WithEvents chk11V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl12V2 As System.Windows.Forms.Label
    Friend WithEvents cbm3V2 As System.Windows.Forms.ComboBox
    Friend WithEvents chk12V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl13V2 As System.Windows.Forms.Label
    Friend WithEvents chk14V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk13V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk17V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl10V2 As System.Windows.Forms.Label
    Friend WithEvents rb13V2 As System.Windows.Forms.RadioButton
    Friend WithEvents grb3V2 As System.Windows.Forms.GroupBox
    Friend WithEvents rb15V2 As System.Windows.Forms.RadioButton
    Friend WithEvents chk16V2 As System.Windows.Forms.CheckBox
    Friend WithEvents rb16V2 As System.Windows.Forms.RadioButton
    Friend WithEvents chk15V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl11V2 As System.Windows.Forms.Label
    Friend WithEvents rb14V2 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl16V2 As System.Windows.Forms.Label
    Friend WithEvents cbm4V2 As System.Windows.Forms.ComboBox
    Friend WithEvents chk20V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk18V2 As System.Windows.Forms.CheckBox
    Friend WithEvents rb19V2 As System.Windows.Forms.RadioButton
    Friend WithEvents chk19V2 As System.Windows.Forms.CheckBox
    Friend WithEvents chk22V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl17V2 As System.Windows.Forms.Label
    Friend WithEvents chk21V2 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl14V2 As System.Windows.Forms.Label
    Friend WithEvents rb20V2 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl15V2 As System.Windows.Forms.Label
    Friend WithEvents rb18V2 As System.Windows.Forms.RadioButton
    Friend WithEvents rb17V2 As System.Windows.Forms.RadioButton
    Friend WithEvents grb4V2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkCamV2 As System.Windows.Forms.CheckBox
    Friend WithEvents grbCV2 As System.Windows.Forms.GroupBox
    Friend WithEvents chkRemV2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkPanV2 As System.Windows.Forms.CheckBox
    Friend WithEvents chkPulV2 As System.Windows.Forms.CheckBox
    Friend WithEvents grbRemV2 As System.Windows.Forms.GroupBox
    Friend WithEvents grbPantV2 As System.Windows.Forms.GroupBox
    Friend WithEvents grbPulV2 As System.Windows.Forms.GroupBox
    Friend WithEvents msk4V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk3V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk1V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk8V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk7V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk6V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk5V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk12V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk11V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk10V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk9V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk16V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk15V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk14V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk13V2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents panel1V2 As System.Windows.Forms.Panel
    Friend WithEvents panel2V2 As System.Windows.Forms.Panel
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox3 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox2 As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox4 As System.Windows.Forms.CheckBox
End Class
