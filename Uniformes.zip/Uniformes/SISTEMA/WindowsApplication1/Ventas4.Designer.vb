﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ventas4
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.msk1V4 = New System.Windows.Forms.MaskedTextBox()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.lbl1V4 = New System.Windows.Forms.Label()
        Me.precioV4 = New System.Windows.Forms.Label()
        Me.lbl2V4 = New System.Windows.Forms.Label()
        Me.grb1V4 = New System.Windows.Forms.GroupBox()
        Me.minimoV4 = New System.Windows.Forms.Label()
        Me.lbl3V4 = New System.Windows.Forms.Label()
        Me.btnCancelarV4 = New System.Windows.Forms.Button()
        Me.btn1V4 = New System.Windows.Forms.Button()
        Me.rb1V4 = New System.Windows.Forms.RadioButton()
        Me.rb2V4 = New System.Windows.Forms.RadioButton()
        Me.grb1V4.SuspendLayout()
        Me.SuspendLayout()
        '
        'msk1V4
        '
        Me.msk1V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1V4.Location = New System.Drawing.Point(94, 11)
        Me.msk1V4.Mask = "99999"
        Me.msk1V4.Name = "msk1V4"
        Me.msk1V4.Size = New System.Drawing.Size(61, 31)
        Me.msk1V4.TabIndex = 37
        Me.msk1V4.ValidatingType = GetType(Integer)
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(4, 3)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(275, 278)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(284, 285)
        Me.ShapeContainer1.TabIndex = 38
        Me.ShapeContainer1.TabStop = False
        '
        'lbl1V4
        '
        Me.lbl1V4.AutoSize = True
        Me.lbl1V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1V4.Location = New System.Drawing.Point(25, 19)
        Me.lbl1V4.Name = "lbl1V4"
        Me.lbl1V4.Size = New System.Drawing.Size(133, 24)
        Me.lbl1V4.TabIndex = 39
        Me.lbl1V4.Text = "El precio es de "
        '
        'precioV4
        '
        Me.precioV4.AutoSize = True
        Me.precioV4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.precioV4.Location = New System.Drawing.Point(164, 19)
        Me.precioV4.Name = "precioV4"
        Me.precioV4.Size = New System.Drawing.Size(16, 24)
        Me.precioV4.TabIndex = 40
        Me.precioV4.Text = "-"
        '
        'lbl2V4
        '
        Me.lbl2V4.AutoSize = True
        Me.lbl2V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2V4.Location = New System.Drawing.Point(74, 65)
        Me.lbl2V4.Name = "lbl2V4"
        Me.lbl2V4.Size = New System.Drawing.Size(122, 24)
        Me.lbl2V4.TabIndex = 41
        Me.lbl2V4.Text = "¿Desea señar?"
        '
        'grb1V4
        '
        Me.grb1V4.Controls.Add(Me.msk1V4)
        Me.grb1V4.Controls.Add(Me.minimoV4)
        Me.grb1V4.Controls.Add(Me.lbl3V4)
        Me.grb1V4.Location = New System.Drawing.Point(12, 115)
        Me.grb1V4.Name = "grb1V4"
        Me.grb1V4.Size = New System.Drawing.Size(260, 74)
        Me.grb1V4.TabIndex = 44
        Me.grb1V4.TabStop = False
        Me.grb1V4.Visible = False
        '
        'minimoV4
        '
        Me.minimoV4.AutoSize = True
        Me.minimoV4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.minimoV4.Location = New System.Drawing.Point(178, 47)
        Me.minimoV4.Name = "minimoV4"
        Me.minimoV4.Size = New System.Drawing.Size(19, 24)
        Me.minimoV4.TabIndex = 45
        Me.minimoV4.Text = "-"
        '
        'lbl3V4
        '
        Me.lbl3V4.AutoSize = True
        Me.lbl3V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3V4.Location = New System.Drawing.Point(6, 47)
        Me.lbl3V4.Name = "lbl3V4"
        Me.lbl3V4.Size = New System.Drawing.Size(144, 24)
        Me.lbl3V4.TabIndex = 45
        Me.lbl3V4.Text = "Con un mínimo de"
        '
        'btnCancelarV4
        '
        Me.btnCancelarV4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnCancelarV4.Location = New System.Drawing.Point(146, 195)
        Me.btnCancelarV4.Name = "btnCancelarV4"
        Me.btnCancelarV4.Size = New System.Drawing.Size(126, 82)
        Me.btnCancelarV4.TabIndex = 46
        Me.btnCancelarV4.Text = "Cancelar"
        Me.btnCancelarV4.UseVisualStyleBackColor = True
        '
        'btn1V4
        '
        Me.btn1V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1V4.Location = New System.Drawing.Point(17, 195)
        Me.btn1V4.Name = "btn1V4"
        Me.btn1V4.Size = New System.Drawing.Size(126, 82)
        Me.btn1V4.TabIndex = 45
        Me.btn1V4.Text = "Imprimir documentos y finalizar"
        Me.btn1V4.UseVisualStyleBackColor = True
        '
        'rb1V4
        '
        Me.rb1V4.AutoSize = True
        Me.rb1V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb1V4.Location = New System.Drawing.Point(99, 92)
        Me.rb1V4.Name = "rb1V4"
        Me.rb1V4.Size = New System.Drawing.Size(44, 28)
        Me.rb1V4.TabIndex = 47
        Me.rb1V4.TabStop = True
        Me.rb1V4.Text = "Sí"
        Me.rb1V4.UseVisualStyleBackColor = True
        '
        'rb2V4
        '
        Me.rb2V4.AutoSize = True
        Me.rb2V4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb2V4.Location = New System.Drawing.Point(149, 92)
        Me.rb2V4.Name = "rb2V4"
        Me.rb2V4.Size = New System.Drawing.Size(47, 28)
        Me.rb2V4.TabIndex = 48
        Me.rb2V4.TabStop = True
        Me.rb2V4.Text = "No"
        Me.rb2V4.UseVisualStyleBackColor = True
        '
        'Ventas4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 285)
        Me.Controls.Add(Me.btnCancelarV4)
        Me.Controls.Add(Me.rb2V4)
        Me.Controls.Add(Me.rb1V4)
        Me.Controls.Add(Me.btn1V4)
        Me.Controls.Add(Me.lbl2V4)
        Me.Controls.Add(Me.precioV4)
        Me.Controls.Add(Me.lbl1V4)
        Me.Controls.Add(Me.grb1V4)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Ventas4"
        Me.Text = "PEDIDO 4"
        Me.grb1V4.ResumeLayout(False)
        Me.grb1V4.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents msk1V4 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents lbl1V4 As System.Windows.Forms.Label
    Friend WithEvents precioV4 As System.Windows.Forms.Label
    Friend WithEvents lbl2V4 As System.Windows.Forms.Label
    Friend WithEvents grb1V4 As System.Windows.Forms.GroupBox
    Friend WithEvents minimoV4 As System.Windows.Forms.Label
    Friend WithEvents lbl3V4 As System.Windows.Forms.Label
    Friend WithEvents btnCancelarV4 As System.Windows.Forms.Button
    Friend WithEvents btn1V4 As System.Windows.Forms.Button
    Friend WithEvents rb1V4 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2V4 As System.Windows.Forms.RadioButton
End Class
