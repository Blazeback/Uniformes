﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AEProveedores
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.msk3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk4 = New System.Windows.Forms.MaskedTextBox()
        Me.rb3 = New System.Windows.Forms.RadioButton()
        Me.rb4 = New System.Windows.Forms.RadioButton()
        Me.rb1 = New System.Windows.Forms.RadioButton()
        Me.rb2 = New System.Windows.Forms.RadioButton()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.grb1 = New System.Windows.Forms.GroupBox()
        Me.grb2 = New System.Windows.Forms.GroupBox()
        Me.grb1.SuspendLayout()
        Me.grb2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(347, 439)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(108, 29)
        Me.btn2.TabIndex = 0
        Me.btn2.Text = "Volver"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(347, 404)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(108, 29)
        Me.btn1.TabIndex = 1
        Me.btn1.Text = "Continuar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4.Location = New System.Drawing.Point(12, 220)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(76, 23)
        Me.lbl4.TabIndex = 2
        Me.lbl4.Text = "Direccion"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3.Location = New System.Drawing.Point(12, 160)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(147, 23)
        Me.lbl3.TabIndex = 3
        Me.lbl3.Text = "Nombre y apellido"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(236, 101)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(77, 23)
        Me.lbl2.TabIndex = 4
        Me.lbl2.Text = "Teléfono"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1.Location = New System.Drawing.Point(12, 101)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(75, 23)
        Me.lbl1.TabIndex = 5
        Me.lbl1.Text = "num Cuit"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5.Location = New System.Drawing.Point(12, 279)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(80, 23)
        Me.lbl5.TabIndex = 6
        Me.lbl5.Text = "Localidad"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.Label6.Location = New System.Drawing.Point(12, 338)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 23)
        Me.Label6.TabIndex = 7
        Me.Label6.Text = "Mail"
        '
        'msk3
        '
        Me.msk3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk3.Location = New System.Drawing.Point(16, 188)
        Me.msk3.Mask = "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"
        Me.msk3.Name = "msk3"
        Me.msk3.Size = New System.Drawing.Size(439, 31)
        Me.msk3.TabIndex = 8
        '
        'msk2
        '
        Me.msk2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2.Location = New System.Drawing.Point(240, 128)
        Me.msk2.Mask = "00000000"
        Me.msk2.Name = "msk2"
        Me.msk2.Size = New System.Drawing.Size(91, 31)
        Me.msk2.TabIndex = 9
        '
        'msk1
        '
        Me.msk1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(16, 128)
        Me.msk1.Mask = "00000000-00"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(119, 31)
        Me.msk1.TabIndex = 10
        '
        'msk4
        '
        Me.msk4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk4.Location = New System.Drawing.Point(16, 306)
        Me.msk4.Mask = "LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL"
        Me.msk4.Name = "msk4"
        Me.msk4.Size = New System.Drawing.Size(439, 31)
        Me.msk4.TabIndex = 11
        '
        'rb3
        '
        Me.rb3.AutoSize = True
        Me.rb3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb3.Location = New System.Drawing.Point(40, 28)
        Me.rb3.Name = "rb3"
        Me.rb3.Size = New System.Drawing.Size(90, 27)
        Me.rb3.TabIndex = 12
        Me.rb3.TabStop = True
        Me.rb3.Text = "Bordado"
        Me.rb3.UseVisualStyleBackColor = True
        '
        'rb4
        '
        Me.rb4.AutoSize = True
        Me.rb4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb4.Location = New System.Drawing.Point(146, 28)
        Me.rb4.Name = "rb4"
        Me.rb4.Size = New System.Drawing.Size(107, 27)
        Me.rb4.TabIndex = 13
        Me.rb4.TabStop = True
        Me.rb4.Text = "Materiales"
        Me.rb4.UseVisualStyleBackColor = True
        '
        'rb1
        '
        Me.rb1.AutoSize = True
        Me.rb1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb1.Location = New System.Drawing.Point(24, 29)
        Me.rb1.Name = "rb1"
        Me.rb1.Size = New System.Drawing.Size(89, 27)
        Me.rb1.TabIndex = 14
        Me.rb1.TabStop = True
        Me.rb1.Text = "Agregar"
        Me.rb1.UseVisualStyleBackColor = True
        '
        'rb2
        '
        Me.rb2.AutoSize = True
        Me.rb2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb2.Location = New System.Drawing.Point(126, 29)
        Me.rb2.Name = "rb2"
        Me.rb2.Size = New System.Drawing.Size(86, 27)
        Me.rb2.TabIndex = 15
        Me.rb2.TabStop = True
        Me.rb2.Text = "Eliminar"
        Me.rb2.UseVisualStyleBackColor = True
        '
        'txt1
        '
        Me.txt1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt1.Location = New System.Drawing.Point(16, 247)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(439, 31)
        Me.txt1.TabIndex = 16
        '
        'txt2
        '
        Me.txt2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt2.Location = New System.Drawing.Point(16, 365)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(439, 31)
        Me.txt2.TabIndex = 17
        '
        'grb1
        '
        Me.grb1.Controls.Add(Me.rb2)
        Me.grb1.Controls.Add(Me.rb1)
        Me.grb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb1.Location = New System.Drawing.Point(12, 12)
        Me.grb1.Name = "grb1"
        Me.grb1.Size = New System.Drawing.Size(232, 69)
        Me.grb1.TabIndex = 18
        Me.grb1.TabStop = False
        '
        'grb2
        '
        Me.grb2.Controls.Add(Me.rb4)
        Me.grb2.Controls.Add(Me.rb3)
        Me.grb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grb2.Location = New System.Drawing.Point(16, 400)
        Me.grb2.Name = "grb2"
        Me.grb2.Size = New System.Drawing.Size(307, 64)
        Me.grb2.TabIndex = 19
        Me.grb2.TabStop = False
        '
        'AEProveedores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(478, 492)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.grb1)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.grb2)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.txt2)
        Me.Controls.Add(Me.msk4)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.msk2)
        Me.Controls.Add(Me.msk3)
        Me.Name = "AEProveedores"
        Me.Text = "PROVEEDORES"
        Me.grb1.ResumeLayout(False)
        Me.grb1.PerformLayout()
        Me.grb2.ResumeLayout(False)
        Me.grb2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents msk3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk4 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents rb3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb4 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1 As System.Windows.Forms.RadioButton
    Friend WithEvents rb2 As System.Windows.Forms.RadioButton
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents txt2 As System.Windows.Forms.TextBox
    Friend WithEvents grb1 As System.Windows.Forms.GroupBox
    Friend WithEvents grb2 As System.Windows.Forms.GroupBox
End Class
