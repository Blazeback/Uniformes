﻿Imports System.Data.Odbc

Public Class RemitoCliente

    Private Sub RemitoCliente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Tables.Add("REM")
        sql = "SELECT articulo, cantidad FROM NP WHERE idNP='" & npentrega & "'"
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("REM"))
        Me.grdREMC.DataSource = ds.Tables("REM")
    End Sub

    Private Sub btnSalirREMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirREMC.Click
        Me.Hide()
        grdREMC.DataSource.clear()
        Principal.Show()
    End Sub

    Private Sub btn1REMC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1REMC.Click
        Try
            prf1REMC.Print()
            grdREMC.DataSource.clear()
        Catch ex As Exception
            MsgBox("La impresión ha sido cancelada.", MsgBoxStyle.Exclamation, "ERROR")
            Me.Show()
        End Try
    End Sub
End Class