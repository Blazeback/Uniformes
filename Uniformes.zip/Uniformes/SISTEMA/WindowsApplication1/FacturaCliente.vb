﻿Imports System.Data.Odbc

Public Class FacturaCliente


    Private Sub FacturaCliente_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If bfact <> 1 Then
            bfact = 1
            ds.Tables.Add("Fact")
            sql = "SELECT cantidad CANTIDAD, articulo ARTICULO, preciounitario PRECIOUNITARIO, total TOTAL FROM NP"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("Fact"))
            Me.grdFAC.DataSource = ds.Tables("Fact")
        Else
            sql = "SELECT cantidad CANTIDAD, articulo ARTICULO, preciounitario PRECIOUNITARIO, total TOTAL FROM NP"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("Fact"))
            Me.grdFAC.DataSource = ds.Tables("Fact")
        End If
    End Sub

    Private Sub btn1Factura_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1Factura.Click
        Try
            pf1Factura.Print()
            grdFAC.DataSource.clear()
        Catch ex As Exception
            MsgBox("La impresión ha sido cancelada.", MsgBoxStyle.Exclamation, "ERROR")
            Me.Show()
        End Try
    End Sub

    Private Sub btnSalirFactura_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirFactura.Click
        Me.Close()
        grdFAC.DataSource.clear()
        If banderaconfeccion = 1 Then
            OrdenConfeccion.Show()
        Else
            Principal.Show()
        End If
    End Sub
End Class