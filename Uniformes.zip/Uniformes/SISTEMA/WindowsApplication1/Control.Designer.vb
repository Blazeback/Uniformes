﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Control
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1C = New System.Windows.Forms.Button()
        Me.btnSalirC = New System.Windows.Forms.Button()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape2 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.btn2C = New System.Windows.Forms.Button()
        Me.grd1C = New System.Windows.Forms.DataGridView()
        Me.btn3C = New System.Windows.Forms.Button()
        Me.btn4C = New System.Windows.Forms.Button()
        Me.btn5C = New System.Windows.Forms.Button()
        Me.btn6C = New System.Windows.Forms.Button()
        Me.btn7C = New System.Windows.Forms.Button()
        Me.btn8C = New System.Windows.Forms.Button()
        Me.lbl2V2 = New System.Windows.Forms.Label()
        Me.cbm1C = New System.Windows.Forms.ComboBox()
        Me.btn9C = New System.Windows.Forms.Button()
        Me.btn10C = New System.Windows.Forms.Button()
        Me.btn11C = New System.Windows.Forms.Button()
        Me.btn12C = New System.Windows.Forms.Button()
        Me.btn13C = New System.Windows.Forms.Button()
        Me.btn14C = New System.Windows.Forms.Button()
        Me.btn15C = New System.Windows.Forms.Button()
        Me.btn16C = New System.Windows.Forms.Button()
        Me.cuotasC = New System.Windows.Forms.Button()
        Me.btn17C = New System.Windows.Forms.Button()
        Me.btn18C = New System.Windows.Forms.Button()
        Me.btn19C = New System.Windows.Forms.Button()
        CType(Me.grd1C, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn1C
        '
        Me.btn1C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1C.Location = New System.Drawing.Point(38, 12)
        Me.btn1C.Name = "btn1C"
        Me.btn1C.Size = New System.Drawing.Size(158, 44)
        Me.btn1C.TabIndex = 10
        Me.btn1C.Text = "Clientes"
        Me.btn1C.UseVisualStyleBackColor = True
        '
        'btnSalirC
        '
        Me.btnSalirC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnSalirC.Location = New System.Drawing.Point(12, 591)
        Me.btnSalirC.Name = "btnSalirC"
        Me.btnSalirC.Size = New System.Drawing.Size(88, 31)
        Me.btnSalirC.TabIndex = 12
        Me.btnSalirC.Text = "Volver"
        Me.btnSalirC.UseVisualStyleBackColor = True
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape2, Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1202, 638)
        Me.ShapeContainer1.TabIndex = 13
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape2
        '
        Me.RectangleShape2.BorderWidth = 2
        Me.RectangleShape2.Location = New System.Drawing.Point(6, 582)
        Me.RectangleShape2.Name = "RectangleShape2"
        Me.RectangleShape2.Size = New System.Drawing.Size(101, 47)
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(6, 4)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(1187, 625)
        '
        'btn2C
        '
        Me.btn2C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2C.Location = New System.Drawing.Point(38, 62)
        Me.btn2C.Name = "btn2C"
        Me.btn2C.Size = New System.Drawing.Size(158, 44)
        Me.btn2C.TabIndex = 14
        Me.btn2C.Text = "Usuarios"
        Me.btn2C.UseVisualStyleBackColor = True
        '
        'grd1C
        '
        Me.grd1C.AllowUserToAddRows = False
        Me.grd1C.AllowUserToDeleteRows = False
        Me.grd1C.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grd1C.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd1C.Location = New System.Drawing.Point(227, 12)
        Me.grd1C.Name = "grd1C"
        Me.grd1C.ReadOnly = True
        Me.grd1C.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grd1C.Size = New System.Drawing.Size(958, 610)
        Me.grd1C.TabIndex = 15
        '
        'btn3C
        '
        Me.btn3C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn3C.Location = New System.Drawing.Point(1010, 89)
        Me.btn3C.Name = "btn3C"
        Me.btn3C.Size = New System.Drawing.Size(158, 57)
        Me.btn3C.TabIndex = 17
        Me.btn3C.Text = "Agregar/eliminar usuarios"
        Me.btn3C.UseVisualStyleBackColor = True
        Me.btn3C.Visible = False
        '
        'btn4C
        '
        Me.btn4C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn4C.Location = New System.Drawing.Point(38, 112)
        Me.btn4C.Name = "btn4C"
        Me.btn4C.Size = New System.Drawing.Size(158, 56)
        Me.btn4C.TabIndex = 18
        Me.btn4C.Text = "Tipos de ropa"
        Me.btn4C.UseVisualStyleBackColor = True
        '
        'btn5C
        '
        Me.btn5C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn5C.Location = New System.Drawing.Point(38, 174)
        Me.btn5C.Name = "btn5C"
        Me.btn5C.Size = New System.Drawing.Size(158, 44)
        Me.btn5C.TabIndex = 19
        Me.btn5C.Text = "Talles"
        Me.btn5C.UseVisualStyleBackColor = True
        '
        'btn6C
        '
        Me.btn6C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn6C.Location = New System.Drawing.Point(38, 224)
        Me.btn6C.Name = "btn6C"
        Me.btn6C.Size = New System.Drawing.Size(158, 44)
        Me.btn6C.TabIndex = 20
        Me.btn6C.Text = "Detalles"
        Me.btn6C.UseVisualStyleBackColor = True
        '
        'btn7C
        '
        Me.btn7C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn7C.Location = New System.Drawing.Point(38, 274)
        Me.btn7C.Name = "btn7C"
        Me.btn7C.Size = New System.Drawing.Size(158, 44)
        Me.btn7C.TabIndex = 21
        Me.btn7C.Text = "Colores"
        Me.btn7C.UseVisualStyleBackColor = True
        '
        'btn8C
        '
        Me.btn8C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn8C.Location = New System.Drawing.Point(38, 324)
        Me.btn8C.Name = "btn8C"
        Me.btn8C.Size = New System.Drawing.Size(158, 58)
        Me.btn8C.TabIndex = 22
        Me.btn8C.Text = "Ropa, talles, color y stock"
        Me.btn8C.UseVisualStyleBackColor = True
        '
        'lbl2V2
        '
        Me.lbl2V2.AutoSize = True
        Me.lbl2V2.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2V2.Location = New System.Drawing.Point(12, 385)
        Me.lbl2V2.Name = "lbl2V2"
        Me.lbl2V2.Size = New System.Drawing.Size(108, 27)
        Me.lbl2V2.TabIndex = 28
        Me.lbl2V2.Text = "Documentos:"
        '
        'cbm1C
        '
        Me.cbm1C.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm1C.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbm1C.FormattingEnabled = True
        Me.cbm1C.Items.AddRange(New Object() {"Notas de pedido", "Órdenes de compra", "Remitos cliente", "Facturas", "Órdenes confección"})
        Me.cbm1C.Location = New System.Drawing.Point(18, 419)
        Me.cbm1C.Name = "cbm1C"
        Me.cbm1C.Size = New System.Drawing.Size(196, 35)
        Me.cbm1C.TabIndex = 29
        '
        'btn9C
        '
        Me.btn9C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn9C.Location = New System.Drawing.Point(38, 468)
        Me.btn9C.Name = "btn9C"
        Me.btn9C.Size = New System.Drawing.Size(158, 56)
        Me.btn9C.TabIndex = 30
        Me.btn9C.Text = "Bordados encargados"
        Me.btn9C.UseVisualStyleBackColor = True
        '
        'btn10C
        '
        Me.btn10C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn10C.Location = New System.Drawing.Point(38, 530)
        Me.btn10C.Name = "btn10C"
        Me.btn10C.Size = New System.Drawing.Size(158, 44)
        Me.btn10C.TabIndex = 31
        Me.btn10C.Text = "Proveedores"
        Me.btn10C.UseVisualStyleBackColor = True
        '
        'btn11C
        '
        Me.btn11C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn11C.Location = New System.Drawing.Point(1010, 152)
        Me.btn11C.Name = "btn11C"
        Me.btn11C.Size = New System.Drawing.Size(158, 33)
        Me.btn11C.TabIndex = 32
        Me.btn11C.Text = "Eliminar clientes"
        Me.btn11C.UseVisualStyleBackColor = True
        Me.btn11C.Visible = False
        '
        'btn12C
        '
        Me.btn12C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn12C.Location = New System.Drawing.Point(1010, 191)
        Me.btn12C.Name = "btn12C"
        Me.btn12C.Size = New System.Drawing.Size(158, 57)
        Me.btn12C.TabIndex = 33
        Me.btn12C.Text = "Agregar/eliminar tipos de ropa"
        Me.btn12C.UseVisualStyleBackColor = True
        Me.btn12C.Visible = False
        '
        'btn13C
        '
        Me.btn13C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn13C.Location = New System.Drawing.Point(1010, 254)
        Me.btn13C.Name = "btn13C"
        Me.btn13C.Size = New System.Drawing.Size(158, 57)
        Me.btn13C.TabIndex = 34
        Me.btn13C.Text = "Agregar/eliminar talles"
        Me.btn13C.UseVisualStyleBackColor = True
        Me.btn13C.Visible = False
        '
        'btn14C
        '
        Me.btn14C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn14C.Location = New System.Drawing.Point(1010, 317)
        Me.btn14C.Name = "btn14C"
        Me.btn14C.Size = New System.Drawing.Size(158, 57)
        Me.btn14C.TabIndex = 35
        Me.btn14C.Text = "Agregar/eliminar detalles"
        Me.btn14C.UseVisualStyleBackColor = True
        Me.btn14C.Visible = False
        '
        'btn15C
        '
        Me.btn15C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn15C.Location = New System.Drawing.Point(1010, 378)
        Me.btn15C.Name = "btn15C"
        Me.btn15C.Size = New System.Drawing.Size(158, 57)
        Me.btn15C.TabIndex = 36
        Me.btn15C.Text = "Agregar/eliminar colores"
        Me.btn15C.UseVisualStyleBackColor = True
        Me.btn15C.Visible = False
        '
        'btn16C
        '
        Me.btn16C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn16C.Location = New System.Drawing.Point(1010, 441)
        Me.btn16C.Name = "btn16C"
        Me.btn16C.Size = New System.Drawing.Size(158, 57)
        Me.btn16C.TabIndex = 37
        Me.btn16C.Text = "Agregar/eliminar proveedores"
        Me.btn16C.UseVisualStyleBackColor = True
        Me.btn16C.Visible = False
        '
        'cuotasC
        '
        Me.cuotasC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cuotasC.Location = New System.Drawing.Point(137, 580)
        Me.cuotasC.Name = "cuotasC"
        Me.cuotasC.Size = New System.Drawing.Size(84, 41)
        Me.cuotasC.TabIndex = 38
        Me.cuotasC.Text = "Cuotas"
        Me.cuotasC.UseVisualStyleBackColor = True
        '
        'btn17C
        '
        Me.btn17C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn17C.Location = New System.Drawing.Point(1010, 504)
        Me.btn17C.Name = "btn17C"
        Me.btn17C.Size = New System.Drawing.Size(158, 56)
        Me.btn17C.TabIndex = 39
        Me.btn17C.Text = "Agregar stock"
        Me.btn17C.UseVisualStyleBackColor = True
        '
        'btn18C
        '
        Me.btn18C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn18C.Location = New System.Drawing.Point(1010, 565)
        Me.btn18C.Name = "btn18C"
        Me.btn18C.Size = New System.Drawing.Size(158, 56)
        Me.btn18C.TabIndex = 40
        Me.btn18C.Text = "Modificar precios"
        Me.btn18C.UseVisualStyleBackColor = True
        '
        'btn19C
        '
        Me.btn19C.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn19C.Location = New System.Drawing.Point(1010, 25)
        Me.btn19C.Name = "btn19C"
        Me.btn19C.Size = New System.Drawing.Size(158, 58)
        Me.btn19C.TabIndex = 41
        Me.btn19C.Text = "Registrar llegada de bordados"
        Me.btn19C.UseVisualStyleBackColor = True
        Me.btn19C.Visible = False
        '
        'Control
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1202, 638)
        Me.Controls.Add(Me.btn19C)
        Me.Controls.Add(Me.btn18C)
        Me.Controls.Add(Me.btn17C)
        Me.Controls.Add(Me.cuotasC)
        Me.Controls.Add(Me.btn16C)
        Me.Controls.Add(Me.btn15C)
        Me.Controls.Add(Me.btn14C)
        Me.Controls.Add(Me.btn13C)
        Me.Controls.Add(Me.btn12C)
        Me.Controls.Add(Me.btn11C)
        Me.Controls.Add(Me.btn10C)
        Me.Controls.Add(Me.btn9C)
        Me.Controls.Add(Me.cbm1C)
        Me.Controls.Add(Me.lbl2V2)
        Me.Controls.Add(Me.btn8C)
        Me.Controls.Add(Me.btn7C)
        Me.Controls.Add(Me.btn6C)
        Me.Controls.Add(Me.btn5C)
        Me.Controls.Add(Me.btn4C)
        Me.Controls.Add(Me.btn3C)
        Me.Controls.Add(Me.grd1C)
        Me.Controls.Add(Me.btn2C)
        Me.Controls.Add(Me.btnSalirC)
        Me.Controls.Add(Me.btn1C)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Control"
        Me.Text = "CONTROL"
        CType(Me.grd1C, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1C As System.Windows.Forms.Button
    Friend WithEvents btnSalirC As System.Windows.Forms.Button
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape2 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents btn2C As System.Windows.Forms.Button
    Friend WithEvents grd1C As System.Windows.Forms.DataGridView
    Friend WithEvents btn3C As System.Windows.Forms.Button
    Friend WithEvents btn4C As System.Windows.Forms.Button
    Friend WithEvents btn5C As System.Windows.Forms.Button
    Friend WithEvents btn6C As System.Windows.Forms.Button
    Friend WithEvents btn7C As System.Windows.Forms.Button
    Friend WithEvents btn8C As System.Windows.Forms.Button
    Friend WithEvents lbl2V2 As System.Windows.Forms.Label
    Friend WithEvents cbm1C As System.Windows.Forms.ComboBox
    Friend WithEvents btn9C As System.Windows.Forms.Button
    Friend WithEvents btn10C As System.Windows.Forms.Button
    Friend WithEvents btn11C As System.Windows.Forms.Button
    Friend WithEvents btn12C As System.Windows.Forms.Button
    Friend WithEvents btn13C As System.Windows.Forms.Button
    Friend WithEvents btn14C As System.Windows.Forms.Button
    Friend WithEvents btn15C As System.Windows.Forms.Button
    Friend WithEvents btn16C As System.Windows.Forms.Button
    Friend WithEvents cuotasC As System.Windows.Forms.Button
    Friend WithEvents btn17C As System.Windows.Forms.Button
    Friend WithEvents btn18C As System.Windows.Forms.Button
    Friend WithEvents btn19C As System.Windows.Forms.Button
End Class
