﻿Imports System.Data.Odbc

Public Class CierreCaja

    Private Sub CierreCaja_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If bcc <> 1 Then
            bcc = 1
            ds.Tables.Add("CC")
        End If

        sql = "SELECT SUM(importe) FROM factura WHERE fecha=(SELECT curdate())"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Try
            If rs.Read = True Then
                If rs(0) > 0 Then
                    montoCC.Text = rs(0)
                Else
                    montoCC.Text = 0
                End If
            End If
        Catch ex As Exception
            montoCC.Text = 0
        End Try

        sql = "SELECT curdate()"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            fechaCC.Text = rs(0)
        End If
        sql = "SELECT* FROM CIERRECAJA"
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("CC"))
        Me.grdCC.DataSource = ds.Tables("CC")
        grdCC.DataSource.clear()
        sql = "SELECT* FROM CIERRECAJA"
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("CC"))
        Me.grdCC.DataSource = ds.Tables("CC")
    End Sub

    Private Sub btn2V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2V.Click
        Me.Close()
        Principal.Show()
    End Sub

    Private Sub registrarCC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles registrarCC.Click
        sql = "SELECT COUNT(*) FROM factura WHERE fecha=(SELECT curdate())"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) > 0 Then
                sql = "SELECT SUM(importe) FROM factura WHERE fecha=(SELECT curdate())"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    sql = "INSERT INTO CIERRECAJA VALUES('', curdate(), '" & rs(0) & "')"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    MsgBox("¡Carga exitosa!", MsgBoxStyle.Exclamation, "EXITO")
                    Principal.lst1P.Items.Remove(0)
                    Me.Close()
                    Principal.Show()
                End If
            Else
                MsgBox("¡Hoy no se realizó ninguna venta!", MsgBoxStyle.Exclamation, "ERROR")
            End If
        End If
        
    End Sub
End Class