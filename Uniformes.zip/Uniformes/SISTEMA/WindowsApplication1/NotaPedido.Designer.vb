﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NotaPedido
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(NotaPedido))
        Me.pcb1NP = New System.Windows.Forms.PictureBox()
        Me.FechaNP = New System.Windows.Forms.Label()
        Me.CodigoNP = New System.Windows.Forms.Label()
        Me.NombreApellidoNP = New System.Windows.Forms.Label()
        Me.DireccionNP = New System.Windows.Forms.Label()
        Me.TelNP = New System.Windows.Forms.Label()
        Me.SeñaNP = New System.Windows.Forms.Label()
        Me.FechaEntregaNP = New System.Windows.Forms.Label()
        Me.TotalNP = New System.Windows.Forms.Label()
        Me.btnSalirNP = New System.Windows.Forms.Button()
        Me.btn1NP = New System.Windows.Forms.Button()
        Me.pf1NP = New Microsoft.VisualBasic.PowerPacks.Printing.PrintForm(Me.components)
        Me.grdNP = New System.Windows.Forms.DataGridView()
        Me.CodigoNPNP = New System.Windows.Forms.Label()
        CType(Me.pcb1NP, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.grdNP, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pcb1NP
        '
        Me.pcb1NP.Image = CType(resources.GetObject("pcb1NP.Image"), System.Drawing.Image)
        Me.pcb1NP.Location = New System.Drawing.Point(-2, -3)
        Me.pcb1NP.Name = "pcb1NP"
        Me.pcb1NP.Size = New System.Drawing.Size(830, 640)
        Me.pcb1NP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pcb1NP.TabIndex = 0
        Me.pcb1NP.TabStop = False
        '
        'FechaNP
        '
        Me.FechaNP.AutoSize = True
        Me.FechaNP.BackColor = System.Drawing.Color.White
        Me.FechaNP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FechaNP.Location = New System.Drawing.Point(626, 20)
        Me.FechaNP.Name = "FechaNP"
        Me.FechaNP.Size = New System.Drawing.Size(110, 23)
        Me.FechaNP.TabIndex = 23
        Me.FechaNP.Text = "0000-00-00"
        '
        'CodigoNP
        '
        Me.CodigoNP.AutoSize = True
        Me.CodigoNP.BackColor = System.Drawing.Color.White
        Me.CodigoNP.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CodigoNP.Location = New System.Drawing.Point(321, 88)
        Me.CodigoNP.Name = "CodigoNP"
        Me.CodigoNP.Size = New System.Drawing.Size(35, 16)
        Me.CodigoNP.TabIndex = 24
        Me.CodigoNP.Text = "NULO"
        '
        'NombreApellidoNP
        '
        Me.NombreApellidoNP.AutoSize = True
        Me.NombreApellidoNP.BackColor = System.Drawing.Color.White
        Me.NombreApellidoNP.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NombreApellidoNP.Location = New System.Drawing.Point(321, 113)
        Me.NombreApellidoNP.Name = "NombreApellidoNP"
        Me.NombreApellidoNP.Size = New System.Drawing.Size(35, 16)
        Me.NombreApellidoNP.TabIndex = 25
        Me.NombreApellidoNP.Text = "NULO"
        '
        'DireccionNP
        '
        Me.DireccionNP.AutoSize = True
        Me.DireccionNP.BackColor = System.Drawing.Color.White
        Me.DireccionNP.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DireccionNP.Location = New System.Drawing.Point(321, 140)
        Me.DireccionNP.Name = "DireccionNP"
        Me.DireccionNP.Size = New System.Drawing.Size(35, 16)
        Me.DireccionNP.TabIndex = 26
        Me.DireccionNP.Text = "NULO"
        '
        'TelNP
        '
        Me.TelNP.AutoSize = True
        Me.TelNP.BackColor = System.Drawing.Color.White
        Me.TelNP.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TelNP.Location = New System.Drawing.Point(663, 140)
        Me.TelNP.Name = "TelNP"
        Me.TelNP.Size = New System.Drawing.Size(35, 16)
        Me.TelNP.TabIndex = 27
        Me.TelNP.Text = "NULO"
        '
        'SeñaNP
        '
        Me.SeñaNP.AutoSize = True
        Me.SeñaNP.BackColor = System.Drawing.Color.White
        Me.SeñaNP.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SeñaNP.Location = New System.Drawing.Point(183, 493)
        Me.SeñaNP.Name = "SeñaNP"
        Me.SeñaNP.Size = New System.Drawing.Size(16, 19)
        Me.SeñaNP.TabIndex = 28
        Me.SeñaNP.Text = "-"
        '
        'FechaEntregaNP
        '
        Me.FechaEntregaNP.AutoSize = True
        Me.FechaEntregaNP.BackColor = System.Drawing.Color.White
        Me.FechaEntregaNP.Font = New System.Drawing.Font("ISOCPEUR", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FechaEntregaNP.Location = New System.Drawing.Point(399, 525)
        Me.FechaEntregaNP.Name = "FechaEntregaNP"
        Me.FechaEntregaNP.Size = New System.Drawing.Size(16, 19)
        Me.FechaEntregaNP.TabIndex = 29
        Me.FechaEntregaNP.Text = "-"
        '
        'TotalNP
        '
        Me.TotalNP.AutoSize = True
        Me.TotalNP.BackColor = System.Drawing.Color.White
        Me.TotalNP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalNP.Location = New System.Drawing.Point(720, 513)
        Me.TotalNP.Name = "TotalNP"
        Me.TotalNP.Size = New System.Drawing.Size(20, 23)
        Me.TotalNP.TabIndex = 31
        Me.TotalNP.Text = "-"
        '
        'btnSalirNP
        '
        Me.btnSalirNP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalirNP.Location = New System.Drawing.Point(406, 598)
        Me.btnSalirNP.Name = "btnSalirNP"
        Me.btnSalirNP.Size = New System.Drawing.Size(141, 39)
        Me.btnSalirNP.TabIndex = 71
        Me.btnSalirNP.Text = "Salir"
        Me.btnSalirNP.UseVisualStyleBackColor = True
        '
        'btn1NP
        '
        Me.btn1NP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1NP.Location = New System.Drawing.Point(244, 598)
        Me.btn1NP.Name = "btn1NP"
        Me.btn1NP.Size = New System.Drawing.Size(141, 39)
        Me.btn1NP.TabIndex = 70
        Me.btn1NP.Text = "Imprimir"
        Me.btn1NP.UseVisualStyleBackColor = True
        '
        'pf1NP
        '
        Me.pf1NP.DocumentName = "document"
        Me.pf1NP.Form = Me
        Me.pf1NP.PrintAction = System.Drawing.Printing.PrintAction.PrintToPrinter
        Me.pf1NP.PrinterSettings = CType(resources.GetObject("pf1NP.PrinterSettings"), System.Drawing.Printing.PrinterSettings)
        Me.pf1NP.PrintFileName = Nothing
        '
        'grdNP
        '
        Me.grdNP.AllowUserToAddRows = False
        Me.grdNP.AllowUserToDeleteRows = False
        Me.grdNP.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdNP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdNP.Location = New System.Drawing.Point(-2, 195)
        Me.grdNP.Name = "grdNP"
        Me.grdNP.ReadOnly = True
        Me.grdNP.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdNP.Size = New System.Drawing.Size(830, 295)
        Me.grdNP.TabIndex = 72
        '
        'CodigoNPNP
        '
        Me.CodigoNPNP.AutoSize = True
        Me.CodigoNPNP.BackColor = System.Drawing.Color.White
        Me.CodigoNPNP.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CodigoNPNP.Location = New System.Drawing.Point(521, 9)
        Me.CodigoNPNP.Name = "CodigoNPNP"
        Me.CodigoNPNP.Size = New System.Drawing.Size(14, 16)
        Me.CodigoNPNP.TabIndex = 73
        Me.CodigoNPNP.Text = "-"
        '
        'NotaPedido
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(825, 636)
        Me.Controls.Add(Me.CodigoNPNP)
        Me.Controls.Add(Me.grdNP)
        Me.Controls.Add(Me.btnSalirNP)
        Me.Controls.Add(Me.btn1NP)
        Me.Controls.Add(Me.TotalNP)
        Me.Controls.Add(Me.FechaEntregaNP)
        Me.Controls.Add(Me.SeñaNP)
        Me.Controls.Add(Me.TelNP)
        Me.Controls.Add(Me.DireccionNP)
        Me.Controls.Add(Me.NombreApellidoNP)
        Me.Controls.Add(Me.CodigoNP)
        Me.Controls.Add(Me.FechaNP)
        Me.Controls.Add(Me.pcb1NP)
        Me.Name = "NotaPedido"
        Me.Text = "NotaPedido"
        CType(Me.pcb1NP, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.grdNP, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents pcb1NP As System.Windows.Forms.PictureBox
    Friend WithEvents FechaNP As System.Windows.Forms.Label
    Friend WithEvents CodigoNP As System.Windows.Forms.Label
    Friend WithEvents NombreApellidoNP As System.Windows.Forms.Label
    Friend WithEvents DireccionNP As System.Windows.Forms.Label
    Friend WithEvents TelNP As System.Windows.Forms.Label
    Friend WithEvents SeñaNP As System.Windows.Forms.Label
    Friend WithEvents FechaEntregaNP As System.Windows.Forms.Label
    Friend WithEvents TotalNP As System.Windows.Forms.Label
    Friend WithEvents btnSalirNP As System.Windows.Forms.Button
    Friend WithEvents btn1NP As System.Windows.Forms.Button
    Friend WithEvents pf1NP As Microsoft.VisualBasic.PowerPacks.Printing.PrintForm
    Friend WithEvents grdNP As System.Windows.Forms.DataGridView
    Friend WithEvents CodigoNPNP As System.Windows.Forms.Label
End Class
