﻿Imports System.Data.Odbc

Public Class ENTREGA
    Dim b As Integer

    Private Sub ENTREGA_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If bent <> 1 Then
            bent = 1
            ds.Tables.Add("ENTREGA")
        End If

        sql = "SELECT C.nombre, C.apellido, C.DNI, NP.numNotaPedido FROM cliente C, factura F, notapedido NP WHERE C.codCliente=F.codCliente AND F.numNotaPedido=NP.numNotaPedido AND NP.finalizado=0"
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("ENTREGA"))
        Me.grdENT.DataSource = ds.Tables("ENTREGA")
        grdENT.DataSource.clear()
        sql = "SELECT C.nombre, C.apellido, C.DNI, NP.numNotaPedido FROM cliente C, factura F, notapedido NP WHERE C.codCliente=F.codCliente AND F.numNotaPedido=NP.numNotaPedido AND NP.finalizado=0"
        adp = New OdbcDataAdapter(sql, cnn)
        adp.Fill(ds.Tables("ENTREGA"))
        Me.grdENT.DataSource = ds.Tables("ENTREGA")

        sql = "SELECT curdate()"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            fechaENT.Text = rs(0)
        End If
    End Sub

    Private Sub btnVALIDARENT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVALIDARENT.Click
        btnFinENT.Enabled = False
        sql = "SELECT COUNT(*) FROM notapedido WHERE numNotaPedido='" & Trim(mskENT.Text) & "' AND finalizado=0"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) > 0 Then
                btnFinENT.Enabled = True
            Else
                MsgBox("El código ingresado no existe.", MsgBoxStyle.Exclamation, "ERROR")
            End If
        End If
    End Sub

    Private Sub btn2V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2V.Click
        mskENT.Text = ""
        btnFinENT.Enabled = False
        Me.Close()
        Principal.Show()
    End Sub

    Private Sub btnFinENT_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFinENT.Click
        b = 0
        npentrega = Trim(mskENT.Text)

        sql = "SELECT codRTC, cantidad FROM NP WHERE idNP='" & npentrega & "'"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            Try
                sql = "UPDATE ropatallescolor SET stock=stock-'" & rs(1) & "' WHERE codRTC='" & rs(0) & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                b = 1
            Catch ex As Exception
                MsgBox("No hay stock suficiente para satisfacer el pedido.", MsgBoxStyle.Exclamation, "ERROR")
                b = 0
            End Try
        Loop

        If b = 1 Then
            sql = "UPDATE notapedido SET finalizado=1 WHERE finalizado=0 AND numNotaPedido='" & Trim(mskENT.Text) & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()

            sql = "SELECT curdate()"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                RemitoCliente.lblFechaRemC.Text = rs(0)
            End If
            sql = "SELECT CONCAT(C.nombre, ' ' , C.apellido) FROM cliente C, factura F WHERE C.codCliente=F.codCliente AND F.numNotaPedido='" & Trim(mskENT.Text) & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                RemitoCliente.lblNombreRemC.Text = rs(0)
            End If

            sql = "SELECT C.direccion, C.localidad, C.telefono, C.codPostal, C.provincia, C.codCliente FROM cliente C, factura F WHERE C.codCliente=F.codCliente AND F.numNotaPedido='" & Trim(mskENT.Text) & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                RemitoCliente.lblDireccionRemC.Text = rs(0)
                RemitoCliente.lblLocalidadRemC.Text = rs(1)
                RemitoCliente.lblTelRemC.Text = rs(2)
                RemitoCliente.lblCPRemC.Text = rs(3)
                RemitoCliente.lblProvinciaRemC.Text = rs(4)
                RemitoCliente.lblCodClienteRemC.Text = rs(5)
                sql = "INSERT INTO remitocliente VALUES('', '" & RemitoCliente.lblCodClienteRemC.Text & "', 1, curdate())"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                sql = "SELECT MAX(numRemitoC) FROM remitocliente"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    RemitoCliente.lblCodigoRemC.Text = rs(0)
                End If
            End If

            Me.Close()
            RemitoCliente.Show()
        End If
    End Sub

    Private Sub mskENT_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles mskENT.TextChanged
        btnFinENT.Enabled = False
    End Sub
End Class