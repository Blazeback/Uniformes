﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MPrima1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.cmb2 = New System.Windows.Forms.ComboBox()
        Me.grd1 = New System.Windows.Forms.DataGridView()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl3 = New System.Windows.Forms.Label()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.lst1 = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        CType(Me.grd1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn4
        '
        Me.btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.btn4.Location = New System.Drawing.Point(531, 238)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(141, 42)
        Me.btn4.TabIndex = 127
        Me.btn4.Text = "Cancelar"
        Me.btn4.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Enabled = False
        Me.btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.btn3.Location = New System.Drawing.Point(531, 176)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(141, 56)
        Me.btn3.TabIndex = 126
        Me.btn3.Text = "Finalizar pedido"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.lbl1.Location = New System.Drawing.Point(161, 89)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(217, 24)
        Me.lbl1.TabIndex = 128
        Me.lbl1.Text = "Seleccione el proveedor"
        '
        'cmb1
        '
        Me.cmb1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Location = New System.Drawing.Point(12, 42)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(283, 32)
        Me.cmb1.TabIndex = 129
        '
        'cmb2
        '
        Me.cmb2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.cmb2.FormattingEnabled = True
        Me.cmb2.Location = New System.Drawing.Point(301, 42)
        Me.cmb2.Name = "cmb2"
        Me.cmb2.Size = New System.Drawing.Size(168, 32)
        Me.cmb2.TabIndex = 130
        '
        'grd1
        '
        Me.grd1.AllowUserToAddRows = False
        Me.grd1.AllowUserToDeleteRows = False
        Me.grd1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grd1.Enabled = False
        Me.grd1.Location = New System.Drawing.Point(16, 128)
        Me.grd1.Name = "grd1"
        Me.grd1.ReadOnly = True
        Me.grd1.Size = New System.Drawing.Size(505, 150)
        Me.grd1.TabIndex = 131
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(12, 15)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(190, 24)
        Me.lbl2.TabIndex = 132
        Me.lbl2.Text = "Seleccione el artículo"
        '
        'lbl3
        '
        Me.lbl3.AutoSize = True
        Me.lbl3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.lbl3.Location = New System.Drawing.Point(297, 15)
        Me.lbl3.Name = "lbl3"
        Me.lbl3.Size = New System.Drawing.Size(172, 24)
        Me.lbl3.TabIndex = 133
        Me.lbl3.Text = "Seleccione el color"
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(531, 80)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(141, 42)
        Me.btn1.TabIndex = 134
        Me.btn1.Text = "Seleccionar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Enabled = False
        Me.btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(531, 128)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(141, 42)
        Me.btn2.TabIndex = 135
        Me.btn2.Text = "Ingresar"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'lst1
        '
        Me.lst1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.lst1.FormattingEnabled = True
        Me.lst1.ItemHeight = 24
        Me.lst1.Location = New System.Drawing.Point(678, 15)
        Me.lst1.Name = "lst1"
        Me.lst1.Size = New System.Drawing.Size(495, 268)
        Me.lst1.TabIndex = 136
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(475, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(168, 24)
        Me.Label1.TabIndex = 137
        Me.Label1.Text = "Ingrese la cantidad"
        '
        'msk1
        '
        Me.msk1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(479, 45)
        Me.msk1.Mask = "000000"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(72, 29)
        Me.msk1.TabIndex = 138
        '
        'MPrima1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1189, 290)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lst1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.lbl3)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.grd1)
        Me.Controls.Add(Me.cmb2)
        Me.Controls.Add(Me.cmb1)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btn3)
        Me.Name = "MPrima1"
        Me.Text = "MAT. PRIM. 1"
        CType(Me.grd1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn4 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents cmb1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb2 As System.Windows.Forms.ComboBox
    Friend WithEvents grd1 As System.Windows.Forms.DataGridView
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl3 As System.Windows.Forms.Label
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents lst1 As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
End Class
