﻿Imports System.Data.Odbc

Public Class EliminarUser
    Dim b As Integer

    Private Sub btnCancelarUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarUser.Click
        txt1AEUser.Text = ""
        cbm1AEUser.SelectedIndex = -1
        txt2AEUser.Text = ""
        txt3AEUser.Text = ""
        Me.Hide()
        AgregElimUser.Show()
    End Sub

    Private Sub btnEliminarUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminarUser.Click
        sql = "SELECT COUNT(*) FROM usuario WHERE nombre='" & txt1AEUser.Text & "' AND sector='" & cbm1AEUser.Text & "'"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) > 0 Then
                If txt2AEUser.Text = txt3AEUser.Text Then
                    sql = "DELETE FROM usuario WHERE nombre='" & txt1AEUser.Text & "' AND sector='" & cbm1AEUser.Text & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    b = 1
                    txt1AEUser.Text = ""
                    cbm1AEUser.SelectedIndex = -1
                    txt2AEUser.Text = ""
                    txt3AEUser.Text = ""
                Else
                    MsgBox("Las contraseñas no coinciden.", MsgBoxStyle.Exclamation, "ERROR")
                    txt2AEUser.Text = ""
                    txt3AEUser.Text = ""
                End If
            Else
                MsgBox("El usuario no existe.", MsgBoxStyle.Exclamation, "ERROR")
                txt1AEUser.Text = ""
                cbm1AEUser.SelectedIndex = -1
                txt2AEUser.Text = ""
                txt3AEUser.Text = ""
            End If
        End If

        If b = 1 Then
            MsgBox("¡El usuario ha sido eliminado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
            txt1AEUser.Text = ""
            cbm1AEUser.SelectedIndex = -1
            txt2AEUser.Text = ""
            txt3AEUser.Text = ""
            Me.Hide()
            AgregElimUser.Show()
        End If
    End Sub

    Private Sub EliminarUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "SELECT DISTINCT sector FROM usuario"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            cbm1AEUser.Items.Add(rs(0))
        Loop
    End Sub
End Class