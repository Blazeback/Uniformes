﻿Imports System.Data.Odbc

Public Class OrdenConfeccion

    Private Sub btn1Confeccion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1Confeccion.Click
        Try
            pf1Confeccion.Print()
            grdCONF.DataSource.clear()
        Catch ex As Exception
            MsgBox("La impresión ha sido cancelada.", MsgBoxStyle.Exclamation, "ERROR")
            Me.Show()
        End Try
    End Sub

    Private Sub OrdenConfeccion_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If bord <> 1 Then
            bord = 1
            ds.Tables.Add("Conf")
            sql = "SELECT* FROM CONFECCION WHERE idNP='" & npglobal & "'"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("Conf"))
            Me.grdCONF.DataSource = ds.Tables("Conf")
        Else
            sql = "SELECT* FROM CONFECCION WHERE idNP='" & npglobal & "'"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("Conf"))
            Me.grdCONF.DataSource = ds.Tables("Conf")
        End If
    End Sub

    Private Sub btnSalirConfeccion_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirConfeccion.Click
        Me.Close()
        grdCONF.DataSource.clear()
        Principal.Show()
    End Sub
End Class