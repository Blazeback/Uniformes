﻿Imports System.Data.Odbc

Public Class Ventas2
    Dim b As Integer
    Dim contador As Integer
    Dim manguita As String
    Dim banderadetallecam As String
    Dim preciouncam As Integer
    Dim codrt As Integer
    Dim codrtc As Integer
    Dim bbolsillo As Integer
    Dim bcuellov As Integer
    Dim bchomba As Integer
    Dim bbolsillos As Integer
    Dim belastico As Integer
    Dim bcordon As Integer
    Dim bcierre As Integer
    Dim bbolsillosint As Integer
    Dim bcapucha As Integer
    Dim bdetalle As Integer

    Private Sub rb1V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb1V2.CheckedChanged
        If rb1V2.Checked = True Then
            grb1V2.Visible = False
            grb1V2.Visible = False
            'rb3V2.Checked = False
            'rb4V2.Checked = False
            chk5V2.Checked = False
            rb5V2.Checked = False
            rb6V2.Checked = False
            CheckBox1.Checked = False
        End If
    End Sub
    ''''''''''''''''''''''''''''''''''''''''jfjfjfjfjjfjfjjf
    Private Sub rb2V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb2V2.CheckedChanged
        If rb2V2.Checked = True Then
            grb1V2.Visible = True
        End If
    End Sub

    Private Sub btnCancelarV2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarV2.Click
        chkCamV2.Checked = False
        chkRemV2.Checked = False
        chkPanV2.Checked = False
        chkPulV2.Checked = False

        If contador > 0 Then
            sql = "DELETE FROM NP WHERE idNP='" & npglobal & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            sql = "DELETE FROM NPTOTAL WHERE idNP='" & npglobal & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            sql = "DELETE FROM NPDETALLE WHERE idNP='" & npglobal & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
        End If

        Me.Hide()
        Ventas.Show()
    End Sub

    Private Sub chk0V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkCamV2.CheckedChanged
        If chkCamV2.Checked = True Then
            grbCV2.Visible = True
        Else
            grbCV2.Visible = False
            grb1V2.Visible = False
            'rb3V2.Checked = False
            'rb4V2.Checked = False
            chk5V2.Checked = False
            CheckBox2.Checked = False
            CheckBox1.Checked = False
            rb5V2.Checked = False
            rb6V2.Checked = False
            'rb99V2.Checked = False
            'rb1010V2.Checked = False
            'chk10V2.Checked = False
            msk1V2.Enabled = False
            msk1V2.Text = ""
            msk2V2.Enabled = False
            msk2V2.Text = ""
            msk3V2.Enabled = False
            msk3V2.Text = ""
            msk4V2.Enabled = False
            msk4V2.Text = ""
            cbm1V2.SelectedIndex = -1
            rb1V2.Checked = False
            rb2V2.Checked = False
            chk1V2.Checked = False
            chk2V2.Checked = False
            chk3V2.Checked = False
            chk4V2.Checked = False
        End If
    End Sub

    Private Sub btn1V2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1V2.Click
        b = 0
        If chkCamV2.Checked = True Then
            If (rb1V2.Checked = False And rb2V2.Checked = False) Then
                b = 1
            End If

            If (chk1V2.Checked = True And msk1V2.Text = "") Then
                b = 1
            End If
            If (chk2V2.Checked = True And msk2V2.Text = "") Then
                b = 1
            End If
            If (chk3V2.Checked = True And msk3V2.Text = "") Then
                b = 1
            End If
            If (chk4V2.Checked = True And msk4V2.Text = "") Then
                b = 1
            End If

            If cbm1V2.Text = "" Then
                b = 1
            End If

            If chk1V2.Checked = False And chk2V2.Checked = False And chk3V2.Checked = False And chk4V2.Checked = False Then
                b = 1
            End If

            If grb1V2.Visible = True Then

                If (rb5V2.Checked = False And rb6V2.Checked = False) Then
                    b = 1
                End If

                'If rb3V2.Checked = False And rb4V2.Checked = False And rb5V2.Checked = False And rb6V2.Checked = False And chk5V2.Checked = False Then
                'b = 1
                'End If
            End If
        End If

        If chkRemV2.Checked = True Then
            If (rb7V2.Checked = False And rb8V2.Checked = False) Then
                b = 1
            End If

            If (chk6V2.Checked = True And msk5V2.Text = "") Then
                b = 1
            End If
            If (chk7V2.Checked = True And msk6V2.Text = "") Then
                b = 1
            End If
            If (chk8V2.Checked = True And msk7V2.Text = "") Then
                b = 1
            End If
            If (chk9V2.Checked = True And msk8V2.Text = "") Then
                b = 1
            End If

            If cbm2V2.Text = "" Then
                b = 1
            End If

            If chk6V2.Checked = False And chk7V2.Checked = False And chk8V2.Checked = False And chk9V2.Checked = False Then
                b = 1
            End If

            If grb2V2.Visible = True Then

                If (rb11V2.Checked = False And rb12V2.Checked = False) Then
                    b = 1
                End If

                'If rb99V2.Checked = False And rb1010V2.Checked = False And chk10V2.Checked = False And chk11V2.Checked = False Then
                'b = 1
                'End If
            End If
        End If

        If chkPanV2.Checked = True Then
            If (rb13V2.Checked = False And rb14V2.Checked = False) Then
                b = 1
            End If

            If chk12V2.Checked = True And msk9V2.Text = "" Then
                b = 1
            End If

            If chk13V2.Checked = True And msk10V2.Text = "" Then
                b = 1
            End If

            If chk14V2.Checked = True And msk11V2.Text = "" Then
                b = 1
            End If

            If chk15V2.Checked = True And msk12V2.Text = "" Then
                b = 1
            End If

            If cbm3V2.Text = "" Then
                b = 1
            End If

            If rb14V2.Checked = True Then
                If (rb15V2.Checked = False And rb16V2.Checked = False) Then
                    b = 1
                End If
            End If
        End If

        If chkPulV2.Checked = True Then
            If (rb17V2.Checked = False And rb18V2.Checked = False) Then
                b = 1
            End If

            If chk18V2.Checked = True And msk13V2.Text = "" Then
                b = 1
            End If

            If chk19V2.Checked = True And msk14V2.Text = "" Then
                b = 1
            End If

            If chk20V2.Checked = True And msk15V2.Text = "" Then
                b = 1
            End If

            If chk21V2.Checked = True And msk16V2.Text = "" Then
                b = 1
            End If

            If cbm4V2.Text = "" Then
                b = 1
            End If

            If rb14V2.Checked = True Then
                If (rb19V2.Checked = False And rb20V2.Checked = False) Then
                    b = 1
                End If
            End If
        End If

        contador = 0

        If b = 0 Then
            banderabordado = 0

            If rb5V2.Checked = True Or rb11V2.Checked = True Or rb15V2.Checked = True Or rb19V2.Checked = True Then
                banderabordado = 1
            End If
            sql = "SELECT MAX(numNotaPedido+1) FROM notapedido"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                npglobal = rs(0)
            End If

            preciototal = 0

            banderadetallecam = "sin"
            preciocam = 0
            preciouncam = 0
            cantidadcam = 0
            tiempocam = TimeOfDay
            tiempocam = "00:00:00"
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            If chkCamV2.Checked = True Then
                bdetalle = 0
                contador = 1
                If chk1V2.Checked = True Then
                    If CheckBox2.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox1.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk1V2.Text)
                    cantidadcam = CInt(msk1V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb5V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0

                    
                    banderadetallecam = "sin"
                End If

                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb5V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk2V2.Checked = True Then
                    If CheckBox2.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox1.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If

                    preciocam = preciocam * CInt(msk2V2.Text)
                    cantidadcam = CInt(msk2V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else
                        If rb5V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb5V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk3V2.Checked = True Then
                    If CheckBox2.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox1.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If

                    preciocam = preciocam * CInt(msk3V2.Text)
                    cantidadcam = CInt(msk3V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else
                        If rb5V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb5V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk4V2.Checked = True Then
                    If CheckBox2.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm1V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk5V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillo = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox1.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Camisa manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If

                    preciocam = preciocam * CInt(msk4V2.Text)
                    cantidadcam = CInt(msk4V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else
                        If rb5V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Camisa manga " & manguita & " " & cbm1V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillo = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb5V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0
            bdetalle = 0

            If chkRemV2.Checked = True Then
                contador = 1
                If chk6V2.Checked = True Then
                    If CheckBox4.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk11V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Chomba'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bchomba = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk5V2.Text)
                    cantidadcam = CInt(msk5V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bchomba = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 10)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk7V2.Checked = True Then
                    If CheckBox4.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk11V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Chomba'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bchomba = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk6V2.Text)
                    cantidadcam = CInt(msk6V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bchomba = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 10)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk8V2.Checked = True Then
                    If CheckBox4.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk11V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Chomba'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bchomba = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk7V2.Text)
                    cantidadcam = CInt(msk7V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bchomba = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 10)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk9V2.Checked = True Then
                    If CheckBox4.Checked = True Then
                        manguita = "larga"
                    Else
                        manguita = "corta"
                    End If
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm2V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk11V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Chomba'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bchomba = 1
                            bdetalle = 1
                        End If
                    End If

                    If CheckBox3.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Remera manga " & manguita & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk8V2.Text)
                    cantidadcam = CInt(msk8V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Remera manga " & manguita & " " & cbm2V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bchomba = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 10)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            bdetalle = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            '________________________________________________________________________________________________________________

            If chkPanV2.Checked = True Then
                contador = 1
                If chk12V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk16V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillos = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk17V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk9V2.Text)
                    cantidadcam = CInt(msk9V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb15V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillos = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk13V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk16V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillos = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk17V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk10V2.Text)
                    cantidadcam = CInt(msk10V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb15V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillos = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk14V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk16V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillos = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk17V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk11V2.Text)
                    cantidadcam = CInt(msk11V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb15V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillos = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
                If chk15V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm3V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk16V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Bolsillo'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bbolsillos = 1
                            bdetalle = 1
                        End If
                    End If

                    If chk17V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Elastico ajustable'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            belastico = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Pantalon'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk12V2.Text)
                    cantidadcam = CInt(msk12V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb15V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pantalon " & cbm3V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bbolsillos = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 1)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If belastico = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 4)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb11V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
            End If

            '______________________________________________________________________________________________________________________
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0
            bdetalle = 0

            If chkPulV2.Checked = True Then
                contador = 1
                If chk18V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk22V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='S' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk13V2.Text)
                    cantidadcam = CInt(msk13V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle S " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb19V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk19V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk22V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='M' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk14V2.Text)
                    cantidadcam = CInt(msk14V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle M " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb19V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk20V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk22V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='L' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk15V2.Text)
                    cantidadcam = CInt(msk15V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle L " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb19V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

                If chk21V2.Checked = True Then
                    sql = "Select codRT, precio, tiempo from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciocam = preciocam + rs(1)
                        tiempocam = tiempocam + rs(2)
                        codrt = rs(0)
                        sql = "SELECT codRTC FROM ropatallescolor R, colores C WHERE R.idColor=C.idColor AND R.codRT='" & codrt & "' AND C.nombre='" & cbm4V2.Text & "'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            codrtc = rs(0)
                        End If
                    End If

                    If chk22V2.Checked = True Then
                        sql = "SELECT nombre, precio, tiempo FROM detalle WHERE nombre='Cuello en V'"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                        If rs.Read = True Then
                            preciocam = preciocam + rs(1)
                            banderadetallecam = "con"
                            preciouncam = preciouncam + rs(1)
                            tiempocam = tiempocam + rs(2)
                            bcuellov = 1
                            bdetalle = 1
                        End If
                    End If
                    sql = "Select precio from ropaTalles RT, ropa R, talles T Where(RT.codRopa = R.codRopa And RT.codTalle = T.codTalle) and talle='XL' and R.nombre='Pulover'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    If rs.Read = True Then
                        preciouncam = preciouncam + rs(0)
                    End If
                    preciocam = preciocam * CInt(msk16V2.Text)
                    cantidadcam = CInt(msk16V2.Text)
                    preciototal = preciototal + preciocam

                    If banderadetallecam = "sin" Then
                        sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', false, 0)"
                        comando = New OdbcCommand(sql, cnn)
                        comando.CommandType = CommandType.Text
                        rs = comando.ExecuteReader
                        comando.Dispose()
                    Else

                        If rb11V2.Checked = True Then
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 1)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        Else
                            sql = "INSERT INTO NP VALUES('', '" & npglobal & "', '" & codrt & "', '" & codrtc & "', '" & cantidadcam & "', 'Pulover " & cbm4V2.Text & " talle XL " & banderadetallecam & " detalle', '" & preciouncam & "', '" & preciocam & "', true, 0)"
                            comando = New OdbcCommand(sql, cnn)
                            comando.CommandType = CommandType.Text
                            rs = comando.ExecuteReader
                            comando.Dispose()
                        End If
                    End If

                    preciocam = 0
                    cantidadcam = 0
                    preciouncam = 0


                    banderadetallecam = "sin"
                End If
                If bcuellov = 1 Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 3)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                If rb19V2.Checked = True Then
                    sql = "INSERT INTO NPDETALLE VALUES('', '" & npglobal & "', '" & codrtc & "', 2)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                End If
                '.............................................................................................
            End If

            bdetalle = 0
            bbolsillo = 0
            bcuellov = 0
            bchomba = 0
            bbolsillos = 0
            belastico = 0
            bcordon = 0
            bcierre = 0
            bbolsillosint = 0
            bcapucha = 0

            Me.Hide()
            Ventas3.Show()
        Else
            MsgBox("Usted ha dejado campos sin completar.", MsgBoxStyle.Exclamation, "ERROR")
        End If
    End Sub

    Private Sub chkRemV2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkRemV2.CheckedChanged
        If chkRemV2.Checked = True Then
            grbRemV2.Visible = True
        Else
            grbRemV2.Visible = False
            grb2V2.Visible = False
            'rb3V2.Checked = False
            'rb4V2.Checked = False
            CheckBox4.Checked = False
            CheckBox3.Checked = False
            'rb99V2.Checked = False
            'rb1010V2.Checked = False
            'chk10V2.Checked = False
            chk11V2.Checked = False
            rb11V2.Checked = False
            rb12V2.Checked = False
            msk5V2.Enabled = False
            msk5V2.Text = ""
            msk6V2.Enabled = False
            msk6V2.Text = ""
            msk7V2.Enabled = False
            msk7V2.Text = ""
            msk8V2.Enabled = False
            msk8V2.Text = ""
            cbm2V2.SelectedIndex = -1
            rb7V2.Checked = False
            rb8V2.Checked = False
            chk6V2.Checked = False
            chk7V2.Checked = False
            chk8V2.Checked = False
            chk9V2.Checked = False
        End If
    End Sub

    Private Sub chkPanV2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkPanV2.CheckedChanged
        If chkPanV2.Checked = True Then
            grbPantV2.Visible = True
        Else
            grbPantV2.Visible = False
            grb3V2.Visible = False
            'rb3V2.Checked = False
            'rb4V2.Checked = False
            rb15V2.Checked = False
            rb16V2.Checked = False
            chk22V2.Checked = False
            'rb99V2.Checked = False
            'rb1010V2.Checked = False
            'chk10V2.Checked = False
            chk11V2.Checked = False
            msk9V2.Enabled = False
            msk9V2.Text = ""
            msk10V2.Enabled = False
            msk10V2.Text = ""
            msk11V2.Enabled = False
            msk11V2.Text = ""
            msk12V2.Enabled = False
            msk12V2.Text = ""
            cbm3V2.SelectedIndex = -1
            rb13V2.Checked = False
            rb14V2.Checked = False
            rb18V2.Checked = False
            chk12V2.Checked = False
            chk13V2.Checked = False
            chk14V2.Checked = False
            chk15V2.Checked = False
            chk16V2.Checked = False
            chk17V2.Checked = False
        End If
    End Sub

    Private Sub rb13V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb13V2.CheckedChanged
        If rb13V2.Checked = True Then
            grb3V2.Visible = False
            chk16V2.Checked = False
            chk17V2.Checked = False
            rb15V2.Checked = False
            rb16V2.Checked = False
        End If
    End Sub

    Private Sub rb14V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb14V2.CheckedChanged
        If rb14V2.Checked = True Then
            grb3V2.Visible = True
        End If
    End Sub

    Private Sub chkPulV2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkPulV2.CheckedChanged
        If chkPulV2.Checked = True Then
            grbPulV2.Visible = True
        Else
            grbPulV2.Visible = False
            grb4V2.Visible = False
            'rb3V2.Checked = False
            'rb4V2.Checked = False
            rb17V2.Checked = False
            rb18V2.Checked = False
            rb19V2.Checked = False
            rb20V2.Checked = False
            chk18V2.Checked = False
            chk19V2.Checked = False
            chk20V2.Checked = False
            chk21V2.Checked = False
            chk22V2.Checked = False
            'rb99V2.Checked = False
            'rb1010V2.Checked = False
            'chk10V2.Checked = False
            msk1V2.Enabled = False
            msk13V2.Enabled = False
            msk13V2.Text = ""
            msk14V2.Enabled = False
            msk14V2.Text = ""
            msk15V2.Enabled = False
            msk15V2.Text = ""
            msk16V2.Enabled = False
            msk16V2.Text = ""
            cbm4V2.SelectedIndex = -1
        End If
    End Sub

    Private Sub rb17V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb17V2.CheckedChanged
        If rb17V2.Checked = True Then
            grb4V2.Visible = False
            chk22V2.Checked = False
            rb19V2.Checked = False
            rb20V2.Checked = False
        End If
    End Sub

    Private Sub rb18V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb18V2.CheckedChanged
        If rb18V2.Checked = True Then
            grb4V2.Visible = True
        End If
    End Sub

    Private Sub rb7V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb7V2.CheckedChanged
        If rb7V2.Checked = True Then
            grb2V2.Visible = False
            grb2V2.Visible = False
            'rb99V2.Checked = False
            'rb1010V2.Checked = False
            'chk10V2.Checked = False
            chk11V2.Checked = False
            rb11V2.Checked = False
            rb12V2.Checked = False
            CheckBox3.Checked = False
        End If
    End Sub

    Private Sub rb8V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rb8V2.CheckedChanged
        If rb8V2.Checked = True Then
            grb2V2.Visible = True
        End If
    End Sub

    Private Sub chk1V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk1V2.CheckedChanged
        If chk1V2.Checked = True Then
            msk1V2.Enabled = True
        Else
            msk1V2.Enabled = False
            msk1V2.Text = ""
        End If
    End Sub

    Private Sub chk2V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk2V2.CheckedChanged
        If chk2V2.Checked = True Then
            msk2V2.Enabled = True
        Else
            msk2V2.Enabled = False
            msk2V2.Text = ""
        End If
    End Sub

    Private Sub chk3V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk3V2.CheckedChanged
        If chk3V2.Checked = True Then
            msk3V2.Enabled = True
        Else
            msk3V2.Enabled = False
            msk3V2.Text = ""
        End If
    End Sub

    Private Sub chk4V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk4V2.CheckedChanged
        If chk4V2.Checked = True Then
            msk4V2.Enabled = True
        Else
            msk4V2.Enabled = False
            msk4V2.Text = ""
        End If
    End Sub

    Private Sub chk6V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk6V2.CheckedChanged
        If chk6V2.Checked = True Then
            msk5V2.Enabled = True
        Else
            msk5V2.Enabled = False
            msk5V2.Text = ""
        End If
    End Sub

    Private Sub chk7V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk7V2.CheckedChanged
        If chk7V2.Checked = True Then
            msk6V2.Enabled = True
        Else
            msk6V2.Enabled = False
            msk6V2.Text = ""
        End If
    End Sub

    Private Sub chk8V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk8V2.CheckedChanged
        If chk8V2.Checked = True Then
            msk7V2.Enabled = True
        Else
            msk7V2.Enabled = False
            msk7V2.Text = ""
        End If
    End Sub

    Private Sub chk9V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk9V2.CheckedChanged
        If chk9V2.Checked = True Then
            msk8V2.Enabled = True
        Else
            msk8V2.Enabled = False
            msk8V2.Text = ""
        End If
    End Sub

    Private Sub chk12V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk12V2.CheckedChanged
        If chk12V2.Checked = True Then
            msk9V2.Enabled = True
        Else
            msk9V2.Enabled = False
            msk9V2.Text = ""
        End If
    End Sub

    Private Sub chk13V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk13V2.CheckedChanged
        If chk13V2.Checked = True Then
            msk10V2.Enabled = True
        Else
            msk10V2.Enabled = False
            msk10V2.Text = ""
        End If
    End Sub

    Private Sub chk14V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk14V2.CheckedChanged
        If chk14V2.Checked = True Then
            msk11V2.Enabled = True
        Else
            msk11V2.Enabled = False
            msk11V2.Text = ""
        End If
    End Sub

    Private Sub chk15V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk15V2.CheckedChanged
        If chk15V2.Checked = True Then
            msk12V2.Enabled = True
        Else
            msk12V2.Enabled = False
            msk12V2.Text = ""
        End If
    End Sub

    Private Sub chk18V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk18V2.CheckedChanged
        If chk18V2.Checked = True Then
            msk13V2.Enabled = True
        Else
            msk13V2.Enabled = False
            msk13V2.Text = ""
        End If
    End Sub

    Private Sub chk19V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk19V2.CheckedChanged
        If chk19V2.Checked = True Then
            msk14V2.Enabled = True
        Else
            msk14V2.Enabled = False
            msk14V2.Text = ""
        End If
    End Sub

    Private Sub chk20V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk20V2.CheckedChanged
        If chk20V2.Checked = True Then
            msk15V2.Enabled = True
        Else
            msk15V2.Enabled = False
            msk15V2.Text = ""
        End If
    End Sub

    Private Sub chk21V2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chk21V2.CheckedChanged
        If chk21V2.Checked = True Then
            msk16V2.Enabled = True
        Else
            msk16V2.Enabled = False
            msk16V2.Text = ""
        End If
    End Sub

    Private Sub msk1V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk1V2.MaskInputRejected
        msk1V2.BeepOnError = True
    End Sub

    Private Sub msk2V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk2V2.MaskInputRejected
        msk2V2.BeepOnError = True
    End Sub

    Private Sub msk3V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk3V2.MaskInputRejected
        msk3V2.BeepOnError = True
    End Sub

    Private Sub msk4V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk4V2.MaskInputRejected
        msk4V2.BeepOnError = True
    End Sub

    Private Sub msk5V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk5V2.MaskInputRejected
        msk5V2.BeepOnError = True
    End Sub

    Private Sub msk6V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk6V2.MaskInputRejected
        msk6V2.BeepOnError = True
    End Sub

    Private Sub msk7V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk7V2.MaskInputRejected
        msk7V2.BeepOnError = True
    End Sub

    Private Sub msk8V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk8V2.MaskInputRejected
        msk8V2.BeepOnError = True
    End Sub

    Private Sub msk9V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk9V2.MaskInputRejected
        msk9V2.BeepOnError = True
    End Sub

    Private Sub msk10V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk10V2.MaskInputRejected
        msk10V2.BeepOnError = True
    End Sub

    Private Sub msk11V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk11V2.MaskInputRejected
        msk11V2.BeepOnError = True
    End Sub

    Private Sub msk12V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk12V2.MaskInputRejected
        msk12V2.BeepOnError = True
    End Sub

    Private Sub msk13V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk13V2.MaskInputRejected
        msk13V2.BeepOnError = True
    End Sub

    Private Sub msk14V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk14V2.MaskInputRejected
        msk14V2.BeepOnError = True
    End Sub

    Private Sub msk15V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk15V2.MaskInputRejected
        msk15V2.BeepOnError = True
    End Sub

    Private Sub msk16V2_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk16V2.MaskInputRejected
        msk16V2.BeepOnError = True
    End Sub

    Private Sub Ventas2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "SELECT nombre FROM colores"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            cbm1V2.Items.Add(rs(0))
            cbm2V2.Items.Add(rs(0))
            cbm3V2.Items.Add(rs(0))
            cbm4V2.Items.Add(rs(0))
        Loop
    End Sub
End Class