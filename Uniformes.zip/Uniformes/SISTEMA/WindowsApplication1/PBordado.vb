﻿Imports System.Data.Odbc
Public Class PBordado

    Private Sub PBordado_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call conexion()
        sql = "Select max(codProveedor) from proveedor"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
    End Sub

    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        If msk1.Text = "" Or msk2.Text = "" Or msk3.Text = "" Then
            MsgBox("Usted a dejado campos sin completar", MsgBoxStyle.Exclamation, "ERROR")
        Else
            sql = "Insert Into proveedorBordado Values ('', " & rs(0) & ", " & Trim(msk3.Text) & ", '" & Trim(msk1.Text) & ":" & Trim(msk2.Text) & ":00', false)"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            MsgBox("¡El proveedor a sido ingresado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
            msk1.Clear()
            msk2.Clear()
            msk3.Clear()
            Me.Hide()
            AEProveedores.Show()
        End If
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        sql = "Delete From proveedor Where codProveedor=" & rs(0)
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        msk1.Clear()
        msk2.Clear()
        msk3.Clear()
        Me.Hide()
        AEProveedores.Show()
    End Sub
End Class