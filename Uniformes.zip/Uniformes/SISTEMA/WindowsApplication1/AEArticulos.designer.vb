﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AEArticulos
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(319, 36)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(105, 29)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "Continuar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1.Location = New System.Drawing.Point(12, 9)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(461, 23)
        Me.lbl1.TabIndex = 1
        Me.lbl1.Text = "Ingrese el nombre del articulo que desee agregar/eliminar"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(12, 68)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(312, 23)
        Me.lbl2.TabIndex = 2
        Me.lbl2.Text = "Ingrese el punto de pedido del articulo"
        Me.lbl2.Visible = False
        '
        'msk1
        '
        Me.msk1.Enabled = False
        Me.msk1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(16, 95)
        Me.msk1.Mask = "0000"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(56, 31)
        Me.msk1.TabIndex = 3
        Me.msk1.Visible = False
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(430, 36)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(75, 29)
        Me.btn2.TabIndex = 5
        Me.btn2.Text = "Volver"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'txt1
        '
        Me.txt1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt1.Location = New System.Drawing.Point(16, 36)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(297, 31)
        Me.txt1.TabIndex = 6
        '
        'btn3
        '
        Me.btn3.Enabled = False
        Me.btn3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn3.Location = New System.Drawing.Point(78, 95)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(105, 29)
        Me.btn3.TabIndex = 7
        Me.btn3.Text = "Finalizar"
        Me.btn3.UseVisualStyleBackColor = True
        Me.btn3.Visible = False
        '
        'AEArticulos
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(517, 135)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.btn1)
        Me.Name = "AEArticulos"
        Me.Text = "ARTÍCULO"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents txt1 As System.Windows.Forms.TextBox
    Friend WithEvents btn3 As System.Windows.Forms.Button
End Class
