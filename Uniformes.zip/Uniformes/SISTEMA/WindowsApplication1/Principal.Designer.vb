﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Principal
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl1P = New System.Windows.Forms.Label()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.re = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.btnVolverP = New System.Windows.Forms.Button()
        Me.btn1P = New System.Windows.Forms.Button()
        Me.btn3P = New System.Windows.Forms.Button()
        Me.btn4P = New System.Windows.Forms.Button()
        Me.btn2P = New System.Windows.Forms.Button()
        Me.btnControlP = New System.Windows.Forms.Button()
        Me.lbl2P = New System.Windows.Forms.Label()
        Me.lst1P = New System.Windows.Forms.ListBox()
        Me.btnSalirP = New System.Windows.Forms.Button()
        Me.lst2P = New System.Windows.Forms.ListBox()
        Me.btnEntregaP = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl1P
        '
        Me.lbl1P.AutoSize = True
        Me.lbl1P.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1P.Location = New System.Drawing.Point(77, 9)
        Me.lbl1P.Name = "lbl1P"
        Me.lbl1P.Size = New System.Drawing.Size(667, 29)
        Me.lbl1P.TabIndex = 0
        Me.lbl1P.Text = "BIENVENIDO AL AGENTE DE ACTUALIZACIÓN DE BASE DE DATOS"
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1, Me.re})
        Me.ShapeContainer1.Size = New System.Drawing.Size(826, 668)
        Me.ShapeContainer1.TabIndex = 1
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 3
        Me.RectangleShape1.Location = New System.Drawing.Point(8, 613)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(178, 44)
        '
        're
        '
        Me.re.BorderWidth = 3
        Me.re.Location = New System.Drawing.Point(7, 45)
        Me.re.Name = "re"
        Me.re.Size = New System.Drawing.Size(809, 612)
        '
        'btnVolverP
        '
        Me.btnVolverP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVolverP.Location = New System.Drawing.Point(100, 619)
        Me.btnVolverP.Name = "btnVolverP"
        Me.btnVolverP.Size = New System.Drawing.Size(82, 37)
        Me.btnVolverP.TabIndex = 2
        Me.btnVolverP.Text = "Volver"
        Me.btnVolverP.UseVisualStyleBackColor = True
        '
        'btn1P
        '
        Me.btn1P.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn1P.Location = New System.Drawing.Point(35, 72)
        Me.btn1P.Name = "btn1P"
        Me.btn1P.Size = New System.Drawing.Size(189, 98)
        Me.btn1P.TabIndex = 3
        Me.btn1P.Text = "Realizar venta"
        Me.btn1P.UseVisualStyleBackColor = True
        '
        'btn3P
        '
        Me.btn3P.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn3P.Location = New System.Drawing.Point(35, 326)
        Me.btn3P.Name = "btn3P"
        Me.btn3P.Size = New System.Drawing.Size(189, 98)
        Me.btn3P.TabIndex = 4
        Me.btn3P.Text = "Encargar bordado"
        Me.btn3P.UseVisualStyleBackColor = True
        '
        'btn4P
        '
        Me.btn4P.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn4P.Location = New System.Drawing.Point(35, 441)
        Me.btn4P.Name = "btn4P"
        Me.btn4P.Size = New System.Drawing.Size(189, 98)
        Me.btn4P.TabIndex = 5
        Me.btn4P.Text = "Cierre de caja"
        Me.btn4P.UseVisualStyleBackColor = True
        '
        'btn2P
        '
        Me.btn2P.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn2P.Location = New System.Drawing.Point(35, 200)
        Me.btn2P.Name = "btn2P"
        Me.btn2P.Size = New System.Drawing.Size(189, 98)
        Me.btn2P.TabIndex = 6
        Me.btn2P.Text = "Encargar materia prima"
        Me.btn2P.UseVisualStyleBackColor = True
        '
        'btnControlP
        '
        Me.btnControlP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnControlP.Location = New System.Drawing.Point(74, 556)
        Me.btnControlP.Name = "btnControlP"
        Me.btnControlP.Size = New System.Drawing.Size(108, 39)
        Me.btnControlP.TabIndex = 7
        Me.btnControlP.Text = "Control"
        Me.btnControlP.UseVisualStyleBackColor = True
        '
        'lbl2P
        '
        Me.lbl2P.AutoSize = True
        Me.lbl2P.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2P.Location = New System.Drawing.Point(466, 60)
        Me.lbl2P.Name = "lbl2P"
        Me.lbl2P.Size = New System.Drawing.Size(141, 29)
        Me.lbl2P.TabIndex = 8
        Me.lbl2P.Text = "Advertencias:"
        '
        'lst1P
        '
        Me.lst1P.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst1P.FormattingEnabled = True
        Me.lst1P.ItemHeight = 23
        Me.lst1P.Location = New System.Drawing.Point(259, 92)
        Me.lst1P.Name = "lst1P"
        Me.lst1P.Size = New System.Drawing.Size(544, 510)
        Me.lst1P.TabIndex = 9
        '
        'btnSalirP
        '
        Me.btnSalirP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSalirP.Location = New System.Drawing.Point(12, 619)
        Me.btnSalirP.Name = "btnSalirP"
        Me.btnSalirP.Size = New System.Drawing.Size(82, 37)
        Me.btnSalirP.TabIndex = 10
        Me.btnSalirP.Text = "SALIR"
        Me.btnSalirP.UseVisualStyleBackColor = True
        '
        'lst2P
        '
        Me.lst2P.Font = New System.Drawing.Font("ISOCPEUR", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lst2P.FormattingEnabled = True
        Me.lst2P.ItemHeight = 14
        Me.lst2P.Location = New System.Drawing.Point(0, 0)
        Me.lst2P.Name = "lst2P"
        Me.lst2P.Size = New System.Drawing.Size(71, 18)
        Me.lst2P.TabIndex = 11
        '
        'btnEntregaP
        '
        Me.btnEntregaP.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEntregaP.Location = New System.Drawing.Point(374, 608)
        Me.btnEntregaP.Name = "btnEntregaP"
        Me.btnEntregaP.Size = New System.Drawing.Size(341, 39)
        Me.btnEntregaP.TabIndex = 12
        Me.btnEntregaP.Text = "REALIZAR ENTREGA AL CLIENTE"
        Me.btnEntregaP.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("ISOCPEUR", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(730, 67)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(73, 23)
        Me.Button1.TabIndex = 13
        Me.Button1.Text = "Actualizar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(826, 668)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.btnEntregaP)
        Me.Controls.Add(Me.lst2P)
        Me.Controls.Add(Me.btnSalirP)
        Me.Controls.Add(Me.lst1P)
        Me.Controls.Add(Me.lbl2P)
        Me.Controls.Add(Me.btnControlP)
        Me.Controls.Add(Me.btn2P)
        Me.Controls.Add(Me.btn4P)
        Me.Controls.Add(Me.btn3P)
        Me.Controls.Add(Me.btn1P)
        Me.Controls.Add(Me.btnVolverP)
        Me.Controls.Add(Me.lbl1P)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Principal"
        Me.Text = "MENÚ PRINCIPAL"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl1P As System.Windows.Forms.Label
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents re As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents btnVolverP As System.Windows.Forms.Button
    Friend WithEvents btn1P As System.Windows.Forms.Button
    Friend WithEvents btn3P As System.Windows.Forms.Button
    Friend WithEvents btn4P As System.Windows.Forms.Button
    Friend WithEvents btn2P As System.Windows.Forms.Button
    Friend WithEvents btnControlP As System.Windows.Forms.Button
    Friend WithEvents lbl2P As System.Windows.Forms.Label
    Friend WithEvents lst1P As System.Windows.Forms.ListBox
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents btnSalirP As System.Windows.Forms.Button
    Friend WithEvents lst2P As System.Windows.Forms.ListBox
    Friend WithEvents btnEntregaP As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button

End Class
