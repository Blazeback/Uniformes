﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Precios
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.msk2 = New System.Windows.Forms.MaskedTextBox()
        Me.msk1 = New System.Windows.Forms.MaskedTextBox()
        Me.lbl7 = New System.Windows.Forms.Label()
        Me.lbl5 = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.lbl4 = New System.Windows.Forms.Label()
        Me.lbl6 = New System.Windows.Forms.Label()
        Me.lbl8 = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.cmb4 = New System.Windows.Forms.ComboBox()
        Me.cmb5 = New System.Windows.Forms.ComboBox()
        Me.cmb1 = New System.Windows.Forms.ComboBox()
        Me.cmb3 = New System.Windows.Forms.ComboBox()
        Me.SuspendLayout()
        '
        'msk2
        '
        Me.msk2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2.Location = New System.Drawing.Point(396, 156)
        Me.msk2.Mask = "0000"
        Me.msk2.Name = "msk2"
        Me.msk2.Size = New System.Drawing.Size(100, 31)
        Me.msk2.TabIndex = 35
        '
        'msk1
        '
        Me.msk1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1.Location = New System.Drawing.Point(269, 69)
        Me.msk1.Mask = "0000"
        Me.msk1.Name = "msk1"
        Me.msk1.Size = New System.Drawing.Size(100, 31)
        Me.msk1.TabIndex = 34
        '
        'lbl7
        '
        Me.lbl7.AutoSize = True
        Me.lbl7.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl7.Location = New System.Drawing.Point(138, 126)
        Me.lbl7.Name = "lbl7"
        Me.lbl7.Size = New System.Drawing.Size(88, 23)
        Me.lbl7.TabIndex = 33
        Me.lbl7.Text = "Proveedor"
        '
        'lbl5
        '
        Me.lbl5.AutoSize = True
        Me.lbl5.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5.Location = New System.Drawing.Point(265, 42)
        Me.lbl5.Name = "lbl5"
        Me.lbl5.Size = New System.Drawing.Size(56, 23)
        Me.lbl5.TabIndex = 32
        Me.lbl5.Text = "Precio"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2.Location = New System.Drawing.Point(11, 43)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(63, 23)
        Me.lbl2.TabIndex = 31
        Me.lbl2.Text = "Prenda"
        '
        'lbl4
        '
        Me.lbl4.AutoSize = True
        Me.lbl4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4.Location = New System.Drawing.Point(138, 43)
        Me.lbl4.Name = "lbl4"
        Me.lbl4.Size = New System.Drawing.Size(48, 23)
        Me.lbl4.TabIndex = 29
        Me.lbl4.Text = "Talle"
        '
        'lbl6
        '
        Me.lbl6.AutoSize = True
        Me.lbl6.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl6.Location = New System.Drawing.Point(11, 126)
        Me.lbl6.Name = "lbl6"
        Me.lbl6.Size = New System.Drawing.Size(71, 23)
        Me.lbl6.TabIndex = 28
        Me.lbl6.Text = "Artículo"
        '
        'lbl8
        '
        Me.lbl8.AutoSize = True
        Me.lbl8.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl8.Location = New System.Drawing.Point(392, 129)
        Me.lbl8.Name = "lbl8"
        Me.lbl8.Size = New System.Drawing.Size(56, 23)
        Me.lbl8.TabIndex = 27
        Me.lbl8.Text = "Precio"
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1.Location = New System.Drawing.Point(11, 12)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(405, 23)
        Me.lbl1.TabIndex = 26
        Me.lbl1.Text = "Seleccione según lo que tenga que actualizar"
        '
        'btn1
        '
        Me.btn1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1.Location = New System.Drawing.Point(375, 68)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(104, 32)
        Me.btn1.TabIndex = 25
        Me.btn1.Text = "Actualizar"
        Me.btn1.UseVisualStyleBackColor = True
        '
        'btn2
        '
        Me.btn2.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2.Location = New System.Drawing.Point(502, 154)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(104, 31)
        Me.btn2.TabIndex = 24
        Me.btn2.Text = "Actualizar"
        Me.btn2.UseVisualStyleBackColor = True
        '
        'btn3
        '
        Me.btn3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn3.Location = New System.Drawing.Point(531, 70)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(75, 33)
        Me.btn3.TabIndex = 23
        Me.btn3.Text = "Volver"
        Me.btn3.UseVisualStyleBackColor = True
        '
        'cmb4
        '
        Me.cmb4.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb4.FormattingEnabled = True
        Me.cmb4.Location = New System.Drawing.Point(15, 153)
        Me.cmb4.Name = "cmb4"
        Me.cmb4.Size = New System.Drawing.Size(121, 31)
        Me.cmb4.TabIndex = 22
        '
        'cmb5
        '
        Me.cmb5.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb5.FormattingEnabled = True
        Me.cmb5.Location = New System.Drawing.Point(142, 153)
        Me.cmb5.Name = "cmb5"
        Me.cmb5.Size = New System.Drawing.Size(248, 31)
        Me.cmb5.TabIndex = 21
        '
        'cmb1
        '
        Me.cmb1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb1.FormattingEnabled = True
        Me.cmb1.Location = New System.Drawing.Point(15, 70)
        Me.cmb1.Name = "cmb1"
        Me.cmb1.Size = New System.Drawing.Size(121, 31)
        Me.cmb1.TabIndex = 20
        '
        'cmb3
        '
        Me.cmb3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cmb3.FormattingEnabled = True
        Me.cmb3.Location = New System.Drawing.Point(142, 69)
        Me.cmb3.Name = "cmb3"
        Me.cmb3.Size = New System.Drawing.Size(121, 31)
        Me.cmb3.TabIndex = 18
        '
        'Precios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(626, 235)
        Me.Controls.Add(Me.msk2)
        Me.Controls.Add(Me.msk1)
        Me.Controls.Add(Me.lbl7)
        Me.Controls.Add(Me.lbl5)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lbl4)
        Me.Controls.Add(Me.lbl6)
        Me.Controls.Add(Me.lbl8)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.btn1)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.cmb4)
        Me.Controls.Add(Me.cmb5)
        Me.Controls.Add(Me.cmb1)
        Me.Controls.Add(Me.cmb3)
        Me.Name = "Precios"
        Me.Text = "PRECIOS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents msk2 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lbl7 As System.Windows.Forms.Label
    Friend WithEvents lbl5 As System.Windows.Forms.Label
    Friend WithEvents lbl2 As System.Windows.Forms.Label
    Friend WithEvents lbl4 As System.Windows.Forms.Label
    Friend WithEvents lbl6 As System.Windows.Forms.Label
    Friend WithEvents lbl8 As System.Windows.Forms.Label
    Friend WithEvents lbl1 As System.Windows.Forms.Label
    Friend WithEvents btn1 As System.Windows.Forms.Button
    Friend WithEvents btn2 As System.Windows.Forms.Button
    Friend WithEvents btn3 As System.Windows.Forms.Button
    Friend WithEvents cmb4 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb5 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb1 As System.Windows.Forms.ComboBox
    Friend WithEvents cmb3 As System.Windows.Forms.ComboBox
End Class
