﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ventas
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn1V = New System.Windows.Forms.Button()
        Me.btn2V = New System.Windows.Forms.Button()
        Me.lbl1V = New System.Windows.Forms.Label()
        Me.lbl2V = New System.Windows.Forms.Label()
        Me.lbl3V = New System.Windows.Forms.Label()
        Me.lbl4V = New System.Windows.Forms.Label()
        Me.lbl5V = New System.Windows.Forms.Label()
        Me.cbm1V = New System.Windows.Forms.ComboBox()
        Me.cbm2V = New System.Windows.Forms.ComboBox()
        Me.panel1V = New System.Windows.Forms.Panel()
        Me.rb3V = New System.Windows.Forms.RadioButton()
        Me.rb2V = New System.Windows.Forms.RadioButton()
        Me.rb1V = New System.Windows.Forms.RadioButton()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.msk1V1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk2V1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk3V1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk4V1 = New System.Windows.Forms.MaskedTextBox()
        Me.msk5V1 = New System.Windows.Forms.MaskedTextBox()
        Me.lbl7V = New System.Windows.Forms.Label()
        Me.lbl8V = New System.Windows.Forms.Label()
        Me.msk9V1 = New System.Windows.Forms.MaskedTextBox()
        Me.lbl9V1 = New System.Windows.Forms.Label()
        Me.lbl10V1 = New System.Windows.Forms.Label()
        Me.btnValidarV1 = New System.Windows.Forms.Button()
        Me.grb2V1 = New System.Windows.Forms.GroupBox()
        Me.cbm4V = New System.Windows.Forms.ComboBox()
        Me.cbm3V = New System.Windows.Forms.ComboBox()
        Me.grb3V1 = New System.Windows.Forms.GroupBox()
        Me.lblDNIV1 = New System.Windows.Forms.Label()
        Me.panel1V.SuspendLayout()
        Me.grb2V1.SuspendLayout()
        Me.grb3V1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btn1V
        '
        Me.btn1V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1V.Location = New System.Drawing.Point(105, 399)
        Me.btn1V.Name = "btn1V"
        Me.btn1V.Size = New System.Drawing.Size(141, 39)
        Me.btn1V.TabIndex = 8
        Me.btn1V.Text = "Continuar"
        Me.btn1V.UseVisualStyleBackColor = True
        '
        'btn2V
        '
        Me.btn2V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2V.Location = New System.Drawing.Point(267, 399)
        Me.btn2V.Name = "btn2V"
        Me.btn2V.Size = New System.Drawing.Size(141, 39)
        Me.btn2V.TabIndex = 9
        Me.btn2V.Text = "Cancelar"
        Me.btn2V.UseVisualStyleBackColor = True
        '
        'lbl1V
        '
        Me.lbl1V.AutoSize = True
        Me.lbl1V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1V.Location = New System.Drawing.Point(27, 14)
        Me.lbl1V.Name = "lbl1V"
        Me.lbl1V.Size = New System.Drawing.Size(121, 23)
        Me.lbl1V.TabIndex = 10
        Me.lbl1V.Text = "DNI del cliente"
        '
        'lbl2V
        '
        Me.lbl2V.AutoSize = True
        Me.lbl2V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2V.Location = New System.Drawing.Point(6, 11)
        Me.lbl2V.Name = "lbl2V"
        Me.lbl2V.Size = New System.Drawing.Size(65, 23)
        Me.lbl2V.TabIndex = 12
        Me.lbl2V.Text = "Nombre"
        '
        'lbl3V
        '
        Me.lbl3V.AutoSize = True
        Me.lbl3V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3V.Location = New System.Drawing.Point(6, 76)
        Me.lbl3V.Name = "lbl3V"
        Me.lbl3V.Size = New System.Drawing.Size(71, 23)
        Me.lbl3V.TabIndex = 13
        Me.lbl3V.Text = "Apellido"
        '
        'lbl4V
        '
        Me.lbl4V.AutoSize = True
        Me.lbl4V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4V.Location = New System.Drawing.Point(6, 146)
        Me.lbl4V.Name = "lbl4V"
        Me.lbl4V.Size = New System.Drawing.Size(192, 23)
        Me.lbl4V.TabIndex = 14
        Me.lbl4V.Text = "Teléfono (celular o fijo)"
        '
        'lbl5V
        '
        Me.lbl5V.AutoSize = True
        Me.lbl5V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5V.Location = New System.Drawing.Point(6, 218)
        Me.lbl5V.Name = "lbl5V"
        Me.lbl5V.Size = New System.Drawing.Size(76, 23)
        Me.lbl5V.TabIndex = 15
        Me.lbl5V.Text = "Dirección"
        '
        'cbm1V
        '
        Me.cbm1V.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm1V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm1V.FormattingEnabled = True
        Me.cbm1V.Items.AddRange(New Object() {"Efectivo", "Débito", "Crédito"})
        Me.cbm1V.Location = New System.Drawing.Point(259, 14)
        Me.cbm1V.Name = "cbm1V"
        Me.cbm1V.Size = New System.Drawing.Size(121, 31)
        Me.cbm1V.TabIndex = 20
        '
        'cbm2V
        '
        Me.cbm2V.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm2V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm2V.FormattingEnabled = True
        Me.cbm2V.Items.AddRange(New Object() {"Contado", "Cuotas"})
        Me.cbm2V.Location = New System.Drawing.Point(398, 14)
        Me.cbm2V.Name = "cbm2V"
        Me.cbm2V.Size = New System.Drawing.Size(121, 31)
        Me.cbm2V.TabIndex = 21
        '
        'panel1V
        '
        Me.panel1V.Controls.Add(Me.rb3V)
        Me.panel1V.Controls.Add(Me.rb2V)
        Me.panel1V.Controls.Add(Me.rb1V)
        Me.panel1V.Location = New System.Drawing.Point(411, 49)
        Me.panel1V.Name = "panel1V"
        Me.panel1V.Size = New System.Drawing.Size(113, 86)
        Me.panel1V.TabIndex = 22
        Me.panel1V.Visible = False
        '
        'rb3V
        '
        Me.rb3V.AutoSize = True
        Me.rb3V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb3V.Location = New System.Drawing.Point(8, 57)
        Me.rb3V.Name = "rb3V"
        Me.rb3V.Size = New System.Drawing.Size(100, 27)
        Me.rb3V.TabIndex = 2
        Me.rb3V.TabStop = True
        Me.rb3V.Text = "12 cuotas"
        Me.rb3V.UseVisualStyleBackColor = True
        '
        'rb2V
        '
        Me.rb2V.AutoSize = True
        Me.rb2V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb2V.Location = New System.Drawing.Point(8, 34)
        Me.rb2V.Name = "rb2V"
        Me.rb2V.Size = New System.Drawing.Size(94, 27)
        Me.rb2V.TabIndex = 1
        Me.rb2V.TabStop = True
        Me.rb2V.Text = "6 cuotas"
        Me.rb2V.UseVisualStyleBackColor = True
        '
        'rb1V
        '
        Me.rb1V.AutoSize = True
        Me.rb1V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb1V.Location = New System.Drawing.Point(8, 11)
        Me.rb1V.Name = "rb1V"
        Me.rb1V.Size = New System.Drawing.Size(94, 27)
        Me.rb1V.TabIndex = 0
        Me.rb1V.TabStop = True
        Me.rb1V.Text = "3 cuotas"
        Me.rb1V.UseVisualStyleBackColor = True
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(536, 450)
        Me.ShapeContainer1.TabIndex = 23
        Me.ShapeContainer1.TabStop = False
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(8, 7)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(524, 439)
        '
        'msk1V1
        '
        Me.msk1V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1V1.Location = New System.Drawing.Point(31, 49)
        Me.msk1V1.Mask = "99999999"
        Me.msk1V1.Name = "msk1V1"
        Me.msk1V1.Size = New System.Drawing.Size(87, 31)
        Me.msk1V1.TabIndex = 29
        '
        'msk2V1
        '
        Me.msk2V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2V1.Location = New System.Drawing.Point(6, 42)
        Me.msk2V1.Mask = "LLLLLLLLLLLLLLLLL"
        Me.msk2V1.Name = "msk2V1"
        Me.msk2V1.Size = New System.Drawing.Size(196, 31)
        Me.msk2V1.TabIndex = 30
        '
        'msk3V1
        '
        Me.msk3V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk3V1.Location = New System.Drawing.Point(6, 102)
        Me.msk3V1.Mask = "LLLLLLLLLLLLLLLLL"
        Me.msk3V1.Name = "msk3V1"
        Me.msk3V1.Size = New System.Drawing.Size(196, 31)
        Me.msk3V1.TabIndex = 31
        '
        'msk4V1
        '
        Me.msk4V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk4V1.Location = New System.Drawing.Point(6, 172)
        Me.msk4V1.Mask = "9999999999"
        Me.msk4V1.Name = "msk4V1"
        Me.msk4V1.Size = New System.Drawing.Size(117, 31)
        Me.msk4V1.TabIndex = 32
        '
        'msk5V1
        '
        Me.msk5V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk5V1.Location = New System.Drawing.Point(6, 244)
        Me.msk5V1.Name = "msk5V1"
        Me.msk5V1.Size = New System.Drawing.Size(196, 31)
        Me.msk5V1.TabIndex = 33
        '
        'lbl7V
        '
        Me.lbl7V.AutoSize = True
        Me.lbl7V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl7V.Location = New System.Drawing.Point(6, 92)
        Me.lbl7V.Name = "lbl7V"
        Me.lbl7V.Size = New System.Drawing.Size(80, 23)
        Me.lbl7V.TabIndex = 36
        Me.lbl7V.Text = "Localidad"
        '
        'lbl8V
        '
        Me.lbl8V.AutoSize = True
        Me.lbl8V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl8V.Location = New System.Drawing.Point(6, 22)
        Me.lbl8V.Name = "lbl8V"
        Me.lbl8V.Size = New System.Drawing.Size(78, 23)
        Me.lbl8V.TabIndex = 38
        Me.lbl8V.Text = "Provincia"
        '
        'msk9V1
        '
        Me.msk9V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk9V1.Location = New System.Drawing.Point(6, 183)
        Me.msk9V1.Mask = "9999"
        Me.msk9V1.Name = "msk9V1"
        Me.msk9V1.Size = New System.Drawing.Size(57, 31)
        Me.msk9V1.TabIndex = 41
        '
        'lbl9V1
        '
        Me.lbl9V1.AutoSize = True
        Me.lbl9V1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl9V1.Location = New System.Drawing.Point(6, 157)
        Me.lbl9V1.Name = "lbl9V1"
        Me.lbl9V1.Size = New System.Drawing.Size(114, 23)
        Me.lbl9V1.TabIndex = 40
        Me.lbl9V1.Text = "Código postal"
        '
        'lbl10V1
        '
        Me.lbl10V1.AutoSize = True
        Me.lbl10V1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl10V1.Location = New System.Drawing.Point(167, 372)
        Me.lbl10V1.Name = "lbl10V1"
        Me.lbl10V1.Size = New System.Drawing.Size(0, 24)
        Me.lbl10V1.TabIndex = 42
        '
        'btnValidarV1
        '
        Me.btnValidarV1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnValidarV1.Location = New System.Drawing.Point(136, 49)
        Me.btnValidarV1.Name = "btnValidarV1"
        Me.btnValidarV1.Size = New System.Drawing.Size(110, 31)
        Me.btnValidarV1.TabIndex = 43
        Me.btnValidarV1.Text = "VALIDAR"
        Me.btnValidarV1.UseVisualStyleBackColor = True
        '
        'grb2V1
        '
        Me.grb2V1.Controls.Add(Me.cbm4V)
        Me.grb2V1.Controls.Add(Me.cbm3V)
        Me.grb2V1.Controls.Add(Me.lbl7V)
        Me.grb2V1.Controls.Add(Me.msk9V1)
        Me.grb2V1.Controls.Add(Me.lbl9V1)
        Me.grb2V1.Controls.Add(Me.lbl8V)
        Me.grb2V1.Location = New System.Drawing.Point(244, 86)
        Me.grb2V1.Name = "grb2V1"
        Me.grb2V1.Size = New System.Drawing.Size(161, 261)
        Me.grb2V1.TabIndex = 44
        Me.grb2V1.TabStop = False
        '
        'cbm4V
        '
        Me.cbm4V.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm4V.Enabled = False
        Me.cbm4V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm4V.FormattingEnabled = True
        Me.cbm4V.Location = New System.Drawing.Point(10, 122)
        Me.cbm4V.Name = "cbm4V"
        Me.cbm4V.Size = New System.Drawing.Size(145, 31)
        Me.cbm4V.TabIndex = 48
        '
        'cbm3V
        '
        Me.cbm3V.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm3V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm3V.FormattingEnabled = True
        Me.cbm3V.Location = New System.Drawing.Point(10, 49)
        Me.cbm3V.Name = "cbm3V"
        Me.cbm3V.Size = New System.Drawing.Size(145, 31)
        Me.cbm3V.TabIndex = 47
        '
        'grb3V1
        '
        Me.grb3V1.Controls.Add(Me.lbl4V)
        Me.grb3V1.Controls.Add(Me.lbl2V)
        Me.grb3V1.Controls.Add(Me.lbl3V)
        Me.grb3V1.Controls.Add(Me.lbl5V)
        Me.grb3V1.Controls.Add(Me.msk5V1)
        Me.grb3V1.Controls.Add(Me.msk2V1)
        Me.grb3V1.Controls.Add(Me.msk4V1)
        Me.grb3V1.Controls.Add(Me.msk3V1)
        Me.grb3V1.Location = New System.Drawing.Point(22, 86)
        Me.grb3V1.Name = "grb3V1"
        Me.grb3V1.Size = New System.Drawing.Size(214, 286)
        Me.grb3V1.TabIndex = 45
        Me.grb3V1.TabStop = False
        '
        'lblDNIV1
        '
        Me.lblDNIV1.AutoSize = True
        Me.lblDNIV1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lblDNIV1.Location = New System.Drawing.Point(132, 372)
        Me.lblDNIV1.Name = "lblDNIV1"
        Me.lblDNIV1.Size = New System.Drawing.Size(270, 23)
        Me.lblDNIV1.TabIndex = 46
        Me.lblDNIV1.Text = "El DNI ya se encuentra registado."
        '
        'Ventas
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(536, 450)
        Me.Controls.Add(Me.lblDNIV1)
        Me.Controls.Add(Me.btnValidarV1)
        Me.Controls.Add(Me.lbl10V1)
        Me.Controls.Add(Me.msk1V1)
        Me.Controls.Add(Me.panel1V)
        Me.Controls.Add(Me.cbm2V)
        Me.Controls.Add(Me.cbm1V)
        Me.Controls.Add(Me.lbl1V)
        Me.Controls.Add(Me.btn2V)
        Me.Controls.Add(Me.btn1V)
        Me.Controls.Add(Me.grb2V1)
        Me.Controls.Add(Me.grb3V1)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Ventas"
        Me.Text = "PEDIDO 1"
        Me.panel1V.ResumeLayout(False)
        Me.panel1V.PerformLayout()
        Me.grb2V1.ResumeLayout(False)
        Me.grb2V1.PerformLayout()
        Me.grb3V1.ResumeLayout(False)
        Me.grb3V1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btn1V As System.Windows.Forms.Button
    Friend WithEvents btn2V As System.Windows.Forms.Button
    Friend WithEvents lbl1V As System.Windows.Forms.Label
    Friend WithEvents lbl2V As System.Windows.Forms.Label
    Friend WithEvents lbl3V As System.Windows.Forms.Label
    Friend WithEvents lbl4V As System.Windows.Forms.Label
    Friend WithEvents lbl5V As System.Windows.Forms.Label
    Friend WithEvents cbm1V As System.Windows.Forms.ComboBox
    Friend WithEvents cbm2V As System.Windows.Forms.ComboBox
    Friend WithEvents panel1V As System.Windows.Forms.Panel
    Friend WithEvents rb3V As System.Windows.Forms.RadioButton
    Friend WithEvents rb2V As System.Windows.Forms.RadioButton
    Friend WithEvents rb1V As System.Windows.Forms.RadioButton
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents msk1V1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2V1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk3V1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk4V1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk5V1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lbl7V As System.Windows.Forms.Label
    Friend WithEvents lbl8V As System.Windows.Forms.Label
    Friend WithEvents msk9V1 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lbl9V1 As System.Windows.Forms.Label
    Friend WithEvents lbl10V1 As System.Windows.Forms.Label
    Friend WithEvents btnValidarV1 As System.Windows.Forms.Button
    Friend WithEvents grb2V1 As System.Windows.Forms.GroupBox
    Friend WithEvents grb3V1 As System.Windows.Forms.GroupBox
    Friend WithEvents lblDNIV1 As System.Windows.Forms.Label
    Friend WithEvents cbm4V As System.Windows.Forms.ComboBox
    Friend WithEvents cbm3V As System.Windows.Forms.ComboBox
End Class
