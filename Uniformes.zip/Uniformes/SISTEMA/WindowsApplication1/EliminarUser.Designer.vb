﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EliminarUser
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txt3AEUser = New System.Windows.Forms.TextBox()
        Me.lbl4EUser = New System.Windows.Forms.Label()
        Me.txt2AEUser = New System.Windows.Forms.TextBox()
        Me.lbl3EUser = New System.Windows.Forms.Label()
        Me.cbm1AEUser = New System.Windows.Forms.ComboBox()
        Me.lbl2EUser = New System.Windows.Forms.Label()
        Me.txt1AEUser = New System.Windows.Forms.TextBox()
        Me.lbl1EUser = New System.Windows.Forms.Label()
        Me.btnCancelarUser = New System.Windows.Forms.Button()
        Me.btnEliminarUser = New System.Windows.Forms.Button()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.SuspendLayout()
        '
        'txt3AEUser
        '
        Me.txt3AEUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt3AEUser.Location = New System.Drawing.Point(24, 238)
        Me.txt3AEUser.Name = "txt3AEUser"
        Me.txt3AEUser.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt3AEUser.Size = New System.Drawing.Size(121, 31)
        Me.txt3AEUser.TabIndex = 38
        '
        'lbl4EUser
        '
        Me.lbl4EUser.AutoSize = True
        Me.lbl4EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl4EUser.Location = New System.Drawing.Point(20, 211)
        Me.lbl4EUser.Name = "lbl4EUser"
        Me.lbl4EUser.Size = New System.Drawing.Size(173, 23)
        Me.lbl4EUser.TabIndex = 37
        Me.lbl4EUser.Text = "Confirmar contraseña"
        '
        'txt2AEUser
        '
        Me.txt2AEUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt2AEUser.Location = New System.Drawing.Point(24, 177)
        Me.txt2AEUser.Name = "txt2AEUser"
        Me.txt2AEUser.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txt2AEUser.Size = New System.Drawing.Size(121, 31)
        Me.txt2AEUser.TabIndex = 36
        '
        'lbl3EUser
        '
        Me.lbl3EUser.AutoSize = True
        Me.lbl3EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl3EUser.Location = New System.Drawing.Point(20, 150)
        Me.lbl3EUser.Name = "lbl3EUser"
        Me.lbl3EUser.Size = New System.Drawing.Size(242, 23)
        Me.lbl3EUser.TabIndex = 35
        Me.lbl3EUser.Text = "Contraseña del usuario actual"
        '
        'cbm1AEUser
        '
        Me.cbm1AEUser.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm1AEUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cbm1AEUser.FormattingEnabled = True
        Me.cbm1AEUser.Location = New System.Drawing.Point(24, 105)
        Me.cbm1AEUser.Name = "cbm1AEUser"
        Me.cbm1AEUser.Size = New System.Drawing.Size(140, 31)
        Me.cbm1AEUser.TabIndex = 34
        '
        'lbl2EUser
        '
        Me.lbl2EUser.AutoSize = True
        Me.lbl2EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl2EUser.Location = New System.Drawing.Point(20, 78)
        Me.lbl2EUser.Name = "lbl2EUser"
        Me.lbl2EUser.Size = New System.Drawing.Size(59, 23)
        Me.lbl2EUser.TabIndex = 33
        Me.lbl2EUser.Text = "Sector"
        '
        'txt1AEUser
        '
        Me.txt1AEUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.txt1AEUser.Location = New System.Drawing.Point(24, 44)
        Me.txt1AEUser.Name = "txt1AEUser"
        Me.txt1AEUser.Size = New System.Drawing.Size(121, 31)
        Me.txt1AEUser.TabIndex = 32
        '
        'lbl1EUser
        '
        Me.lbl1EUser.AutoSize = True
        Me.lbl1EUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1EUser.Location = New System.Drawing.Point(20, 17)
        Me.lbl1EUser.Name = "lbl1EUser"
        Me.lbl1EUser.Size = New System.Drawing.Size(153, 23)
        Me.lbl1EUser.TabIndex = 31
        Me.lbl1EUser.Text = "Nombre de usuario"
        '
        'btnCancelarUser
        '
        Me.btnCancelarUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelarUser.Location = New System.Drawing.Point(146, 275)
        Me.btnCancelarUser.Name = "btnCancelarUser"
        Me.btnCancelarUser.Size = New System.Drawing.Size(97, 39)
        Me.btnCancelarUser.TabIndex = 30
        Me.btnCancelarUser.Text = "Cancelar"
        Me.btnCancelarUser.UseVisualStyleBackColor = True
        '
        'btnEliminarUser
        '
        Me.btnEliminarUser.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEliminarUser.Location = New System.Drawing.Point(34, 275)
        Me.btnEliminarUser.Name = "btnEliminarUser"
        Me.btnEliminarUser.Size = New System.Drawing.Size(97, 39)
        Me.btnEliminarUser.TabIndex = 29
        Me.btnEliminarUser.Text = "Eliminar"
        Me.btnEliminarUser.UseVisualStyleBackColor = True
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(6, 5)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(258, 315)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(270, 325)
        Me.ShapeContainer1.TabIndex = 39
        Me.ShapeContainer1.TabStop = False
        '
        'EliminarUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(270, 325)
        Me.Controls.Add(Me.txt3AEUser)
        Me.Controls.Add(Me.lbl4EUser)
        Me.Controls.Add(Me.txt2AEUser)
        Me.Controls.Add(Me.lbl3EUser)
        Me.Controls.Add(Me.cbm1AEUser)
        Me.Controls.Add(Me.lbl2EUser)
        Me.Controls.Add(Me.txt1AEUser)
        Me.Controls.Add(Me.lbl1EUser)
        Me.Controls.Add(Me.btnCancelarUser)
        Me.Controls.Add(Me.btnEliminarUser)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "EliminarUser"
        Me.Text = "ELIMINAR USUARIO"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt3AEUser As System.Windows.Forms.TextBox
    Friend WithEvents lbl4EUser As System.Windows.Forms.Label
    Friend WithEvents txt2AEUser As System.Windows.Forms.TextBox
    Friend WithEvents lbl3EUser As System.Windows.Forms.Label
    Friend WithEvents cbm1AEUser As System.Windows.Forms.ComboBox
    Friend WithEvents lbl2EUser As System.Windows.Forms.Label
    Friend WithEvents txt1AEUser As System.Windows.Forms.TextBox
    Friend WithEvents lbl1EUser As System.Windows.Forms.Label
    Friend WithEvents btnCancelarUser As System.Windows.Forms.Button
    Friend WithEvents btnEliminarUser As System.Windows.Forms.Button
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
End Class
