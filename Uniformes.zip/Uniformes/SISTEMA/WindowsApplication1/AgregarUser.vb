﻿Imports System.Data.Odbc

Public Class AgregarUser
    Dim b As Integer

    Private Sub btnCancelarUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarUser.Click
        txt1User.Text = ""
        cbm1User.Text = ""
        txt3User.Text = ""
        txt4User.Text = ""
        Me.Hide()
        AgregElimUser.Show()
    End Sub

    Private Sub btnAgregarUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAgregarUser.Click
        If txt3User.Text = txt4User.Text Then
            sql = "SELECT COUNT(*) FROM usuario WHERE nombre='" & txt1User.Text & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) = 0 Then
                    sql = "INSERT INTO usuario VALUES ('', '" & txt1User.Text & "', '" & txt3User.Text & "', '" & cbm1User.Text & "')"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    b = 1
                    txt1User.Text = ""
                    cbm1User.Text = ""
                    txt3User.Text = ""
                    txt4User.Text = ""
                Else
                    MsgBox("El nombre de usuario ingresado ya existe.", MsgBoxStyle.Exclamation, "ERROR")
                    txt1User.Text = ""
                    cbm1User.Text = ""
                    txt3User.Text = ""
                    txt4User.Text = ""
                End If
            End If
            
        Else
            MsgBox("Las contraseñas no coinciden.", MsgBoxStyle.Exclamation, "ERROR")
            txt3User.Text = ""
            txt4User.Text = ""
        End If

        If b = 1 Then
            MsgBox("¡El usuario ha sido agregado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
            txt1User.Text = ""
            cbm1User.Text = ""
            txt3User.Text = ""
            txt4User.Text = ""
            Me.Hide()
            AgregElimUser.Show()
        End If
    End Sub

    Private Sub AgregarUser_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "SELECT sector FROM usuario"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            cbm1User.Items.Add(rs(0))
        Loop
    End Sub
End Class