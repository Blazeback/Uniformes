﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CierreCaja
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdCC = New System.Windows.Forms.DataGridView()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.lbl1V = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.montoCC = New System.Windows.Forms.Label()
        Me.fechaCC = New System.Windows.Forms.Label()
        Me.btn2V = New System.Windows.Forms.Button()
        Me.registrarCC = New System.Windows.Forms.Button()
        CType(Me.grdCC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdCC
        '
        Me.grdCC.AllowUserToAddRows = False
        Me.grdCC.AllowUserToDeleteRows = False
        Me.grdCC.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdCC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdCC.Location = New System.Drawing.Point(12, 35)
        Me.grdCC.Name = "grdCC"
        Me.grdCC.ReadOnly = True
        Me.grdCC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdCC.Size = New System.Drawing.Size(369, 216)
        Me.grdCC.TabIndex = 75
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(5, 5)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(383, 400)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(393, 416)
        Me.ShapeContainer1.TabIndex = 76
        Me.ShapeContainer1.TabStop = False
        '
        'lbl1V
        '
        Me.lbl1V.AutoSize = True
        Me.lbl1V.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1V.Location = New System.Drawing.Point(136, 9)
        Me.lbl1V.Name = "lbl1V"
        Me.lbl1V.Size = New System.Drawing.Size(99, 25)
        Me.lbl1V.TabIndex = 77
        Me.lbl1V.Text = "REGISTRO"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(55, 254)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(148, 23)
        Me.Label1.TabIndex = 78
        Me.Label1.Text = "MONTO DEL DÍA:"
        '
        'montoCC
        '
        Me.montoCC.AutoSize = True
        Me.montoCC.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.montoCC.Location = New System.Drawing.Point(209, 252)
        Me.montoCC.Name = "montoCC"
        Me.montoCC.Size = New System.Drawing.Size(21, 25)
        Me.montoCC.TabIndex = 79
        Me.montoCC.Text = "-"
        '
        'fechaCC
        '
        Me.fechaCC.AutoSize = True
        Me.fechaCC.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fechaCC.Location = New System.Drawing.Point(12, 9)
        Me.fechaCC.Name = "fechaCC"
        Me.fechaCC.Size = New System.Drawing.Size(21, 25)
        Me.fechaCC.TabIndex = 80
        Me.fechaCC.Text = "-"
        '
        'btn2V
        '
        Me.btn2V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn2V.Location = New System.Drawing.Point(108, 359)
        Me.btn2V.Name = "btn2V"
        Me.btn2V.Size = New System.Drawing.Size(155, 39)
        Me.btn2V.TabIndex = 82
        Me.btn2V.Text = "Cancelar"
        Me.btn2V.UseVisualStyleBackColor = True
        '
        'registrarCC
        '
        Me.registrarCC.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.registrarCC.Location = New System.Drawing.Point(108, 289)
        Me.registrarCC.Name = "registrarCC"
        Me.registrarCC.Size = New System.Drawing.Size(155, 64)
        Me.registrarCC.TabIndex = 81
        Me.registrarCC.Text = "Registrar cierre del día"
        Me.registrarCC.UseVisualStyleBackColor = True
        '
        'CierreCaja
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(393, 416)
        Me.Controls.Add(Me.btn2V)
        Me.Controls.Add(Me.registrarCC)
        Me.Controls.Add(Me.fechaCC)
        Me.Controls.Add(Me.montoCC)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lbl1V)
        Me.Controls.Add(Me.grdCC)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "CierreCaja"
        Me.Text = "CIERRE DE CAJA"
        CType(Me.grdCC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grdCC As System.Windows.Forms.DataGridView
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents lbl1V As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents montoCC As System.Windows.Forms.Label
    Friend WithEvents fechaCC As System.Windows.Forms.Label
    Friend WithEvents btn2V As System.Windows.Forms.Button
    Friend WithEvents registrarCC As System.Windows.Forms.Button
End Class
