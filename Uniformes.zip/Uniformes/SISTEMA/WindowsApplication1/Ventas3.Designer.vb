﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ventas3
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lineshape = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.rb4V3 = New System.Windows.Forms.RadioButton()
        Me.lbl7V3 = New System.Windows.Forms.Label()
        Me.cbm2V3 = New System.Windows.Forms.ComboBox()
        Me.chk10V3 = New System.Windows.Forms.CheckBox()
        Me.chk5V3 = New System.Windows.Forms.CheckBox()
        Me.lbl4V3 = New System.Windows.Forms.Label()
        Me.chk6V3 = New System.Windows.Forms.CheckBox()
        Me.chk7V3 = New System.Windows.Forms.CheckBox()
        Me.rb5V3 = New System.Windows.Forms.RadioButton()
        Me.chk8V3 = New System.Windows.Forms.CheckBox()
        Me.chk9V3 = New System.Windows.Forms.CheckBox()
        Me.lbl5V3 = New System.Windows.Forms.Label()
        Me.lbl6V3 = New System.Windows.Forms.Label()
        Me.rb7V3 = New System.Windows.Forms.RadioButton()
        Me.rb6V3 = New System.Windows.Forms.RadioButton()
        Me.rb8V3 = New System.Windows.Forms.RadioButton()
        Me.grb2V3 = New System.Windows.Forms.GroupBox()
        Me.lbl8V3 = New System.Windows.Forms.Label()
        Me.chk12V3 = New System.Windows.Forms.CheckBox()
        Me.rb9V3 = New System.Windows.Forms.RadioButton()
        Me.chk11V3 = New System.Windows.Forms.CheckBox()
        Me.lbl3V3 = New System.Windows.Forms.Label()
        Me.cbm1V3 = New System.Windows.Forms.ComboBox()
        Me.chk3V3 = New System.Windows.Forms.CheckBox()
        Me.chk1V3 = New System.Windows.Forms.CheckBox()
        Me.chk2V3 = New System.Windows.Forms.CheckBox()
        Me.chk4V3 = New System.Windows.Forms.CheckBox()
        Me.lbl1V3 = New System.Windows.Forms.Label()
        Me.lbl2V3 = New System.Windows.Forms.Label()
        Me.rb2V3 = New System.Windows.Forms.RadioButton()
        Me.rb1V3 = New System.Windows.Forms.RadioButton()
        Me.grb1V3 = New System.Windows.Forms.GroupBox()
        Me.btnCancelarV3 = New System.Windows.Forms.Button()
        Me.btn1V3 = New System.Windows.Forms.Button()
        Me.chkShorV3 = New System.Windows.Forms.CheckBox()
        Me.chkBuzoV3 = New System.Windows.Forms.CheckBox()
        Me.grbShV3 = New System.Windows.Forms.GroupBox()
        Me.msk4V3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk3V3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk2V3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk1V3 = New System.Windows.Forms.MaskedTextBox()
        Me.grbBuzoV3 = New System.Windows.Forms.GroupBox()
        Me.msk8V3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk7V3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk6V3 = New System.Windows.Forms.MaskedTextBox()
        Me.msk5V3 = New System.Windows.Forms.MaskedTextBox()
        Me.grbBuzoEV3 = New System.Windows.Forms.GroupBox()
        Me.msk12V3 = New System.Windows.Forms.MaskedTextBox()
        Me.grb3V3 = New System.Windows.Forms.GroupBox()
        Me.rb12V3 = New System.Windows.Forms.RadioButton()
        Me.chk19V3 = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.chk17V3 = New System.Windows.Forms.CheckBox()
        Me.chk18V3 = New System.Windows.Forms.CheckBox()
        Me.rb13V3 = New System.Windows.Forms.RadioButton()
        Me.msk11V3 = New System.Windows.Forms.MaskedTextBox()
        Me.rb10V3 = New System.Windows.Forms.RadioButton()
        Me.msk10V3 = New System.Windows.Forms.MaskedTextBox()
        Me.rb11V3 = New System.Windows.Forms.RadioButton()
        Me.msk9V3 = New System.Windows.Forms.MaskedTextBox()
        Me.lbl11V3 = New System.Windows.Forms.Label()
        Me.lbl10V3 = New System.Windows.Forms.Label()
        Me.cbm3V3 = New System.Windows.Forms.ComboBox()
        Me.lbl9V3 = New System.Windows.Forms.Label()
        Me.chk16V3 = New System.Windows.Forms.CheckBox()
        Me.chk13V3 = New System.Windows.Forms.CheckBox()
        Me.chk14V3 = New System.Windows.Forms.CheckBox()
        Me.chk15V3 = New System.Windows.Forms.CheckBox()
        Me.chkBuzoEV3 = New System.Windows.Forms.CheckBox()
        Me.grbCamperV3 = New System.Windows.Forms.GroupBox()
        Me.msk16V3 = New System.Windows.Forms.MaskedTextBox()
        Me.grb4V3 = New System.Windows.Forms.GroupBox()
        Me.chk26V3 = New System.Windows.Forms.CheckBox()
        Me.chk25V3 = New System.Windows.Forms.CheckBox()
        Me.rb16V3 = New System.Windows.Forms.RadioButton()
        Me.chk24V3 = New System.Windows.Forms.CheckBox()
        Me.rb17V3 = New System.Windows.Forms.RadioButton()
        Me.lbl16V3 = New System.Windows.Forms.Label()
        Me.msk15V3 = New System.Windows.Forms.MaskedTextBox()
        Me.rb14V3 = New System.Windows.Forms.RadioButton()
        Me.msk14V3 = New System.Windows.Forms.MaskedTextBox()
        Me.rb15V3 = New System.Windows.Forms.RadioButton()
        Me.msk13V3 = New System.Windows.Forms.MaskedTextBox()
        Me.lbl15V3 = New System.Windows.Forms.Label()
        Me.lbl14V3 = New System.Windows.Forms.Label()
        Me.cbm4V3 = New System.Windows.Forms.ComboBox()
        Me.lbl13V3 = New System.Windows.Forms.Label()
        Me.chk23V3 = New System.Windows.Forms.CheckBox()
        Me.chk20V3 = New System.Windows.Forms.CheckBox()
        Me.chk21V3 = New System.Windows.Forms.CheckBox()
        Me.chk22V3 = New System.Windows.Forms.CheckBox()
        Me.chkCamperaV3 = New System.Windows.Forms.CheckBox()
        Me.grb2V3.SuspendLayout()
        Me.grb1V3.SuspendLayout()
        Me.grbShV3.SuspendLayout()
        Me.grbBuzoV3.SuspendLayout()
        Me.grbBuzoEV3.SuspendLayout()
        Me.grb3V3.SuspendLayout()
        Me.grbCamperV3.SuspendLayout()
        Me.grb4V3.SuspendLayout()
        Me.SuspendLayout()
        '
        'lineshape
        '
        Me.lineshape.BorderWidth = 2
        Me.lineshape.Location = New System.Drawing.Point(4, 4)
        Me.lineshape.Name = "lineshape"
        Me.lineshape.Size = New System.Drawing.Size(1032, 597)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.lineshape})
        Me.ShapeContainer1.Size = New System.Drawing.Size(1047, 602)
        Me.ShapeContainer1.TabIndex = 0
        Me.ShapeContainer1.TabStop = False
        '
        'rb4V3
        '
        Me.rb4V3.AutoSize = True
        Me.rb4V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb4V3.Location = New System.Drawing.Point(128, 58)
        Me.rb4V3.Name = "rb4V3"
        Me.rb4V3.Size = New System.Drawing.Size(48, 27)
        Me.rb4V3.TabIndex = 22
        Me.rb4V3.TabStop = True
        Me.rb4V3.Text = "Sí."
        Me.rb4V3.UseVisualStyleBackColor = True
        '
        'lbl7V3
        '
        Me.lbl7V3.AutoSize = True
        Me.lbl7V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl7V3.Location = New System.Drawing.Point(22, 257)
        Me.lbl7V3.Name = "lbl7V3"
        Me.lbl7V3.Size = New System.Drawing.Size(49, 23)
        Me.lbl7V3.TabIndex = 144
        Me.lbl7V3.Text = "Color"
        '
        'cbm2V3
        '
        Me.cbm2V3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm2V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm2V3.FormattingEnabled = True
        Me.cbm2V3.Location = New System.Drawing.Point(98, 254)
        Me.cbm2V3.Name = "cbm2V3"
        Me.cbm2V3.Size = New System.Drawing.Size(121, 31)
        Me.cbm2V3.TabIndex = 139
        '
        'chk10V3
        '
        Me.chk10V3.AutoSize = True
        Me.chk10V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk10V3.Location = New System.Drawing.Point(8, 16)
        Me.chk10V3.Name = "chk10V3"
        Me.chk10V3.Size = New System.Drawing.Size(81, 27)
        Me.chk10V3.TabIndex = 18
        Me.chk10V3.Text = "Cordón"
        Me.chk10V3.UseVisualStyleBackColor = True
        '
        'chk5V3
        '
        Me.chk5V3.AutoSize = True
        Me.chk5V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk5V3.Location = New System.Drawing.Point(14, 19)
        Me.chk5V3.Name = "chk5V3"
        Me.chk5V3.Size = New System.Drawing.Size(165, 27)
        Me.chk5V3.TabIndex = 28
        Me.chk5V3.Text = "Elástico ajustable"
        Me.chk5V3.UseVisualStyleBackColor = True
        '
        'lbl4V3
        '
        Me.lbl4V3.AutoSize = True
        Me.lbl4V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl4V3.Location = New System.Drawing.Point(28, 72)
        Me.lbl4V3.Name = "lbl4V3"
        Me.lbl4V3.Size = New System.Drawing.Size(90, 23)
        Me.lbl4V3.TabIndex = 24
        Me.lbl4V3.Text = "¿Bordado?"
        '
        'chk6V3
        '
        Me.chk6V3.AutoSize = True
        Me.chk6V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk6V3.Location = New System.Drawing.Point(11, 107)
        Me.chk6V3.Name = "chk6V3"
        Me.chk6V3.Size = New System.Drawing.Size(67, 27)
        Me.chk6V3.TabIndex = 136
        Me.chk6V3.Text = "Chico"
        Me.chk6V3.UseVisualStyleBackColor = True
        '
        'chk7V3
        '
        Me.chk7V3.AutoSize = True
        Me.chk7V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk7V3.Location = New System.Drawing.Point(10, 141)
        Me.chk7V3.Name = "chk7V3"
        Me.chk7V3.Size = New System.Drawing.Size(89, 27)
        Me.chk7V3.TabIndex = 135
        Me.chk7V3.Text = "Mediano"
        Me.chk7V3.UseVisualStyleBackColor = True
        '
        'rb5V3
        '
        Me.rb5V3.AutoSize = True
        Me.rb5V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb5V3.Location = New System.Drawing.Point(128, 81)
        Me.rb5V3.Name = "rb5V3"
        Me.rb5V3.Size = New System.Drawing.Size(51, 27)
        Me.rb5V3.TabIndex = 23
        Me.rb5V3.TabStop = True
        Me.rb5V3.Text = "No."
        Me.rb5V3.UseVisualStyleBackColor = True
        '
        'chk8V3
        '
        Me.chk8V3.AutoSize = True
        Me.chk8V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk8V3.Location = New System.Drawing.Point(10, 175)
        Me.chk8V3.Name = "chk8V3"
        Me.chk8V3.Size = New System.Drawing.Size(82, 27)
        Me.chk8V3.TabIndex = 137
        Me.chk8V3.Text = "Grande"
        Me.chk8V3.UseVisualStyleBackColor = True
        '
        'chk9V3
        '
        Me.chk9V3.AutoSize = True
        Me.chk9V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk9V3.Location = New System.Drawing.Point(10, 209)
        Me.chk9V3.Name = "chk9V3"
        Me.chk9V3.Size = New System.Drawing.Size(117, 27)
        Me.chk9V3.TabIndex = 138
        Me.chk9V3.Text = "Muy grande"
        Me.chk9V3.UseVisualStyleBackColor = True
        '
        'lbl5V3
        '
        Me.lbl5V3.AutoSize = True
        Me.lbl5V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl5V3.Location = New System.Drawing.Point(22, 23)
        Me.lbl5V3.Name = "lbl5V3"
        Me.lbl5V3.Size = New System.Drawing.Size(96, 23)
        Me.lbl5V3.TabIndex = 134
        Me.lbl5V3.Text = "¿Estándar?"
        '
        'lbl6V3
        '
        Me.lbl6V3.AutoSize = True
        Me.lbl6V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl6V3.Location = New System.Drawing.Point(146, 68)
        Me.lbl6V3.Name = "lbl6V3"
        Me.lbl6V3.Size = New System.Drawing.Size(75, 23)
        Me.lbl6V3.TabIndex = 133
        Me.lbl6V3.Text = "Cantidad"
        '
        'rb7V3
        '
        Me.rb7V3.AutoSize = True
        Me.rb7V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb7V3.Location = New System.Drawing.Point(122, 32)
        Me.rb7V3.Name = "rb7V3"
        Me.rb7V3.Size = New System.Drawing.Size(51, 27)
        Me.rb7V3.TabIndex = 132
        Me.rb7V3.TabStop = True
        Me.rb7V3.Text = "No."
        Me.rb7V3.UseVisualStyleBackColor = True
        '
        'rb6V3
        '
        Me.rb6V3.AutoSize = True
        Me.rb6V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb6V3.Location = New System.Drawing.Point(122, 9)
        Me.rb6V3.Name = "rb6V3"
        Me.rb6V3.Size = New System.Drawing.Size(48, 27)
        Me.rb6V3.TabIndex = 131
        Me.rb6V3.TabStop = True
        Me.rb6V3.Text = "Sí."
        Me.rb6V3.UseVisualStyleBackColor = True
        '
        'rb8V3
        '
        Me.rb8V3.AutoSize = True
        Me.rb8V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb8V3.Location = New System.Drawing.Point(139, 72)
        Me.rb8V3.Name = "rb8V3"
        Me.rb8V3.Size = New System.Drawing.Size(48, 27)
        Me.rb8V3.TabIndex = 22
        Me.rb8V3.TabStop = True
        Me.rb8V3.Text = "Sí."
        Me.rb8V3.UseVisualStyleBackColor = True
        '
        'grb2V3
        '
        Me.grb2V3.Controls.Add(Me.rb8V3)
        Me.grb2V3.Controls.Add(Me.lbl8V3)
        Me.grb2V3.Controls.Add(Me.chk12V3)
        Me.grb2V3.Controls.Add(Me.rb9V3)
        Me.grb2V3.Controls.Add(Me.chk11V3)
        Me.grb2V3.Controls.Add(Me.chk10V3)
        Me.grb2V3.Location = New System.Drawing.Point(11, 292)
        Me.grb2V3.Name = "grb2V3"
        Me.grb2V3.Size = New System.Drawing.Size(225, 153)
        Me.grb2V3.TabIndex = 145
        Me.grb2V3.TabStop = False
        Me.grb2V3.Visible = False
        '
        'lbl8V3
        '
        Me.lbl8V3.AutoSize = True
        Me.lbl8V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl8V3.Location = New System.Drawing.Point(39, 86)
        Me.lbl8V3.Name = "lbl8V3"
        Me.lbl8V3.Size = New System.Drawing.Size(90, 23)
        Me.lbl8V3.TabIndex = 24
        Me.lbl8V3.Text = "¿Bordado?"
        '
        'chk12V3
        '
        Me.chk12V3.AutoSize = True
        Me.chk12V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk12V3.Location = New System.Drawing.Point(102, 16)
        Me.chk12V3.Name = "chk12V3"
        Me.chk12V3.Size = New System.Drawing.Size(85, 27)
        Me.chk12V3.TabIndex = 29
        Me.chk12V3.Text = "Bolsillo"
        Me.chk12V3.UseVisualStyleBackColor = True
        '
        'rb9V3
        '
        Me.rb9V3.AutoSize = True
        Me.rb9V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb9V3.Location = New System.Drawing.Point(139, 99)
        Me.rb9V3.Name = "rb9V3"
        Me.rb9V3.Size = New System.Drawing.Size(51, 27)
        Me.rb9V3.TabIndex = 23
        Me.rb9V3.TabStop = True
        Me.rb9V3.Text = "No."
        Me.rb9V3.UseVisualStyleBackColor = True
        '
        'chk11V3
        '
        Me.chk11V3.AutoSize = True
        Me.chk11V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk11V3.Location = New System.Drawing.Point(8, 49)
        Me.chk11V3.Name = "chk11V3"
        Me.chk11V3.Size = New System.Drawing.Size(90, 27)
        Me.chk11V3.TabIndex = 27
        Me.chk11V3.Text = "Capucha"
        Me.chk11V3.UseVisualStyleBackColor = True
        '
        'lbl3V3
        '
        Me.lbl3V3.AutoSize = True
        Me.lbl3V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl3V3.Location = New System.Drawing.Point(23, 248)
        Me.lbl3V3.Name = "lbl3V3"
        Me.lbl3V3.Size = New System.Drawing.Size(49, 23)
        Me.lbl3V3.TabIndex = 128
        Me.lbl3V3.Text = "Color"
        '
        'cbm1V3
        '
        Me.cbm1V3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm1V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm1V3.FormattingEnabled = True
        Me.cbm1V3.Location = New System.Drawing.Point(99, 245)
        Me.cbm1V3.Name = "cbm1V3"
        Me.cbm1V3.Size = New System.Drawing.Size(121, 31)
        Me.cbm1V3.TabIndex = 123
        '
        'chk3V3
        '
        Me.chk3V3.AutoSize = True
        Me.chk3V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk3V3.Location = New System.Drawing.Point(11, 166)
        Me.chk3V3.Name = "chk3V3"
        Me.chk3V3.Size = New System.Drawing.Size(82, 27)
        Me.chk3V3.TabIndex = 121
        Me.chk3V3.Text = "Grande"
        Me.chk3V3.UseVisualStyleBackColor = True
        '
        'chk1V3
        '
        Me.chk1V3.AutoSize = True
        Me.chk1V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk1V3.Location = New System.Drawing.Point(12, 98)
        Me.chk1V3.Name = "chk1V3"
        Me.chk1V3.Size = New System.Drawing.Size(67, 27)
        Me.chk1V3.TabIndex = 120
        Me.chk1V3.Text = "Chico"
        Me.chk1V3.UseVisualStyleBackColor = True
        '
        'chk2V3
        '
        Me.chk2V3.AutoSize = True
        Me.chk2V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk2V3.Location = New System.Drawing.Point(11, 132)
        Me.chk2V3.Name = "chk2V3"
        Me.chk2V3.Size = New System.Drawing.Size(89, 27)
        Me.chk2V3.TabIndex = 119
        Me.chk2V3.Text = "Mediano"
        Me.chk2V3.UseVisualStyleBackColor = True
        '
        'chk4V3
        '
        Me.chk4V3.AutoSize = True
        Me.chk4V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk4V3.Location = New System.Drawing.Point(11, 200)
        Me.chk4V3.Name = "chk4V3"
        Me.chk4V3.Size = New System.Drawing.Size(117, 27)
        Me.chk4V3.TabIndex = 122
        Me.chk4V3.Text = "Muy grande"
        Me.chk4V3.UseVisualStyleBackColor = True
        '
        'lbl1V3
        '
        Me.lbl1V3.AutoSize = True
        Me.lbl1V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1V3.Location = New System.Drawing.Point(23, 23)
        Me.lbl1V3.Name = "lbl1V3"
        Me.lbl1V3.Size = New System.Drawing.Size(96, 23)
        Me.lbl1V3.TabIndex = 118
        Me.lbl1V3.Text = "¿Estándar?"
        '
        'lbl2V3
        '
        Me.lbl2V3.AutoSize = True
        Me.lbl2V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl2V3.Location = New System.Drawing.Point(147, 59)
        Me.lbl2V3.Name = "lbl2V3"
        Me.lbl2V3.Size = New System.Drawing.Size(75, 23)
        Me.lbl2V3.TabIndex = 117
        Me.lbl2V3.Text = "Cantidad"
        '
        'rb2V3
        '
        Me.rb2V3.AutoSize = True
        Me.rb2V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb2V3.Location = New System.Drawing.Point(123, 32)
        Me.rb2V3.Name = "rb2V3"
        Me.rb2V3.Size = New System.Drawing.Size(51, 27)
        Me.rb2V3.TabIndex = 116
        Me.rb2V3.TabStop = True
        Me.rb2V3.Text = "No."
        Me.rb2V3.UseVisualStyleBackColor = True
        '
        'rb1V3
        '
        Me.rb1V3.AutoSize = True
        Me.rb1V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb1V3.Location = New System.Drawing.Point(123, 9)
        Me.rb1V3.Name = "rb1V3"
        Me.rb1V3.Size = New System.Drawing.Size(48, 27)
        Me.rb1V3.TabIndex = 115
        Me.rb1V3.TabStop = True
        Me.rb1V3.Text = "Sí."
        Me.rb1V3.UseVisualStyleBackColor = True
        '
        'grb1V3
        '
        Me.grb1V3.Controls.Add(Me.chk5V3)
        Me.grb1V3.Controls.Add(Me.rb4V3)
        Me.grb1V3.Controls.Add(Me.rb5V3)
        Me.grb1V3.Controls.Add(Me.lbl4V3)
        Me.grb1V3.Location = New System.Drawing.Point(12, 283)
        Me.grb1V3.Name = "grb1V3"
        Me.grb1V3.Size = New System.Drawing.Size(225, 121)
        Me.grb1V3.TabIndex = 129
        Me.grb1V3.TabStop = False
        Me.grb1V3.Visible = False
        '
        'btnCancelarV3
        '
        Me.btnCancelarV3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnCancelarV3.Location = New System.Drawing.Point(570, 553)
        Me.btnCancelarV3.Name = "btnCancelarV3"
        Me.btnCancelarV3.Size = New System.Drawing.Size(380, 39)
        Me.btnCancelarV3.TabIndex = 147
        Me.btnCancelarV3.Text = "Volver"
        Me.btnCancelarV3.UseVisualStyleBackColor = True
        '
        'btn1V3
        '
        Me.btn1V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btn1V3.Location = New System.Drawing.Point(105, 553)
        Me.btn1V3.Name = "btn1V3"
        Me.btn1V3.Size = New System.Drawing.Size(381, 39)
        Me.btn1V3.TabIndex = 146
        Me.btn1V3.Text = "Continuar"
        Me.btn1V3.UseVisualStyleBackColor = True
        '
        'chkShorV3
        '
        Me.chkShorV3.AutoSize = True
        Me.chkShorV3.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkShorV3.Location = New System.Drawing.Point(81, 17)
        Me.chkShorV3.Name = "chkShorV3"
        Me.chkShorV3.Size = New System.Drawing.Size(84, 33)
        Me.chkShorV3.TabIndex = 148
        Me.chkShorV3.Text = "Short"
        Me.chkShorV3.UseVisualStyleBackColor = True
        '
        'chkBuzoV3
        '
        Me.chkBuzoV3.AutoSize = True
        Me.chkBuzoV3.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBuzoV3.Location = New System.Drawing.Point(334, 17)
        Me.chkBuzoV3.Name = "chkBuzoV3"
        Me.chkBuzoV3.Size = New System.Drawing.Size(77, 33)
        Me.chkBuzoV3.TabIndex = 149
        Me.chkBuzoV3.Text = "Buzo"
        Me.chkBuzoV3.UseVisualStyleBackColor = True
        '
        'grbShV3
        '
        Me.grbShV3.Controls.Add(Me.msk4V3)
        Me.grbShV3.Controls.Add(Me.lbl2V3)
        Me.grbShV3.Controls.Add(Me.msk3V3)
        Me.grbShV3.Controls.Add(Me.grb1V3)
        Me.grbShV3.Controls.Add(Me.msk2V3)
        Me.grbShV3.Controls.Add(Me.rb1V3)
        Me.grbShV3.Controls.Add(Me.msk1V3)
        Me.grbShV3.Controls.Add(Me.rb2V3)
        Me.grbShV3.Controls.Add(Me.lbl1V3)
        Me.grbShV3.Controls.Add(Me.chk4V3)
        Me.grbShV3.Controls.Add(Me.chk2V3)
        Me.grbShV3.Controls.Add(Me.chk1V3)
        Me.grbShV3.Controls.Add(Me.chk3V3)
        Me.grbShV3.Controls.Add(Me.cbm1V3)
        Me.grbShV3.Controls.Add(Me.lbl3V3)
        Me.grbShV3.Location = New System.Drawing.Point(12, 52)
        Me.grbShV3.Name = "grbShV3"
        Me.grbShV3.Size = New System.Drawing.Size(244, 418)
        Me.grbShV3.TabIndex = 150
        Me.grbShV3.TabStop = False
        Me.grbShV3.Visible = False
        '
        'msk4V3
        '
        Me.msk4V3.Enabled = False
        Me.msk4V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk4V3.Location = New System.Drawing.Point(149, 200)
        Me.msk4V3.Mask = "99999"
        Me.msk4V3.Name = "msk4V3"
        Me.msk4V3.Size = New System.Drawing.Size(71, 31)
        Me.msk4V3.TabIndex = 159
        Me.msk4V3.ValidatingType = GetType(Integer)
        '
        'msk3V3
        '
        Me.msk3V3.Enabled = False
        Me.msk3V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk3V3.Location = New System.Drawing.Point(149, 163)
        Me.msk3V3.Mask = "99999"
        Me.msk3V3.Name = "msk3V3"
        Me.msk3V3.Size = New System.Drawing.Size(71, 31)
        Me.msk3V3.TabIndex = 158
        Me.msk3V3.ValidatingType = GetType(Integer)
        '
        'msk2V3
        '
        Me.msk2V3.Enabled = False
        Me.msk2V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk2V3.Location = New System.Drawing.Point(149, 123)
        Me.msk2V3.Mask = "99999"
        Me.msk2V3.Name = "msk2V3"
        Me.msk2V3.Size = New System.Drawing.Size(71, 31)
        Me.msk2V3.TabIndex = 157
        Me.msk2V3.ValidatingType = GetType(Integer)
        '
        'msk1V3
        '
        Me.msk1V3.Enabled = False
        Me.msk1V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk1V3.Location = New System.Drawing.Point(149, 86)
        Me.msk1V3.Mask = "99999"
        Me.msk1V3.Name = "msk1V3"
        Me.msk1V3.Size = New System.Drawing.Size(71, 31)
        Me.msk1V3.TabIndex = 156
        Me.msk1V3.ValidatingType = GetType(Integer)
        '
        'grbBuzoV3
        '
        Me.grbBuzoV3.Controls.Add(Me.msk8V3)
        Me.grbBuzoV3.Controls.Add(Me.grb2V3)
        Me.grbBuzoV3.Controls.Add(Me.msk7V3)
        Me.grbBuzoV3.Controls.Add(Me.rb6V3)
        Me.grbBuzoV3.Controls.Add(Me.msk6V3)
        Me.grbBuzoV3.Controls.Add(Me.rb7V3)
        Me.grbBuzoV3.Controls.Add(Me.msk5V3)
        Me.grbBuzoV3.Controls.Add(Me.lbl7V3)
        Me.grbBuzoV3.Controls.Add(Me.lbl6V3)
        Me.grbBuzoV3.Controls.Add(Me.cbm2V3)
        Me.grbBuzoV3.Controls.Add(Me.lbl5V3)
        Me.grbBuzoV3.Controls.Add(Me.chk9V3)
        Me.grbBuzoV3.Controls.Add(Me.chk6V3)
        Me.grbBuzoV3.Controls.Add(Me.chk7V3)
        Me.grbBuzoV3.Controls.Add(Me.chk8V3)
        Me.grbBuzoV3.Location = New System.Drawing.Point(262, 52)
        Me.grbBuzoV3.Name = "grbBuzoV3"
        Me.grbBuzoV3.Size = New System.Drawing.Size(246, 448)
        Me.grbBuzoV3.TabIndex = 151
        Me.grbBuzoV3.TabStop = False
        Me.grbBuzoV3.Visible = False
        '
        'msk8V3
        '
        Me.msk8V3.Enabled = False
        Me.msk8V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk8V3.Location = New System.Drawing.Point(148, 209)
        Me.msk8V3.Mask = "99999"
        Me.msk8V3.Name = "msk8V3"
        Me.msk8V3.Size = New System.Drawing.Size(71, 31)
        Me.msk8V3.TabIndex = 163
        Me.msk8V3.ValidatingType = GetType(Integer)
        '
        'msk7V3
        '
        Me.msk7V3.Enabled = False
        Me.msk7V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk7V3.Location = New System.Drawing.Point(148, 172)
        Me.msk7V3.Mask = "99999"
        Me.msk7V3.Name = "msk7V3"
        Me.msk7V3.Size = New System.Drawing.Size(71, 31)
        Me.msk7V3.TabIndex = 162
        Me.msk7V3.ValidatingType = GetType(Integer)
        '
        'msk6V3
        '
        Me.msk6V3.Enabled = False
        Me.msk6V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk6V3.Location = New System.Drawing.Point(148, 132)
        Me.msk6V3.Mask = "99999"
        Me.msk6V3.Name = "msk6V3"
        Me.msk6V3.Size = New System.Drawing.Size(71, 31)
        Me.msk6V3.TabIndex = 161
        Me.msk6V3.ValidatingType = GetType(Integer)
        '
        'msk5V3
        '
        Me.msk5V3.Enabled = False
        Me.msk5V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk5V3.Location = New System.Drawing.Point(148, 95)
        Me.msk5V3.Mask = "99999"
        Me.msk5V3.Name = "msk5V3"
        Me.msk5V3.Size = New System.Drawing.Size(71, 31)
        Me.msk5V3.TabIndex = 160
        Me.msk5V3.ValidatingType = GetType(Integer)
        '
        'grbBuzoEV3
        '
        Me.grbBuzoEV3.Controls.Add(Me.msk12V3)
        Me.grbBuzoEV3.Controls.Add(Me.grb3V3)
        Me.grbBuzoEV3.Controls.Add(Me.msk11V3)
        Me.grbBuzoEV3.Controls.Add(Me.rb10V3)
        Me.grbBuzoEV3.Controls.Add(Me.msk10V3)
        Me.grbBuzoEV3.Controls.Add(Me.rb11V3)
        Me.grbBuzoEV3.Controls.Add(Me.msk9V3)
        Me.grbBuzoEV3.Controls.Add(Me.lbl11V3)
        Me.grbBuzoEV3.Controls.Add(Me.lbl10V3)
        Me.grbBuzoEV3.Controls.Add(Me.cbm3V3)
        Me.grbBuzoEV3.Controls.Add(Me.lbl9V3)
        Me.grbBuzoEV3.Controls.Add(Me.chk16V3)
        Me.grbBuzoEV3.Controls.Add(Me.chk13V3)
        Me.grbBuzoEV3.Controls.Add(Me.chk14V3)
        Me.grbBuzoEV3.Controls.Add(Me.chk15V3)
        Me.grbBuzoEV3.Location = New System.Drawing.Point(514, 52)
        Me.grbBuzoEV3.Name = "grbBuzoEV3"
        Me.grbBuzoEV3.Size = New System.Drawing.Size(246, 445)
        Me.grbBuzoEV3.TabIndex = 152
        Me.grbBuzoEV3.TabStop = False
        Me.grbBuzoEV3.Visible = False
        '
        'msk12V3
        '
        Me.msk12V3.Enabled = False
        Me.msk12V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk12V3.Location = New System.Drawing.Point(148, 212)
        Me.msk12V3.Mask = "99999"
        Me.msk12V3.Name = "msk12V3"
        Me.msk12V3.Size = New System.Drawing.Size(71, 31)
        Me.msk12V3.TabIndex = 167
        Me.msk12V3.ValidatingType = GetType(Integer)
        '
        'grb3V3
        '
        Me.grb3V3.Controls.Add(Me.rb12V3)
        Me.grb3V3.Controls.Add(Me.chk19V3)
        Me.grb3V3.Controls.Add(Me.Label1)
        Me.grb3V3.Controls.Add(Me.chk17V3)
        Me.grb3V3.Controls.Add(Me.chk18V3)
        Me.grb3V3.Controls.Add(Me.rb13V3)
        Me.grb3V3.Location = New System.Drawing.Point(11, 292)
        Me.grb3V3.Name = "grb3V3"
        Me.grb3V3.Size = New System.Drawing.Size(225, 143)
        Me.grb3V3.TabIndex = 145
        Me.grb3V3.TabStop = False
        Me.grb3V3.Visible = False
        '
        'rb12V3
        '
        Me.rb12V3.AutoSize = True
        Me.rb12V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb12V3.Location = New System.Drawing.Point(148, 72)
        Me.rb12V3.Name = "rb12V3"
        Me.rb12V3.Size = New System.Drawing.Size(48, 27)
        Me.rb12V3.TabIndex = 31
        Me.rb12V3.TabStop = True
        Me.rb12V3.Text = "Sí."
        Me.rb12V3.UseVisualStyleBackColor = True
        '
        'chk19V3
        '
        Me.chk19V3.AutoSize = True
        Me.chk19V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk19V3.Location = New System.Drawing.Point(111, 16)
        Me.chk19V3.Name = "chk19V3"
        Me.chk19V3.Size = New System.Drawing.Size(85, 27)
        Me.chk19V3.TabIndex = 35
        Me.chk19V3.Text = "Bolsillo"
        Me.chk19V3.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(48, 86)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 23)
        Me.Label1.TabIndex = 33
        Me.Label1.Text = "¿Bordado?"
        '
        'chk17V3
        '
        Me.chk17V3.AutoSize = True
        Me.chk17V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk17V3.Location = New System.Drawing.Point(17, 16)
        Me.chk17V3.Name = "chk17V3"
        Me.chk17V3.Size = New System.Drawing.Size(81, 27)
        Me.chk17V3.TabIndex = 30
        Me.chk17V3.Text = "Cordón"
        Me.chk17V3.UseVisualStyleBackColor = True
        '
        'chk18V3
        '
        Me.chk18V3.AutoSize = True
        Me.chk18V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk18V3.Location = New System.Drawing.Point(17, 49)
        Me.chk18V3.Name = "chk18V3"
        Me.chk18V3.Size = New System.Drawing.Size(90, 27)
        Me.chk18V3.TabIndex = 34
        Me.chk18V3.Text = "Capucha"
        Me.chk18V3.UseVisualStyleBackColor = True
        '
        'rb13V3
        '
        Me.rb13V3.AutoSize = True
        Me.rb13V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb13V3.Location = New System.Drawing.Point(148, 99)
        Me.rb13V3.Name = "rb13V3"
        Me.rb13V3.Size = New System.Drawing.Size(51, 27)
        Me.rb13V3.TabIndex = 32
        Me.rb13V3.TabStop = True
        Me.rb13V3.Text = "No."
        Me.rb13V3.UseVisualStyleBackColor = True
        '
        'msk11V3
        '
        Me.msk11V3.Enabled = False
        Me.msk11V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk11V3.Location = New System.Drawing.Point(148, 175)
        Me.msk11V3.Mask = "99999"
        Me.msk11V3.Name = "msk11V3"
        Me.msk11V3.Size = New System.Drawing.Size(71, 31)
        Me.msk11V3.TabIndex = 166
        Me.msk11V3.ValidatingType = GetType(Integer)
        '
        'rb10V3
        '
        Me.rb10V3.AutoSize = True
        Me.rb10V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb10V3.Location = New System.Drawing.Point(122, 9)
        Me.rb10V3.Name = "rb10V3"
        Me.rb10V3.Size = New System.Drawing.Size(48, 27)
        Me.rb10V3.TabIndex = 131
        Me.rb10V3.TabStop = True
        Me.rb10V3.Text = "Sí."
        Me.rb10V3.UseVisualStyleBackColor = True
        '
        'msk10V3
        '
        Me.msk10V3.Enabled = False
        Me.msk10V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk10V3.Location = New System.Drawing.Point(148, 135)
        Me.msk10V3.Mask = "99999"
        Me.msk10V3.Name = "msk10V3"
        Me.msk10V3.Size = New System.Drawing.Size(71, 31)
        Me.msk10V3.TabIndex = 165
        Me.msk10V3.ValidatingType = GetType(Integer)
        '
        'rb11V3
        '
        Me.rb11V3.AutoSize = True
        Me.rb11V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb11V3.Location = New System.Drawing.Point(122, 32)
        Me.rb11V3.Name = "rb11V3"
        Me.rb11V3.Size = New System.Drawing.Size(51, 27)
        Me.rb11V3.TabIndex = 132
        Me.rb11V3.TabStop = True
        Me.rb11V3.Text = "No."
        Me.rb11V3.UseVisualStyleBackColor = True
        '
        'msk9V3
        '
        Me.msk9V3.Enabled = False
        Me.msk9V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk9V3.Location = New System.Drawing.Point(148, 98)
        Me.msk9V3.Mask = "99999"
        Me.msk9V3.Name = "msk9V3"
        Me.msk9V3.Size = New System.Drawing.Size(71, 31)
        Me.msk9V3.TabIndex = 164
        Me.msk9V3.ValidatingType = GetType(Integer)
        '
        'lbl11V3
        '
        Me.lbl11V3.AutoSize = True
        Me.lbl11V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl11V3.Location = New System.Drawing.Point(22, 257)
        Me.lbl11V3.Name = "lbl11V3"
        Me.lbl11V3.Size = New System.Drawing.Size(49, 23)
        Me.lbl11V3.TabIndex = 144
        Me.lbl11V3.Text = "Color"
        '
        'lbl10V3
        '
        Me.lbl10V3.AutoSize = True
        Me.lbl10V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl10V3.Location = New System.Drawing.Point(146, 68)
        Me.lbl10V3.Name = "lbl10V3"
        Me.lbl10V3.Size = New System.Drawing.Size(75, 23)
        Me.lbl10V3.TabIndex = 133
        Me.lbl10V3.Text = "Cantidad"
        '
        'cbm3V3
        '
        Me.cbm3V3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm3V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm3V3.FormattingEnabled = True
        Me.cbm3V3.Location = New System.Drawing.Point(98, 254)
        Me.cbm3V3.Name = "cbm3V3"
        Me.cbm3V3.Size = New System.Drawing.Size(121, 31)
        Me.cbm3V3.TabIndex = 139
        '
        'lbl9V3
        '
        Me.lbl9V3.AutoSize = True
        Me.lbl9V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl9V3.Location = New System.Drawing.Point(22, 23)
        Me.lbl9V3.Name = "lbl9V3"
        Me.lbl9V3.Size = New System.Drawing.Size(96, 23)
        Me.lbl9V3.TabIndex = 134
        Me.lbl9V3.Text = "¿Estándar?"
        '
        'chk16V3
        '
        Me.chk16V3.AutoSize = True
        Me.chk16V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk16V3.Location = New System.Drawing.Point(10, 209)
        Me.chk16V3.Name = "chk16V3"
        Me.chk16V3.Size = New System.Drawing.Size(117, 27)
        Me.chk16V3.TabIndex = 138
        Me.chk16V3.Text = "Muy grande"
        Me.chk16V3.UseVisualStyleBackColor = True
        '
        'chk13V3
        '
        Me.chk13V3.AutoSize = True
        Me.chk13V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk13V3.Location = New System.Drawing.Point(11, 107)
        Me.chk13V3.Name = "chk13V3"
        Me.chk13V3.Size = New System.Drawing.Size(67, 27)
        Me.chk13V3.TabIndex = 136
        Me.chk13V3.Text = "Chico"
        Me.chk13V3.UseVisualStyleBackColor = True
        '
        'chk14V3
        '
        Me.chk14V3.AutoSize = True
        Me.chk14V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk14V3.Location = New System.Drawing.Point(10, 141)
        Me.chk14V3.Name = "chk14V3"
        Me.chk14V3.Size = New System.Drawing.Size(89, 27)
        Me.chk14V3.TabIndex = 135
        Me.chk14V3.Text = "Mediano"
        Me.chk14V3.UseVisualStyleBackColor = True
        '
        'chk15V3
        '
        Me.chk15V3.AutoSize = True
        Me.chk15V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk15V3.Location = New System.Drawing.Point(10, 175)
        Me.chk15V3.Name = "chk15V3"
        Me.chk15V3.Size = New System.Drawing.Size(82, 27)
        Me.chk15V3.TabIndex = 137
        Me.chk15V3.Text = "Grande"
        Me.chk15V3.UseVisualStyleBackColor = True
        '
        'chkBuzoEV3
        '
        Me.chkBuzoEV3.AutoSize = True
        Me.chkBuzoEV3.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkBuzoEV3.Location = New System.Drawing.Point(524, 17)
        Me.chkBuzoEV3.Name = "chkBuzoEV3"
        Me.chkBuzoEV3.Size = New System.Drawing.Size(183, 33)
        Me.chkBuzoEV3.TabIndex = 153
        Me.chkBuzoEV3.Text = "Buzo egresados"
        Me.chkBuzoEV3.UseVisualStyleBackColor = True
        '
        'grbCamperV3
        '
        Me.grbCamperV3.Controls.Add(Me.msk16V3)
        Me.grbCamperV3.Controls.Add(Me.grb4V3)
        Me.grbCamperV3.Controls.Add(Me.msk15V3)
        Me.grbCamperV3.Controls.Add(Me.rb14V3)
        Me.grbCamperV3.Controls.Add(Me.msk14V3)
        Me.grbCamperV3.Controls.Add(Me.rb15V3)
        Me.grbCamperV3.Controls.Add(Me.msk13V3)
        Me.grbCamperV3.Controls.Add(Me.lbl15V3)
        Me.grbCamperV3.Controls.Add(Me.lbl14V3)
        Me.grbCamperV3.Controls.Add(Me.cbm4V3)
        Me.grbCamperV3.Controls.Add(Me.lbl13V3)
        Me.grbCamperV3.Controls.Add(Me.chk23V3)
        Me.grbCamperV3.Controls.Add(Me.chk20V3)
        Me.grbCamperV3.Controls.Add(Me.chk21V3)
        Me.grbCamperV3.Controls.Add(Me.chk22V3)
        Me.grbCamperV3.Location = New System.Drawing.Point(780, 52)
        Me.grbCamperV3.Name = "grbCamperV3"
        Me.grbCamperV3.Size = New System.Drawing.Size(246, 495)
        Me.grbCamperV3.TabIndex = 154
        Me.grbCamperV3.TabStop = False
        Me.grbCamperV3.Visible = False
        '
        'msk16V3
        '
        Me.msk16V3.Enabled = False
        Me.msk16V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk16V3.Location = New System.Drawing.Point(148, 212)
        Me.msk16V3.Mask = "99999"
        Me.msk16V3.Name = "msk16V3"
        Me.msk16V3.Size = New System.Drawing.Size(71, 31)
        Me.msk16V3.TabIndex = 171
        Me.msk16V3.ValidatingType = GetType(Integer)
        '
        'grb4V3
        '
        Me.grb4V3.Controls.Add(Me.chk26V3)
        Me.grb4V3.Controls.Add(Me.chk25V3)
        Me.grb4V3.Controls.Add(Me.rb16V3)
        Me.grb4V3.Controls.Add(Me.chk24V3)
        Me.grb4V3.Controls.Add(Me.rb17V3)
        Me.grb4V3.Controls.Add(Me.lbl16V3)
        Me.grb4V3.Location = New System.Drawing.Point(11, 292)
        Me.grb4V3.Name = "grb4V3"
        Me.grb4V3.Size = New System.Drawing.Size(225, 196)
        Me.grb4V3.TabIndex = 145
        Me.grb4V3.TabStop = False
        Me.grb4V3.Visible = False
        '
        'chk26V3
        '
        Me.chk26V3.AutoSize = True
        Me.chk26V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk26V3.Location = New System.Drawing.Point(6, 82)
        Me.chk26V3.Name = "chk26V3"
        Me.chk26V3.Size = New System.Drawing.Size(186, 27)
        Me.chk26V3.TabIndex = 30
        Me.chk26V3.Text = "Cierre para bolsillos"
        Me.chk26V3.UseVisualStyleBackColor = True
        '
        'chk25V3
        '
        Me.chk25V3.AutoSize = True
        Me.chk25V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk25V3.Location = New System.Drawing.Point(6, 49)
        Me.chk25V3.Name = "chk25V3"
        Me.chk25V3.Size = New System.Drawing.Size(90, 27)
        Me.chk25V3.TabIndex = 36
        Me.chk25V3.Text = "Capucha"
        Me.chk25V3.UseVisualStyleBackColor = True
        '
        'rb16V3
        '
        Me.rb16V3.AutoSize = True
        Me.rb16V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb16V3.Location = New System.Drawing.Point(128, 115)
        Me.rb16V3.Name = "rb16V3"
        Me.rb16V3.Size = New System.Drawing.Size(48, 27)
        Me.rb16V3.TabIndex = 22
        Me.rb16V3.TabStop = True
        Me.rb16V3.Text = "Sí."
        Me.rb16V3.UseVisualStyleBackColor = True
        '
        'chk24V3
        '
        Me.chk24V3.AutoSize = True
        Me.chk24V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk24V3.Location = New System.Drawing.Point(6, 16)
        Me.chk24V3.Name = "chk24V3"
        Me.chk24V3.Size = New System.Drawing.Size(175, 27)
        Me.chk24V3.TabIndex = 18
        Me.chk24V3.Text = "Bolsillos interiores"
        Me.chk24V3.UseVisualStyleBackColor = True
        '
        'rb17V3
        '
        Me.rb17V3.AutoSize = True
        Me.rb17V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb17V3.Location = New System.Drawing.Point(125, 148)
        Me.rb17V3.Name = "rb17V3"
        Me.rb17V3.Size = New System.Drawing.Size(51, 27)
        Me.rb17V3.TabIndex = 23
        Me.rb17V3.TabStop = True
        Me.rb17V3.Text = "No."
        Me.rb17V3.UseVisualStyleBackColor = True
        '
        'lbl16V3
        '
        Me.lbl16V3.AutoSize = True
        Me.lbl16V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl16V3.Location = New System.Drawing.Point(28, 129)
        Me.lbl16V3.Name = "lbl16V3"
        Me.lbl16V3.Size = New System.Drawing.Size(90, 23)
        Me.lbl16V3.TabIndex = 24
        Me.lbl16V3.Text = "¿Bordado?"
        '
        'msk15V3
        '
        Me.msk15V3.Enabled = False
        Me.msk15V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk15V3.Location = New System.Drawing.Point(148, 175)
        Me.msk15V3.Mask = "99999"
        Me.msk15V3.Name = "msk15V3"
        Me.msk15V3.Size = New System.Drawing.Size(71, 31)
        Me.msk15V3.TabIndex = 170
        Me.msk15V3.ValidatingType = GetType(Integer)
        '
        'rb14V3
        '
        Me.rb14V3.AutoSize = True
        Me.rb14V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb14V3.Location = New System.Drawing.Point(122, 9)
        Me.rb14V3.Name = "rb14V3"
        Me.rb14V3.Size = New System.Drawing.Size(48, 27)
        Me.rb14V3.TabIndex = 131
        Me.rb14V3.TabStop = True
        Me.rb14V3.Text = "Sí."
        Me.rb14V3.UseVisualStyleBackColor = True
        '
        'msk14V3
        '
        Me.msk14V3.Enabled = False
        Me.msk14V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk14V3.Location = New System.Drawing.Point(148, 135)
        Me.msk14V3.Mask = "99999"
        Me.msk14V3.Name = "msk14V3"
        Me.msk14V3.Size = New System.Drawing.Size(71, 31)
        Me.msk14V3.TabIndex = 169
        Me.msk14V3.ValidatingType = GetType(Integer)
        '
        'rb15V3
        '
        Me.rb15V3.AutoSize = True
        Me.rb15V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.rb15V3.Location = New System.Drawing.Point(122, 32)
        Me.rb15V3.Name = "rb15V3"
        Me.rb15V3.Size = New System.Drawing.Size(51, 27)
        Me.rb15V3.TabIndex = 132
        Me.rb15V3.TabStop = True
        Me.rb15V3.Text = "No."
        Me.rb15V3.UseVisualStyleBackColor = True
        '
        'msk13V3
        '
        Me.msk13V3.Enabled = False
        Me.msk13V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.msk13V3.Location = New System.Drawing.Point(148, 98)
        Me.msk13V3.Mask = "99999"
        Me.msk13V3.Name = "msk13V3"
        Me.msk13V3.Size = New System.Drawing.Size(71, 31)
        Me.msk13V3.TabIndex = 168
        Me.msk13V3.ValidatingType = GetType(Integer)
        '
        'lbl15V3
        '
        Me.lbl15V3.AutoSize = True
        Me.lbl15V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl15V3.Location = New System.Drawing.Point(22, 257)
        Me.lbl15V3.Name = "lbl15V3"
        Me.lbl15V3.Size = New System.Drawing.Size(49, 23)
        Me.lbl15V3.TabIndex = 144
        Me.lbl15V3.Text = "Color"
        '
        'lbl14V3
        '
        Me.lbl14V3.AutoSize = True
        Me.lbl14V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl14V3.Location = New System.Drawing.Point(146, 68)
        Me.lbl14V3.Name = "lbl14V3"
        Me.lbl14V3.Size = New System.Drawing.Size(75, 23)
        Me.lbl14V3.TabIndex = 133
        Me.lbl14V3.Text = "Cantidad"
        '
        'cbm4V3
        '
        Me.cbm4V3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbm4V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.cbm4V3.FormattingEnabled = True
        Me.cbm4V3.Location = New System.Drawing.Point(98, 254)
        Me.cbm4V3.Name = "cbm4V3"
        Me.cbm4V3.Size = New System.Drawing.Size(121, 31)
        Me.cbm4V3.TabIndex = 139
        '
        'lbl13V3
        '
        Me.lbl13V3.AutoSize = True
        Me.lbl13V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl13V3.Location = New System.Drawing.Point(22, 23)
        Me.lbl13V3.Name = "lbl13V3"
        Me.lbl13V3.Size = New System.Drawing.Size(96, 23)
        Me.lbl13V3.TabIndex = 134
        Me.lbl13V3.Text = "¿Estándar?"
        '
        'chk23V3
        '
        Me.chk23V3.AutoSize = True
        Me.chk23V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk23V3.Location = New System.Drawing.Point(10, 209)
        Me.chk23V3.Name = "chk23V3"
        Me.chk23V3.Size = New System.Drawing.Size(117, 27)
        Me.chk23V3.TabIndex = 138
        Me.chk23V3.Text = "Muy grande"
        Me.chk23V3.UseVisualStyleBackColor = True
        '
        'chk20V3
        '
        Me.chk20V3.AutoSize = True
        Me.chk20V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk20V3.Location = New System.Drawing.Point(11, 107)
        Me.chk20V3.Name = "chk20V3"
        Me.chk20V3.Size = New System.Drawing.Size(67, 27)
        Me.chk20V3.TabIndex = 136
        Me.chk20V3.Text = "Chico"
        Me.chk20V3.UseVisualStyleBackColor = True
        '
        'chk21V3
        '
        Me.chk21V3.AutoSize = True
        Me.chk21V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk21V3.Location = New System.Drawing.Point(10, 141)
        Me.chk21V3.Name = "chk21V3"
        Me.chk21V3.Size = New System.Drawing.Size(89, 27)
        Me.chk21V3.TabIndex = 135
        Me.chk21V3.Text = "Mediano"
        Me.chk21V3.UseVisualStyleBackColor = True
        '
        'chk22V3
        '
        Me.chk22V3.AutoSize = True
        Me.chk22V3.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.chk22V3.Location = New System.Drawing.Point(10, 175)
        Me.chk22V3.Name = "chk22V3"
        Me.chk22V3.Size = New System.Drawing.Size(82, 27)
        Me.chk22V3.TabIndex = 137
        Me.chk22V3.Text = "Grande"
        Me.chk22V3.UseVisualStyleBackColor = True
        '
        'chkCamperaV3
        '
        Me.chkCamperaV3.AutoSize = True
        Me.chkCamperaV3.Font = New System.Drawing.Font("ISOCPEUR", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkCamperaV3.Location = New System.Drawing.Point(823, 17)
        Me.chkCamperaV3.Name = "chkCamperaV3"
        Me.chkCamperaV3.Size = New System.Drawing.Size(110, 33)
        Me.chkCamperaV3.TabIndex = 155
        Me.chkCamperaV3.Text = "Campera"
        Me.chkCamperaV3.UseVisualStyleBackColor = True
        '
        'Ventas3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1047, 602)
        Me.Controls.Add(Me.chkCamperaV3)
        Me.Controls.Add(Me.grbCamperV3)
        Me.Controls.Add(Me.chkBuzoEV3)
        Me.Controls.Add(Me.grbBuzoEV3)
        Me.Controls.Add(Me.chkBuzoV3)
        Me.Controls.Add(Me.chkShorV3)
        Me.Controls.Add(Me.btnCancelarV3)
        Me.Controls.Add(Me.btn1V3)
        Me.Controls.Add(Me.grbShV3)
        Me.Controls.Add(Me.grbBuzoV3)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Ventas3"
        Me.Text = "PEDIDO 3"
        Me.grb2V3.ResumeLayout(False)
        Me.grb2V3.PerformLayout()
        Me.grb1V3.ResumeLayout(False)
        Me.grb1V3.PerformLayout()
        Me.grbShV3.ResumeLayout(False)
        Me.grbShV3.PerformLayout()
        Me.grbBuzoV3.ResumeLayout(False)
        Me.grbBuzoV3.PerformLayout()
        Me.grbBuzoEV3.ResumeLayout(False)
        Me.grbBuzoEV3.PerformLayout()
        Me.grb3V3.ResumeLayout(False)
        Me.grb3V3.PerformLayout()
        Me.grbCamperV3.ResumeLayout(False)
        Me.grbCamperV3.PerformLayout()
        Me.grb4V3.ResumeLayout(False)
        Me.grb4V3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lineshape As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents rb4V3 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl7V3 As System.Windows.Forms.Label
    Friend WithEvents cbm2V3 As System.Windows.Forms.ComboBox
    Friend WithEvents chk10V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk5V3 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl4V3 As System.Windows.Forms.Label
    Friend WithEvents chk6V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk7V3 As System.Windows.Forms.CheckBox
    Friend WithEvents rb5V3 As System.Windows.Forms.RadioButton
    Friend WithEvents chk8V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk9V3 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl5V3 As System.Windows.Forms.Label
    Friend WithEvents lbl6V3 As System.Windows.Forms.Label
    Friend WithEvents rb7V3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb6V3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb8V3 As System.Windows.Forms.RadioButton
    Friend WithEvents grb2V3 As System.Windows.Forms.GroupBox
    Friend WithEvents chk11V3 As System.Windows.Forms.CheckBox
    Friend WithEvents rb9V3 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl8V3 As System.Windows.Forms.Label
    Friend WithEvents lbl3V3 As System.Windows.Forms.Label
    Friend WithEvents cbm1V3 As System.Windows.Forms.ComboBox
    Friend WithEvents chk3V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk1V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk2V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk4V3 As System.Windows.Forms.CheckBox
    Friend WithEvents lbl1V3 As System.Windows.Forms.Label
    Friend WithEvents lbl2V3 As System.Windows.Forms.Label
    Friend WithEvents rb2V3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb1V3 As System.Windows.Forms.RadioButton
    Friend WithEvents grb1V3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnCancelarV3 As System.Windows.Forms.Button
    Friend WithEvents btn1V3 As System.Windows.Forms.Button
    Friend WithEvents chkShorV3 As System.Windows.Forms.CheckBox
    Friend WithEvents chkBuzoV3 As System.Windows.Forms.CheckBox
    Friend WithEvents grbShV3 As System.Windows.Forms.GroupBox
    Friend WithEvents grbBuzoV3 As System.Windows.Forms.GroupBox
    Friend WithEvents grbBuzoEV3 As System.Windows.Forms.GroupBox
    Friend WithEvents grb3V3 As System.Windows.Forms.GroupBox
    Friend WithEvents rb10V3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb11V3 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl11V3 As System.Windows.Forms.Label
    Friend WithEvents lbl10V3 As System.Windows.Forms.Label
    Friend WithEvents cbm3V3 As System.Windows.Forms.ComboBox
    Friend WithEvents lbl9V3 As System.Windows.Forms.Label
    Friend WithEvents chk16V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk13V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk14V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk15V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chkBuzoEV3 As System.Windows.Forms.CheckBox
    Friend WithEvents grbCamperV3 As System.Windows.Forms.GroupBox
    Friend WithEvents grb4V3 As System.Windows.Forms.GroupBox
    Friend WithEvents rb16V3 As System.Windows.Forms.RadioButton
    Friend WithEvents chk24V3 As System.Windows.Forms.CheckBox
    Friend WithEvents rb17V3 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl16V3 As System.Windows.Forms.Label
    Friend WithEvents rb14V3 As System.Windows.Forms.RadioButton
    Friend WithEvents rb15V3 As System.Windows.Forms.RadioButton
    Friend WithEvents lbl15V3 As System.Windows.Forms.Label
    Friend WithEvents lbl14V3 As System.Windows.Forms.Label
    Friend WithEvents cbm4V3 As System.Windows.Forms.ComboBox
    Friend WithEvents lbl13V3 As System.Windows.Forms.Label
    Friend WithEvents chk23V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk20V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk21V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk22V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chkCamperaV3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk12V3 As System.Windows.Forms.CheckBox
    Friend WithEvents msk4V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk3V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk2V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk1V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk8V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk7V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk6V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk5V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk12V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents rb12V3 As System.Windows.Forms.RadioButton
    Friend WithEvents chk19V3 As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents chk17V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk18V3 As System.Windows.Forms.CheckBox
    Friend WithEvents rb13V3 As System.Windows.Forms.RadioButton
    Friend WithEvents msk11V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk10V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk9V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk16V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents chk26V3 As System.Windows.Forms.CheckBox
    Friend WithEvents chk25V3 As System.Windows.Forms.CheckBox
    Friend WithEvents msk15V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk14V3 As System.Windows.Forms.MaskedTextBox
    Friend WithEvents msk13V3 As System.Windows.Forms.MaskedTextBox
End Class
