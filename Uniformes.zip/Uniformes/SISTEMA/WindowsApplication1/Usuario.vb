﻿Imports System.Data.Odbc

Public Class Usuario

    Private Sub Usuario_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call conexion()
        sql = "SELECT DISTINCT sector FROM usuario"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            cbm1U.Items.Add(rs(0))
        Loop
    End Sub

    Private Sub btnSalirU_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirU.Click
        End
    End Sub

    Private Sub btn1U_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1U.Click
        Try
            sql = "SELECT COUNT(*) FROM usuario WHERE nombre='" & txt1U.Text & "' AND contraseña='" & txt2U.Text & "' AND sector='" & cbm1U.Text & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) = 0 Then
                    MsgBox("Datos incorrectos.", MsgBoxStyle.Exclamation, "ERROR")
                    txt1U.Text = ""
                    txt2U.Text = ""
                    cbm1U.SelectedIndex = -1
                Else
                    user = txt1U.Text
                    sectoruser = cbm1U.Text
                    Me.Hide()
                    Principal.Show()

                    If sectoruser = "Administracion" Then
                        Principal.btn1P.Enabled = True
                        Principal.btn2P.Enabled = True
                        Principal.btn3P.Enabled = True
                        Principal.btn4P.Enabled = True
                        Principal.btnControlP.Enabled = True
                        Principal.btnEntregaP.Enabled = True
                    End If

                    If sectoruser = "Contaduria" Then
                        Principal.btn1P.Enabled = False
                        Principal.btn2P.Enabled = False
                        Principal.btn3P.Enabled = False
                        Principal.btn4P.Enabled = True
                        Principal.btnControlP.Enabled = True
                        Principal.btnEntregaP.Enabled = False
                    End If

                    If sectoruser = "Otros" Then
                        Principal.btn1P.Enabled = False
                        Principal.btn2P.Enabled = False
                        Principal.btn3P.Enabled = False
                        Principal.btn4P.Enabled = False
                        Principal.btnControlP.Enabled = False
                        Principal.btnEntregaP.Enabled = False
                    End If
                End If
            End If
        Catch ex As Exception
            MsgBox("Usted no se encuentra conectado a la base de datos.", MsgBoxStyle.Exclamation, "ERROR")
            txt1U.Text = ""
            txt2U.Text = ""
            cbm1U.SelectedIndex = -1
        End Try
    End Sub
End Class