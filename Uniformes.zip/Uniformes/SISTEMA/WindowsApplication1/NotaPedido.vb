﻿Imports System.Data.Odbc

Public Class NotaPedido

    Private Sub btnSalirNP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirNP.Click
        Me.Close()
        grdNP.DataSource.clear()
        FacturaCliente.Show()
    End Sub

    Private Sub btn1NP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1NP.Click
        Try
            pf1NP.Print()
            grdNP.DataSource.clear()
        Catch ex As Exception
            MsgBox("La impresión ha sido cancelada.", MsgBoxStyle.Exclamation, "ERROR")
            Me.Show()
        End Try
    End Sub

    Private Sub NotaPedido_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        If bnp <> 1 Then
            ds.Tables.Add("NotaP")
            sql = "SELECT cantidad CANTIDAD, articulo ARTICULO, preciounitario PRECIOUNITARIO, total TOTAL FROM NP"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("NotaP"))
            Me.grdNP.DataSource = ds.Tables("NotaP")
            bnp = 1
        Else
            sql = "SELECT cantidad CANTIDAD, articulo ARTICULO, preciounitario PRECIOUNITARIO, total TOTAL FROM NP"
            adp = New OdbcDataAdapter(sql, cnn)
            adp.Fill(ds.Tables("NotaP"))
            Me.grdNP.DataSource = ds.Tables("NotaP")
        End If
    End Sub
End Class