﻿Imports System.Data.Odbc
Public Class AEDetalles

    Private Sub btn1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1.Click
        Call conexion()
        Dim nombre As String
        Dim b As Integer
        nombre = Trim(msk1.Text)
        sql = "Select Count(*) From Detalle Where nombre='" & nombre & "' And borrado = false"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If msk1.Text = "" Then
            MsgBox("No ingreso datos", MsgBoxStyle.Exclamation, "ERROR")
        Else
            b = 1
            If rs.Read = True Then
                If rs(0) > 0 Then
                    sql = "Update detalle Set borrado=1 Where nombre='" & nombre & "'"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    MsgBox("¡El detalle ha sido eliminado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
                Else
                    sql = "Insert into detalle Values ('', '" & nombre & "', null, null, false)"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    MsgBox("¡El detalle ha sido cargado exitosamente!.", MsgBoxStyle.Exclamation, "EXITO")
                End If
            End If
        End If

        If b = 1 Then
            msk1.Clear()
            b = 0
            Me.Hide()
            Control.Show()
        End If
    End Sub

    Private Sub btn2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2.Click
        Me.Hide()
        Control.Show()
        msk1.Clear()
    End Sub

    Private Sub msk1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk1.MaskInputRejected

    End Sub
End Class