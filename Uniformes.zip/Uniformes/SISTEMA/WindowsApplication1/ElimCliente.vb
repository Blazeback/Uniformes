﻿Imports System.Data.Odbc

Public Class ElimCliente

    Private Sub btnCancelarEC_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancelarEC.Click
        Me.Hide()
        msk1VElC.Text = ""
        msk2VElC.Text = ""
        msk3VElC.Text = ""
        Control.Show()
    End Sub

    Private Sub btnEliminarCli_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEliminarCli.Click
        sql = "SELECT COUNT(*) FROM cliente WHERE nombre='" & msk1VElC.Text & "' AND apellido='" & msk2VElC.Text & "' AND DNI='" & msk3VElC.Text & "'"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) > 0 Then
                sql = "UPDATE cliente SET borrado=1 WHERE DNI='" & msk3VElC.Text & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                MsgBox("¡El cliente ha sido eliminado exitosamente!", MsgBoxStyle.Exclamation, "EXITO")
                msk1VElC.Text = ""
                msk2VElC.Text = ""
                msk3VElC.Text = ""
                Me.Hide()
                Control.Show()
            Else
                MsgBox("Los datos ingresados no existen.", MsgBoxStyle.Exclamation, "ERROR")
                msk1VElC.Text = ""
                msk2VElC.Text = ""
                msk3VElC.Text = ""
            End If
        End If
    End Sub
End Class