﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class LlegadaBordados
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnLB = New System.Windows.Forms.Button()
        Me.registrarLB = New System.Windows.Forms.Button()
        Me.lbl1V = New System.Windows.Forms.Label()
        Me.grdLB = New System.Windows.Forms.DataGridView()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.mskBordadoLB = New System.Windows.Forms.MaskedTextBox()
        Me.fechaLB = New System.Windows.Forms.Label()
        CType(Me.grdLB, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnLB
        '
        Me.btnLB.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.btnLB.Location = New System.Drawing.Point(115, 367)
        Me.btnLB.Name = "btnLB"
        Me.btnLB.Size = New System.Drawing.Size(155, 39)
        Me.btnLB.TabIndex = 86
        Me.btnLB.Text = "Cancelar"
        Me.btnLB.UseVisualStyleBackColor = True
        '
        'registrarLB
        '
        Me.registrarLB.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.registrarLB.Location = New System.Drawing.Point(115, 297)
        Me.registrarLB.Name = "registrarLB"
        Me.registrarLB.Size = New System.Drawing.Size(155, 64)
        Me.registrarLB.TabIndex = 85
        Me.registrarLB.Text = "Registrar llegada"
        Me.registrarLB.UseVisualStyleBackColor = True
        '
        'lbl1V
        '
        Me.lbl1V.AutoSize = True
        Me.lbl1V.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl1V.Location = New System.Drawing.Point(142, 9)
        Me.lbl1V.Name = "lbl1V"
        Me.lbl1V.Size = New System.Drawing.Size(100, 27)
        Me.lbl1V.TabIndex = 84
        Me.lbl1V.Text = "REGISTRO"
        '
        'grdLB
        '
        Me.grdLB.AllowUserToAddRows = False
        Me.grdLB.AllowUserToDeleteRows = False
        Me.grdLB.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdLB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdLB.Location = New System.Drawing.Point(18, 41)
        Me.grdLB.Name = "grdLB"
        Me.grdLB.ReadOnly = True
        Me.grdLB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdLB.Size = New System.Drawing.Size(369, 216)
        Me.grdLB.TabIndex = 83
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(11, 5)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(383, 420)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(404, 432)
        Me.ShapeContainer1.TabIndex = 87
        Me.ShapeContainer1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(24, 260)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(179, 24)
        Me.Label1.TabIndex = 89
        Me.Label1.Text = "Nombre del proveedor"
        '
        'mskBordadoLB
        '
        Me.mskBordadoLB.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.mskBordadoLB.Location = New System.Drawing.Point(209, 257)
        Me.mskBordadoLB.Mask = "LLLLLLLLLLLLLLL"
        Me.mskBordadoLB.Name = "mskBordadoLB"
        Me.mskBordadoLB.Size = New System.Drawing.Size(171, 31)
        Me.mskBordadoLB.TabIndex = 88
        '
        'fechaLB
        '
        Me.fechaLB.AutoSize = True
        Me.fechaLB.Font = New System.Drawing.Font("ISOCPEUR", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.fechaLB.Location = New System.Drawing.Point(23, 11)
        Me.fechaLB.Name = "fechaLB"
        Me.fechaLB.Size = New System.Drawing.Size(21, 27)
        Me.fechaLB.TabIndex = 90
        Me.fechaLB.Text = "-"
        '
        'LlegadaBordados
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(404, 432)
        Me.Controls.Add(Me.fechaLB)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.mskBordadoLB)
        Me.Controls.Add(Me.btnLB)
        Me.Controls.Add(Me.registrarLB)
        Me.Controls.Add(Me.lbl1V)
        Me.Controls.Add(Me.grdLB)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "LlegadaBordados"
        Me.Text = "LLEGADA DE BORDADOS"
        CType(Me.grdLB, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnLB As System.Windows.Forms.Button
    Friend WithEvents registrarLB As System.Windows.Forms.Button
    Friend WithEvents lbl1V As System.Windows.Forms.Label
    Friend WithEvents grdLB As System.Windows.Forms.DataGridView
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents mskBordadoLB As System.Windows.Forms.MaskedTextBox
    Friend WithEvents fechaLB As System.Windows.Forms.Label
End Class
