﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cuotass
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grdCuotas = New System.Windows.Forms.DataGridView()
        Me.RectangleShape1 = New Microsoft.VisualBasic.PowerPacks.RectangleShape()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.btnCancelarCuotas = New System.Windows.Forms.Button()
        Me.btnPagoCuota = New System.Windows.Forms.Button()
        Me.mskCuota = New System.Windows.Forms.MaskedTextBox()
        Me.lbl1V = New System.Windows.Forms.Label()
        Me.lblClienteCuotas = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.grdCuotas, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'grdCuotas
        '
        Me.grdCuotas.AllowUserToAddRows = False
        Me.grdCuotas.AllowUserToDeleteRows = False
        Me.grdCuotas.BackgroundColor = System.Drawing.SystemColors.Control
        Me.grdCuotas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.grdCuotas.Location = New System.Drawing.Point(12, 48)
        Me.grdCuotas.Name = "grdCuotas"
        Me.grdCuotas.ReadOnly = True
        Me.grdCuotas.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.grdCuotas.Size = New System.Drawing.Size(353, 133)
        Me.grdCuotas.TabIndex = 74
        '
        'RectangleShape1
        '
        Me.RectangleShape1.BorderWidth = 2
        Me.RectangleShape1.Location = New System.Drawing.Point(6, 8)
        Me.RectangleShape1.Name = "RectangleShape1"
        Me.RectangleShape1.Size = New System.Drawing.Size(370, 312)
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.RectangleShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(384, 328)
        Me.ShapeContainer1.TabIndex = 75
        Me.ShapeContainer1.TabStop = False
        '
        'btnCancelarCuotas
        '
        Me.btnCancelarCuotas.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCancelarCuotas.Location = New System.Drawing.Point(190, 249)
        Me.btnCancelarCuotas.Name = "btnCancelarCuotas"
        Me.btnCancelarCuotas.Size = New System.Drawing.Size(161, 63)
        Me.btnCancelarCuotas.TabIndex = 77
        Me.btnCancelarCuotas.Text = "Cancelar"
        Me.btnCancelarCuotas.UseVisualStyleBackColor = True
        '
        'btnPagoCuota
        '
        Me.btnPagoCuota.Font = New System.Drawing.Font("ISOCPEUR", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPagoCuota.Location = New System.Drawing.Point(23, 249)
        Me.btnPagoCuota.Name = "btnPagoCuota"
        Me.btnPagoCuota.Size = New System.Drawing.Size(161, 63)
        Me.btnPagoCuota.TabIndex = 76
        Me.btnPagoCuota.Text = "Registrar pago de cuota"
        Me.btnPagoCuota.UseVisualStyleBackColor = True
        '
        'mskCuota
        '
        Me.mskCuota.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.mskCuota.Location = New System.Drawing.Point(144, 212)
        Me.mskCuota.Mask = "99999"
        Me.mskCuota.Name = "mskCuota"
        Me.mskCuota.Size = New System.Drawing.Size(63, 31)
        Me.mskCuota.TabIndex = 79
        Me.mskCuota.ValidatingType = GetType(Integer)
        '
        'lbl1V
        '
        Me.lbl1V.AutoSize = True
        Me.lbl1V.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lbl1V.Location = New System.Drawing.Point(51, 21)
        Me.lbl1V.Name = "lbl1V"
        Me.lbl1V.Size = New System.Drawing.Size(62, 23)
        Me.lbl1V.TabIndex = 78
        Me.lbl1V.Text = "Cliente"
        '
        'lblClienteCuotas
        '
        Me.lblClienteCuotas.AutoSize = True
        Me.lblClienteCuotas.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.lblClienteCuotas.Location = New System.Drawing.Point(125, 21)
        Me.lblClienteCuotas.Name = "lblClienteCuotas"
        Me.lblClienteCuotas.Size = New System.Drawing.Size(19, 23)
        Me.lblClienteCuotas.TabIndex = 80
        Me.lblClienteCuotas.Text = "-"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("ISOCPEUR", 14.25!)
        Me.Label1.Location = New System.Drawing.Point(110, 185)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(132, 23)
        Me.Label1.TabIndex = 81
        Me.Label1.Text = "Código de cuota"
        '
        'Cuotass
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 328)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblClienteCuotas)
        Me.Controls.Add(Me.mskCuota)
        Me.Controls.Add(Me.lbl1V)
        Me.Controls.Add(Me.btnCancelarCuotas)
        Me.Controls.Add(Me.btnPagoCuota)
        Me.Controls.Add(Me.grdCuotas)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Name = "Cuotass"
        Me.Text = "CUOTAS"
        CType(Me.grdCuotas, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents grdCuotas As System.Windows.Forms.DataGridView
    Friend WithEvents RectangleShape1 As Microsoft.VisualBasic.PowerPacks.RectangleShape
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents btnCancelarCuotas As System.Windows.Forms.Button
    Friend WithEvents btnPagoCuota As System.Windows.Forms.Button
    Friend WithEvents mskCuota As System.Windows.Forms.MaskedTextBox
    Friend WithEvents lbl1V As System.Windows.Forms.Label
    Friend WithEvents lblClienteCuotas As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
