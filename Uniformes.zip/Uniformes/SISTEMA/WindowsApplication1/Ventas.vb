﻿Imports System.Data.Odbc
Imports System.Globalization

Public Class Ventas
    Dim b As Integer
    Dim b2 As Integer
    Dim b3 As Integer
    Dim banderadni2 As Integer

    Private Sub btn2V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2V.Click
        b = 0
        b2 = 0
        msk1V1.Text = ""
        msk2V1.Text = ""
        msk3V1.Text = ""
        msk4V1.Text = ""
        msk5V1.Text = ""
        cbm3V.Text = ""
        cbm4V.Text = ""
        lbl9V1.Text = ""
        cbm1V.SelectedIndex = -1
        cbm2V.SelectedIndex = -1
        panel1V.Visible = False
        rb1V.Checked = False
        rb2V.Checked = False
        rb3V.Checked = False
        Me.Hide()
        Principal.Show()
    End Sub

    Private Sub cbm2V_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbm2V.SelectedIndexChanged
        If cbm2V.Text = "Cuotas" Then
            panel1V.Visible = True
        End If
        If cbm2V.Text = "Contado" Then
            panel1V.Visible = False
            rb1V.Checked = False
            rb2V.Checked = False
            rb3V.Checked = False
        End If
    End Sub

    Private Sub btn1V_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1V.Click
        b = 1
        b2 = 1
        If msk1V1.Text = "" Or msk2V1.Text = "" Or msk3V1.Text = "" Or msk4V1.Text = "" Or msk5V1.Text = "" Or cbm3V.Text = "" Or cbm4V.Text = "" Or cbm1V.Text = "" Or cbm2V.Text = "" Then
            If banderadni = 1 Then
                MsgBox("Usted ha dejado campos sin completar.", MsgBoxStyle.Exclamation, "ERROR")
            Else
                b2 = 0
            End If
        Else
            b2 = 0
        End If

        If b2 = 0 Then
            If cbm1V.Text = "" Or cbm2V.Text = "" Then
                MsgBox("Usted ha dejado campos sin completar.", MsgBoxStyle.Exclamation, "ERROR")
            Else
                If cbm2V.Text = "Cuotas" And rb1V.Checked = False And rb2V.Checked = False And rb3V.Checked = False Then
                    MsgBox("Usted no ha seleccionado ninguna cuota.", MsgBoxStyle.Exclamation, "ERROR")
                Else
                    b = 0
                End If
            End If
        End If

        If b = 0 Then
            b = 0
            b2 = 0
            If banderadni = 1 Then

            End If
            If rb1V.Checked = True Then
                cuotas = 3
            Else
                If rb2V.Checked = True Then
                    cuotas = 6
                    If rb3V.Checked = True Then
                        cuotas = 12
                    Else
                        cuotas = 0
                    End If
                End If
            End If
            formapago = cbm1V.Text
            Me.Hide()
            Ventas2.Show()
            b = 0
            b2 = 0
        End If
    End Sub

    Private Sub msk1V1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk1V1.MaskInputRejected
        msk1V1.BeepOnError = True
    End Sub

    Private Sub msk2V1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk2V1.MaskInputRejected
        msk2V1.BeepOnError = True
    End Sub

    Private Sub msk3V1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk3V1.MaskInputRejected
        msk3V1.BeepOnError = True
    End Sub

    Private Sub msk4V1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk4V1.MaskInputRejected
        msk4V1.BeepOnError = True
    End Sub

    Private Sub msk5V1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk5V1.MaskInputRejected
        msk5V1.BeepOnError = True
    End Sub

    Private Sub MaskedTextBox1_MaskInputRejected(ByVal sender As System.Object, ByVal e As System.Windows.Forms.MaskInputRejectedEventArgs) Handles msk9V1.MaskInputRejected
        msk9V1.BeepOnError = True
    End Sub

    Private Sub btnValidarV1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnValidarV1.Click
        grb2V1.Visible = False
        grb3V1.Visible = False
        lblDNIV1.Visible = False
        msk2V1.Text = ""
        msk3V1.Text = ""
        msk4V1.Text = ""
        msk5V1.Text = ""
        cbm3V.Text = ""
        cbm4V.Text = ""
        lbl9V1.Text = ""
        cbm1V.SelectedIndex = -1
        cbm2V.SelectedIndex = -1
        panel1V.Visible = False
        rb1V.Checked = False
        rb2V.Checked = False
        rb3V.Checked = False
        If msk1V1.Text <> "" Then
            sql = "SELECT COUNT(*) FROM cliente WHERE DNI='" & CInt(Trim(msk1V1.Text)) & "'"
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                If rs(0) = 0 Then
                    sql = "Select max(codCliente+1) from Cliente"
                    banderadni = 1
                    grb2V1.Visible = True
                    grb3V1.Visible = True
                    msk2V1.Text = ""
                    msk3V1.Text = ""
                    msk4V1.Text = ""
                    msk5V1.Text = ""
                    cbm3V.Text = ""
                    cbm4V.Text = ""
                    lbl9V1.Text = ""
                    cbm1V.SelectedIndex = -1
                    cbm2V.SelectedIndex = -1
                    panel1V.Visible = False
                    rb1V.Checked = False
                    rb2V.Checked = False
                    rb3V.Checked = False
                Else
                    sql = "SELECT* FROM LocalidadGBA"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    Do While rs.Read = True
                        cbm4V.Items.Add(rs(0))
                    Loop

                    sql = "SELECT* FROM LocalidadCABA"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    Do While rs.Read = True
                        cbm4V.Items.Add(rs(0))
                    Loop

                    sql = "Select codCliente from cliente where DNI='" & CInt(Trim(msk1V1.Text)) & "'"
                    banderadni = 0
                    lblDNIV1.Visible = True
                End If
            End If
            comando = New OdbcCommand(sql, cnn)
            comando.CommandType = CommandType.Text
            rs = comando.ExecuteReader
            comando.Dispose()
            If rs.Read = True Then
                codigoxd = rs(0)
            End If

            If banderadni = 0 Then
                sql = "SELECT* FROM cliente WHERE DNI='" & CInt(Trim(msk1V1.Text)) & "'"
                comando = New OdbcCommand(sql, cnn)
                comando.CommandType = CommandType.Text
                rs = comando.ExecuteReader
                comando.Dispose()
                If rs.Read = True Then
                    b3 = 1
                    msk2V1.Text = rs(1)
                    msk3V1.Text = rs(2)
                    msk4V1.Text = rs(3)
                    msk5V1.Text = rs(5)
                    cbm3V.Text = rs(7)
                    cbm4V.Text = rs(6)
                    msk9V1.Text = rs(8)
                    grb3V1.Visible = True
                    grb2V1.Visible = True
                    msk2V1.Enabled = False
                    msk3V1.Enabled = False
                    msk4V1.Enabled = False
                    msk5V1.Enabled = False
                    cbm3V.Enabled = False
                    cbm4V.Enabled = False
                    msk9V1.Enabled = False
                End If
            Else
                b3 = 0
                msk2V1.Text = ""
                msk3V1.Text = ""
                msk4V1.Text = ""
                msk5V1.Text = ""
                cbm3V.Text = ""
                cbm4V.Text = ""
                msk9V1.Text = ""
                cbm3V.SelectedIndex = -1
                cbm4V.SelectedIndex = -1
                grb3V1.Visible = True
                grb2V1.Visible = True
                msk2V1.Enabled = True
                msk3V1.Enabled = True
                msk4V1.Enabled = True
                msk5V1.Enabled = True
                cbm3V.Enabled = True
                cbm4V.Enabled = False
                msk9V1.Enabled = True
            End If
        Else
            MsgBox("Por favor, ingrese un DNI.")
        End If
    End Sub

    Private Sub Ventas_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "SELECT* FROM Provincia"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            cbm3V.Items.Add(rs(0))
        Loop
    End Sub

    Private Sub cbm3V_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cbm3V.SelectedIndexChanged
        If cbm3V.Text = "" Then
            cbm4V.Enabled = False
        Else
            If b3 = 0 Then
                cbm4V.Enabled = True
                If cbm3V.Text = "Gran Buenos Aires" Then
                    cbm4V.SelectedIndex = -1
                    sql = "SELECT* FROM LocalidadGBA"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    Do While rs.Read = True
                        cbm4V.Items.Add(rs(0))
                    Loop
                Else
                    cbm4V.SelectedIndex = -1
                    sql = "SELECT* FROM LocalidadCABA"
                    comando = New OdbcCommand(sql, cnn)
                    comando.CommandType = CommandType.Text
                    rs = comando.ExecuteReader
                    comando.Dispose()
                    Do While rs.Read = True
                        cbm4V.Items.Add(rs(0))
                    Loop
                End If
            End If
        End If
    End Sub

    Private Sub msk1V1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles msk1V1.TextChanged
        grb2V1.Visible = False
        grb3V1.Visible = False
        lblDNIV1.Visible = False
        msk2V1.Text = ""
        msk3V1.Text = ""
        msk4V1.Text = ""
        msk5V1.Text = ""
        cbm3V.Text = ""
        cbm4V.Text = ""
        lbl9V1.Text = ""
        cbm1V.SelectedIndex = -1
        cbm2V.SelectedIndex = -1
        panel1V.Visible = False
        rb1V.Checked = False
        rb2V.Checked = False
        rb3V.Checked = False
    End Sub
End Class