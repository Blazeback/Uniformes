﻿Imports System.Data.Odbc

Public Class Principal
    Private Sub btnVolverP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnVolverP.Click
        Me.Close()
        Usuario.txt1U.Text = ""
        Usuario.txt2U.Text = ""
        Usuario.cbm1U.SelectedIndex = -1
        Usuario.Show()
    End Sub

    Private Sub btn1P_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1P.Click
        Ventas.grb2V1.Visible = False
        Ventas.grb3V1.Visible = False
        Ventas.grb3V1.Visible = False
        Ventas.lblDNIV1.Visible = False
        Me.Hide()
        Ventas.Show()
    End Sub

    Private Sub btnControlP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnControlP.Click
        If sectoruser = "Administracion" Then
            Control.btn1C.Enabled = True
            Control.btn2C.Enabled = True
            Control.btn3C.Enabled = True
            Control.btn4C.Enabled = True
            Control.btn5C.Enabled = True
            Control.btn6C.Enabled = True
            Control.btn7C.Enabled = True
            Control.btn8C.Enabled = True
            Control.btn9C.Enabled = True
            Control.btn10C.Enabled = True
            Control.btn11C.Enabled = True
            Control.btn12C.Enabled = True
            Control.btn13C.Enabled = True
            Control.btn14C.Enabled = True
            Control.btn15C.Enabled = True
            Control.btn16C.Enabled = True
            Control.btn17C.Enabled = True
            Control.btn18C.Enabled = True
            Control.btn19C.Enabled = True
        End If

        If sectoruser = "Contaduria" Then
            Control.btn1C.Enabled = True
            Control.btn2C.Enabled = False
            Control.btn3C.Visible = False
            Control.btn4C.Enabled = True
            Control.btn5C.Enabled = True
            Control.btn6C.Enabled = True
            Control.btn7C.Enabled = True
            Control.btn8C.Enabled = True
            Control.btn9C.Enabled = True
            Control.btn10C.Enabled = True
            Control.btn11C.Enabled = False
            Control.btn12C.Enabled = False
            Control.btn13C.Enabled = False
            Control.btn14C.Enabled = False
            Control.btn15C.Enabled = False
            Control.btn16C.Enabled = False
            Control.btn17C.Enabled = False
            Control.btn18C.Enabled = False
            Control.btn19C.Enabled = False
        End If

        If sectoruser = "Otros" Then
            Control.btn1C.Enabled = False
            Control.btn2C.Enabled = False
            Control.btn3C.Enabled = False
            Control.btn4C.Enabled = False
            Control.btn5C.Enabled = False
            Control.btn6C.Enabled = False
            Control.btn7C.Enabled = False
            Control.btn8C.Enabled = False
            Control.btn9C.Enabled = False
            Control.btn10C.Enabled = False
            Control.btn11C.Enabled = False
            Control.btn12C.Enabled = False
            Control.btn13C.Enabled = False
            Control.btn14C.Enabled = False
            Control.btn15C.Enabled = False
            Control.btn16C.Enabled = False
            Control.btn17C.Enabled = False
            Control.btn18C.Enabled = False
            Control.btn19C.Enabled = False
        End If
        Me.Hide()
        Control.Show()
    End Sub

    Private Sub btnSalirP_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSalirP.Click
        End
    End Sub

    Private Sub Principal_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        sql = "SELECT curdate()"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            lst2P.Items.Add("'" & rs(0) & "'")
        End If

        sql = "SELECT COUNT(*) FROM CIERRECAJA WHERE fecha=(SELECT curdate())"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        If rs.Read = True Then
            If rs(0) = 0 Then
                lst1P.Items.Add("Hoy no se realizó el cierre de caja.")
            End If
        End If

        sql = "SELECT CONCAT(nombre, ' ', apellido,' con DNI ', dni) FROM cliente WHERE codCliente IN (SELECT codCliente FROM factura WHERE numNotaPedido IN (SELECT numNotaPedido FROM notapedido WHERE finalizado=0))"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            lst1P.Items.Add("Pedido del cliente " & rs(0) & " activo.")
        Loop

        sql = "SELECT CONCAT(CC.nombre, ' ', CC.apellido,' cuota numero ', C.numCuota, ' sin pagar.') FROM cuotas C, factura F, cliente CC WHERE CC.codCliente=F.codCliente AND F.numFactura=C.numFactura AND codCuota NOT IN (SELECT codCuota FROM reciboC)"
        comando = New OdbcCommand(sql, cnn)
        comando.CommandType = CommandType.Text
        rs = comando.ExecuteReader
        comando.Dispose()
        Do While rs.Read = True
            lst1P.Items.Add("DEUDA: " & rs(0) & "")
        Loop

        If sectoruser = "Administracion" Then
            btn1P.Enabled = True
            btn2P.Enabled = True
            btn3P.Enabled = True
            btn4P.Enabled = True
            btnControlP.Enabled = True
        End If

        If sectoruser = "Contaduria" Then
            btn1P.Enabled = False
            btn2P.Enabled = False
            btn3P.Enabled = False
            btn4P.Enabled = True
            btnControlP.Enabled = True
        End If

        If sectoruser = "Otros" Then
            btn1P.Enabled = False
            btn2P.Enabled = False
            btn3P.Enabled = False
            btn4P.Enabled = False
            btnControlP.Enabled = False
        End If
    End Sub

    Private Sub btn3P_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn3P.Click
        Me.Hide()
        EBordados.Show()
    End Sub

    Private Sub btn2P_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2P.Click
        Me.Hide()
        MPrima1.Show()
    End Sub

    Private Sub btn4P_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn4P.Click
        Me.Hide()
        CierreCaja.Show()
    End Sub

    Private Sub lst2P_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst2P.SelectedIndexChanged

    End Sub

    Private Sub lst1P_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lst1P.SelectedIndexChanged

    End Sub

    Private Sub re_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles re.Click

    End Sub

    Private Sub btnEntregaP_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEntregaP.Click
        Me.Hide()
        ENTREGA.Show()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Close()
        ACTUALIZANDO.Show()
    End Sub
End Class
