﻿Public Class AgregElimUser

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblVolverAgregElimUser.Click
        Control.btn1C.Enabled = True
        Control.btn2C.Enabled = True
        If sectoruser = "Contaduria" Or sectoruser = "Otros" Then
            Control.btn3C.Enabled = False
        Else
            Control.btn3C.Enabled = True
        End If
        Control.btn4C.Enabled = True
        Control.btn5C.Enabled = True
        Control.btn6C.Enabled = True
        Control.btn7C.Enabled = True
        Control.btn8C.Enabled = True
        Control.btn3C.Visible = False
        Control.btn11C.Visible = False
        Control.btn12C.Visible = False
        Control.btn13C.Visible = False
        Control.btn14C.Visible = False
        Control.btn15C.Visible = False
        Control.btn16C.Visible = False
        Me.Hide()
        Control.Show()
    End Sub

    Private Sub btnAgregarUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn1AEUser.Click
        Me.Hide()
        AgregarUser.Show()
    End Sub

    Private Sub btn2AEUser_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btn2AEUser.Click
        Control.btn3C.Visible = False
        Me.Hide()
        EliminarUser.Show()
    End Sub
End Class