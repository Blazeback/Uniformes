Create Database uniformes;
Use uniformes;

Create Table cliente(
codCliente Int auto_increment,
nombre Varchar(50),
apellido Varchar(50),
telefono Varchar(15) ,
DNI int(8),
direccion Varchar(70),
localidad Varchar(50),
provincia Varchar(50),
codPostal Int,
borrado boolean,
Constraint PK_cliente Primary Key (codCliente)
)engine=innodb;

Insert Into cliente Values
('', "Martin", "Perez", "4567-7899", 42514190, "Av. Rivadavia 8000", "Monte Castro", "CABA", 1408, false),
('', "Rodolfo", "Berger", "1514010801", 38555210, "Av. Rivadavia 8000", "Monte Castro", "CABA", 1408, false),
('', "Hans", "Juarez", "1514880802", 35514190, "Av. Rivadavia 8000", "Monte Castro", "CABA", 1408, false),
('', "Rodolfo", "Walsh", "1514870803", 30514190, "Av. Rivadavia 8000", "Monte Castro", "CABA", 1408, false),
('', "Maria Elena", "Walsh", "1510980804", 25514190, "Av. Rivadavia 8000", "Monte Castro", "CABA", 1408, false),
('', "Julio", "Verne", "1514380151", 10514190, "Av. Rivadavia 8000", "Monte Castro", "CABA", 1408, false);

Create Table notaPedido(
numNotaPedido Int auto_increment,
fechaInicio Date,
fechaEntrega Date,
finalizado boolean,
Constraint PK_pedido Primary Key (numNotaPedido) 
)engine=innodb;

Insert Into notaPedido Values
('', "2017-10-17", curdate(), true),
('', "2017-10-17", curdate(), false),
('', "2017-09-17", curdate(), false);

Create Table factura(
numFactura Int auto_increment,
codCliente Int,
numNotaPedido Int,
fecha Date,
importe Int,
formaPago Varchar(10),
seña Boolean,
cantSeña Int,
Constraint PK_factura Primary Key (numFactura),
Constraint FK_cliente Foreign Key (codCliente) References cliente(codCliente),
Constraint FK_pedido Foreign Key (numNotaPedido) References notaPedido(numNotaPedido)
)engine=innodb;

Insert Into factura Values
('', 1, 1, "2017-10-17", 15000, "tarjeta", true, 3000),
('', 2, 2, "2017-10-17", 15000, "tarjeta", true, 3000),
('', 3, 3, "2017-10-17", 15000, "tarjeta", true, 3000);

Create Table cuotas(
codCuota Int auto_increment,
numCuota Int,
numFactura Int,
fVencimiento Date,
fPago Date,
monto Int,
Constraint PK_cuotas Primary Key (codCuota),
Constraint FK_factura Foreign Key (numFactura) References factura(numfactura)
)engine=innodb;

Insert Into cuotas Values
('', 1, 1, "2017-11-17", null, 2200),
('', 2, 1, "2017-12-17", null, 2200),
('', 3, 1, "2018-01-17", null, 2200),
('', 4, 1, "2018-02-17", null, 2200),
('', 5, 1, "2018-03-17", null, 2200),
('', 6, 1, "2018-04-17", null, 2200);

Create Table ReciboC(
codRecibo Int auto_increment,
codCuota Int,
fEmision Date,
monto Int,
recibido Boolean,
Constraint PK_recibo Primary Key (codRecibo),
Constraint FK_cuotas Foreign Key (codCuota) References cuotas(codCuota)
)engine=innodb;

Create Table interesC(
codInteres Int auto_increment,
cantDias Int,
porcentaje Float,
Constraint PK_interes Primary Key (codInteres)
)engine=innodb;

Create Table ropa(
codRopa Int auto_increment,
nombre Varchar(50),
borrado boolean,
Constraint PK_ropa Primary Key (codRopa)
)engine=innodb;

Insert Into ropa Values 
('', "Camisa manga corta", false),
('', "Camisa manga larga", false),
('', "Remera manga corta", false),
('', "Remera manga larga", false),
('', "Pantalon", false),
('', "Pulover", false),
('', "Buzo", false),
('', "Short", false),
('', "Campera", false);

Create Table talles(
codTalle Int auto_increment,
talle Varchar(5),
tiempo Time,
borrado boolean,
Constraint PK_talles Primary Key (codTalle) 
)engine=innodb;

Insert Into talles Values
('', "S", "01:00:00", false),
('', "M", "01:00:00", false),
('', "L", "01:00:00", false),
('', "XL", "01:00:00", false);

Create Table detalle(
codDetalle Int auto_increment,
nombre Varchar(50),
precio Int,
tiempo time,
borrado boolean,
Constraint PK_detalle Primary Key (codDetalle)
)engine=innodb;

Insert Into detalle Values
('', "Bolsillo", 10, "00:30:00", false),
('', "Escudo", 20, null, false),
('', "Cuello en V", 10, "00:30:00", false),
('', "Elastico ajustable", 20, "00:30:00", false),
('', "Capucha", 10, "00:30:00", false),
('', "Cordon/Tirante Buzo", 20, "00:30:00", false),
('', "Bolsillo canguro", 10, "00:30:00", false),
('', "Bolsillo con cierre", 20, "00:30:00", false),
('', "Bolsillo interior", 10, "00:30:00", false),
('', "Chomba", 10, "00:30:00", false);

Create Table colores(
idColor Int auto_increment,
nombre Varchar(10),
borrado boolean,
Constraint PK_color Primary Key (idcolor)
)engine=innodb;

Insert Into colores Values
('', "Amarillo", false),
('', "Azul", false),
('', "Blanco", false),
('', "Marron", false),
('', "Negro", false),
('', "Rojo", false),
('', "Rosa", false),
('', "Verde", false);

Create Table ropaTalles(
codRT Int auto_increment,
codRopa Int,
codTalle Int,
precio Int,
puntoPedido Int,
borrado boolean,
Constraint PK_RT Primary Key (codRT),
Constraint FK_ropaT Foreign Key (codRopa) References Ropa(codRopa),
Constraint FK_Talle Foreign Key (CodTalle) References talles(codTalle)
)engine=innodb;

Insert Into ropaTalles Values
('', 1, 1, 50, 15, false),
('', 1, 2, 60, 20, false),
('', 1, 3, 70, 15, false),
('', 1, 4, 80, 10, false),
('', 2, 1, 50, 15, false),
('', 2, 2, 60, 20, false),
('', 2, 3, 70, 15, false),
('', 2, 4, 80, 10, false),
('', 3, 1, 50, 15, false),
('', 3, 2, 60, 20, false),
('', 3, 3, 70, 15, false),
('', 3, 4, 80, 10, false),
('', 4, 1, 50, 15, false),
('', 4, 2, 60, 20, false),
('', 4, 3, 70, 15, false),
('', 4, 4, 80, 10, false),
('', 5, 1, 50, 15, false),
('', 5, 2, 60, 20, false),
('', 5, 3, 70, 15, false),
('', 5, 4, 80, 10, false),
('', 6, 1, 50, 15, false),
('', 6, 2, 60, 20, false),
('', 6, 3, 70, 15, false),
('', 6, 4, 80, 10, false),
('', 7, 1, 50, 15, false),
('', 7, 2, 60, 20, false),
('', 7, 3, 70, 15, false),
('', 7, 4, 80, 10, false),
('', 8, 1, 50, 15, false),
('', 8, 2, 60, 20, false),
('', 8, 3, 70, 15, false),
('', 8, 4, 80, 10, false),
('', 9, 1, 50, 15, false),
('', 9, 2, 60, 20, false),
('', 9, 3, 70, 15, false),
('', 9, 4, 80, 10, false);

Create Table ropaTallesColor(
codRTC Int auto_increment,
codRT Int,
idColor Int,
stock Int,
borrado boolean,
Constraint PK_RTC Primary key (codRTC),
Constraint FK_RT Foreign key (codRT) References ropaTalles (codRT),
Constraint FK_Color Foreign key (idColor) References colores(idColor)
)engine=innodb;

Insert Into ropaTallesColor(codRTC, codRT, idColor, stock) Values 
('', 1, 1, 20),
('', 1, 2, 20),
('', 1, 3, 20),
('', 1, 4, 20),
('', 1, 5, 20),
('', 1, 6, 20),
('', 1, 7, 20),
('', 1, 8, 20),
('', 2, 1, 25),
('', 2, 2, 25),
('', 2, 3, 25),
('', 2, 4, 25),
('', 2, 5, 25),
('', 2, 6, 25),
('', 2, 7, 25),
('', 2, 8, 25),
('', 3, 1, 20),
('', 3, 2, 20),
('', 3, 3, 20),
('', 3, 4, 20),
('', 3, 5, 20),
('', 3, 6, 20),
('', 3, 7, 20),
('', 3, 8, 20),
('', 4, 1, 15),
('', 4, 2, 15),
('', 4, 3, 15),
('', 4, 4, 15),
('', 4, 5, 15),
('', 4, 6, 15),
('', 4, 7, 15),
('', 4, 8, 15),
('', 5, 1, 20),
('', 5, 2, 20),
('', 5, 3, 20),
('', 5, 4, 20),
('', 5, 5, 20),
('', 5, 6, 20),
('', 5, 7, 20),
('', 5, 8, 20),
('', 6, 1, 25),
('', 6, 2, 25),
('', 6, 3, 25),
('', 6, 4, 25),
('', 6, 5, 25),
('', 6, 6, 25),
('', 6, 7, 25),
('', 6, 8, 25),
('', 7, 1, 20),
('', 7, 2, 20),
('', 7, 3, 20),
('', 7, 4, 20),
('', 7, 5, 20),
('', 7, 6, 20),
('', 7, 7, 20),
('', 7, 8, 20),
('', 8, 1, 15),
('', 8, 2, 15),
('', 8, 3, 15),
('', 8, 4, 15),
('', 8, 5, 15),
('', 8, 6, 15),
('', 8, 7, 15),
('', 8, 8, 15),
('', 9, 1, 20),
('', 9, 2, 20),
('', 9, 3, 20),
('', 9, 4, 20),
('', 9, 5, 20),
('', 9, 6, 20),
('', 9, 7, 20),
('', 9, 8, 20),
('', 10, 1, 25),
('', 10, 2, 25),
('', 10, 3, 25),
('', 10, 4, 25),
('', 10, 5, 25),
('', 10, 6, 25),
('', 10, 7, 25),
('', 10, 8, 25),
('', 11, 1, 20),
('', 11, 2, 20),
('', 11, 3, 20),
('', 11, 4, 20),
('', 11, 5, 20),
('', 11, 6, 20),
('', 11, 7, 20),
('', 11, 8, 20),
('', 12, 1, 15),
('', 12, 2, 15),
('', 12, 3, 15),
('', 12, 4, 15),
('', 12, 5, 15),
('', 12, 6, 15),
('', 12, 7, 15),
('', 12, 8, 15),
('', 13, 1, 20),
('', 13, 2, 20),
('', 13, 3, 20),
('', 13, 4, 20),
('', 13, 5, 20),
('', 13, 6, 20),
('', 13, 7, 20),
('', 13, 8, 20),
('', 14, 1, 25),
('', 14, 2, 25),
('', 14, 3, 25),
('', 14, 4, 25),
('', 14, 5, 25),
('', 14, 6, 25),
('', 14, 7, 25),
('', 14, 8, 25),
('', 15, 1, 20),
('', 15, 2, 20),
('', 15, 3, 20),
('', 15, 4, 20),
('', 15, 5, 20),
('', 15, 6, 20),
('', 15, 7, 20),
('', 15, 8, 20),
('', 16, 1, 15),
('', 16, 2, 15),
('', 16, 3, 15),
('', 16, 4, 15),
('', 16, 5, 15),
('', 16, 6, 15),
('', 16, 7, 15),
('', 16, 8, 15),
('', 17, 1, 20),
('', 17, 2, 20),
('', 17, 3, 20),
('', 17, 4, 20),
('', 17, 5, 20),
('', 17, 6, 20),
('', 17, 7, 20),
('', 17, 8, 20),
('', 18, 1, 25),
('', 18, 2, 25),
('', 18, 3, 25),
('', 18, 4, 25),
('', 18, 5, 25),
('', 18, 6, 25),
('', 18, 7, 25),
('', 18, 8, 25),
('', 19, 1, 20),
('', 19, 2, 20),
('', 19, 3, 20),
('', 19, 4, 20),
('', 19, 5, 20),
('', 19, 6, 20),
('', 19, 7, 20),
('', 19, 8, 20),
('', 20, 1, 15),
('', 20, 2, 15),
('', 20, 3, 15),
('', 20, 4, 15),
('', 20, 5, 15),
('', 20, 6, 15),
('', 20, 7, 15),
('', 20, 8, 15),
('', 21, 1, 20),
('', 21, 2, 20),
('', 21, 3, 20),
('', 21, 4, 20),
('', 21, 5, 20),
('', 21, 6, 20),
('', 21, 7, 20),
('', 21, 8, 20),
('', 22, 1, 25),
('', 22, 2, 25),
('', 22, 3, 25),
('', 22, 4, 25),
('', 22, 5, 25),
('', 22, 6, 25),
('', 22, 7, 25),
('', 22, 8, 25),
('', 23, 1, 20),
('', 23, 2, 20),
('', 23, 3, 20),
('', 23, 4, 20),
('', 23, 5, 20),
('', 23, 6, 20),
('', 23, 7, 20),
('', 23, 8, 20),
('', 24, 1, 15),
('', 24, 2, 15),
('', 24, 3, 15),
('', 24, 4, 15),
('', 24, 5, 15),
('', 24, 6, 15),
('', 24, 7, 15),
('', 24, 8, 15),
('', 25, 1, 20),
('', 25, 2, 20),
('', 25, 3, 20),
('', 25, 4, 20),
('', 25, 5, 20),
('', 25, 6, 20),
('', 25, 7, 20),
('', 25, 8, 20),
('', 26, 1, 25),
('', 26, 2, 25),
('', 26, 3, 25),
('', 26, 4, 25),
('', 26, 5, 25),
('', 26, 6, 25),
('', 26, 7, 25),
('', 26, 8, 25),
('', 27, 1, 20),
('', 27, 2, 20),
('', 27, 3, 20),
('', 27, 4, 20),
('', 27, 5, 20),
('', 27, 6, 20),
('', 27, 7, 20),
('', 27, 8, 20),
('', 28, 1, 15),
('', 28, 2, 15),
('', 28, 3, 15),
('', 28, 4, 15),
('', 28, 5, 15),
('', 28, 6, 15),
('', 28, 7, 15),
('', 28, 8, 15),
('', 29, 1, 20),
('', 29, 2, 20),
('', 29, 3, 20),
('', 29, 4, 20),
('', 29, 5, 20),
('', 29, 6, 20),
('', 29, 7, 20),
('', 29, 8, 20),
('', 30, 1, 25),
('', 30, 2, 25),
('', 30, 3, 25),
('', 30, 4, 25),
('', 30, 5, 25),
('', 30, 6, 25),
('', 30, 7, 25),
('', 30, 8, 25),
('', 31, 1, 20),
('', 31, 2, 20),
('', 31, 3, 20),
('', 31, 4, 20),
('', 31, 5, 20),
('', 31, 6, 20),
('', 31, 7, 20),
('', 31, 8, 20),
('', 32, 1, 15),
('', 32, 2, 15),
('', 32, 3, 15),
('', 32, 4, 15),
('', 32, 5, 15),
('', 32, 6, 15),
('', 32, 7, 15),
('', 32, 8, 15),
('', 33, 1, 20),
('', 33, 2, 20),
('', 33, 3, 20),
('', 33, 4, 20),
('', 33, 5, 20),
('', 33, 6, 20),
('', 33, 7, 20),
('', 33, 8, 20),
('', 34, 1, 25),
('', 34, 2, 25),
('', 34, 3, 25),
('', 34, 4, 25),
('', 34, 5, 25),
('', 34, 6, 25),
('', 34, 7, 25),
('', 34, 8, 25),
('', 35, 1, 20),
('', 35, 2, 20),
('', 35, 3, 20),
('', 35, 4, 20),
('', 35, 5, 20),
('', 35, 6, 20),
('', 35, 7, 20),
('', 35, 8, 20),
('', 36, 1, 15),
('', 36, 2, 15),
('', 36, 3, 15),
('', 36, 4, 15),
('', 36, 5, 15),
('', 36, 6, 15),
('', 36, 7, 15),
('', 36, 8, 15);

Update ropatallescolor Set borrado=false where stock>=0;

Create Table pedidoRopa(
codPedidoRopa Int  auto_increment,
codRTC Int,
numNotaPedido Int,
cantidad Int,
Constraint PK_pedidoRopa Primary Key (codPedidoRopa),
Constraint FK_rtc Foreign Key (codRTC) References ropaTallesColor(codRTC),
Constraint FK_notaPedido Foreign Key (numNotaPedido) References notaPedido(numNotaPedido)
)engine=innodb;

Insert Into pedidoRopa Values
('', 67, 2, 15),
('', 130, 2, 10),
('', 83, 2, 15),
('', 146, 2, 10),
('', 98, 3, 15),
('', 194, 3, 10),
('', 114, 3, 15),
('', 210, 3, 10);


Create Table PedidoRopaDetalle(
codPRD Int auto_increment,
codPedidoRopa Int,
codDetalle Int,
Constraint PK_PRD Primary Key (codPRD),
Constraint FK_pedidoRopa Foreign Key (codPedidoRopa) References pedidoRopa(codPedidoRopa),
Constraint FK_detalle Foreign Key (codDetalle) References detalle(codDetalle)
)engine=innodb;

Insert Into pedidoRopaDetalle Values
('', 1, 2),
('', 2, 4),
('', 3, 2),
('', 4, 4),
('', 5, 2),
('', 6, 2),
('', 6, 6),
('', 6, 7),
('', 7, 2),
('', 8, 2),
('', 8, 6),
('', 8, 7);

Create Table remitoCliente(
numRemitoC Int auto_increment,
codCliente Int,
recibido Boolean,
fEmision Date,
Constraint PK_remitoC Primary Key (numRemitoC),
Constraint FK_clienteRemito Foreign Key (codCliente) References cliente(codCliente)
)engine=innodb;

Create Table almacen(
codArticulo Int auto_increment,
nombre Varchar(50),
puntoPedido Int,
borrado boolean,
Constraint PK_articulo Primary Key (codArticulo)
)engine=innodb;

INSERT INTO almacen VALUES
('', "Jabon", 6000000, false),
('', "Rollo de Tela Algodon 50m", 20, false);

Create Table almacenColor(
codAlmacenColor int auto_increment,
codArticulo Int,
idColor Int,
stock Int,
Constraint PK_AlmCol Primary Key (codAlmacenColor),
Constraint FK_almCArtic Foreign Key (codArticulo) References almacen (codArticulo),
Constraint FK_almCColor Foreign Key (idColor) References colores (idColor)
)engine=innodb;

Create Table proveedor(
codProveedor Int auto_increment,
nombre Varchar(50),
numCuit Varchar(20),
telefono Varchar(15),
direccion Varchar(70),
mail Varchar(35),
tipoProveedor Varchar(30),
localidad Varchar(50),
borrado boolean,
Constraint PK_proveedor Primary Key (codProveedor)
)engine=innodb;

Insert Into proveedor Values
('', "Rigoberto Perez", "3600034320", "1123-7844", "Av. Rivadavia 4343", "R_Perez@gmail.com", "Bordados", "CABA", false),
('', "Fabricio Gomez" , "3221365420", "4874-1877", "Av. Acoyte 575", "F_Gomez@yahoo.com.ar", "Materiales", "CABA", false),
('', "Rogelio Mamani" , "2977720220", "4372-5527", "Av. Lope de Vega 1752", "R_Mamani@gmail.com", "Bordados", "CABA", false),
('', "Joshua Quispe"  , "3358157220", "4174-8851", "Av. Belgrano 4253", "J_Quispe@outlook.com", "Materiales", "CABA", false);

Create Table facturaProveedor(
codFactura Int auto_increment,
monto Int,
detalle Varchar(100),
pagado Boolean,
Constraint PK_FProveedor Primary key (codFactura)
)engine=innodb;

Create Table remitoProveedor(
numRemitoP Int auto_increment,
codFactura Int,
fecha Date,
detalle Varchar(100),
estado Varchar(50),
Constraint PK_remitoP Primary Key (numRemitoP),
Constraint FK_remitoFactura Foreign key (codFactura) References facturaProveedor (codFactura)
)engine=innodb;

Create Table materiales(
CodRT Int auto_increment,
codArticulo Int,
cantidad Int,
Constraint FK_RopaMateriales Foreign Key (CodRT) References ropaTalles(codRT),
Constraint FK_AlmacenMateriales Foreign Key (codArticulo) References almacen(codArticulo)
)engine=innodb;

Create Table proveedorBordado(
codPB Int auto_increment,
codProveedor Int,
precio Int,
tiempo time,
borrado boolean,
Constraint PK_proveedorDetalle Primary Key (codPB),
Constraint FK_Proveedor Foreign Key (codProveedor) References proveedor(codProveedor)
)engine=innodb;

Insert Into proveedorBordado Values
('', 1, 30, "00:45:00", false),
('', 2, 60, "00:15:00", false);

Create Table pedidoBordado(
codPRD Int,
codPB Int,
fechaSalida Date,
fechaRecibido Date,
Constraint FK_pedDet Foreign Key (codPRD) References pedidoRopaDetalle(codPRD),
Constraint FK_provDet Foreign Key (codPB) References proveedorBordado(codPB)
)engine=innodb;

Insert into pedidoBordado Values
(1, 2, curdate(), null),
(3, 2, curdate(), null);

Create Table proveedorAlmacen(
codProveedor Int,
codArticulo Int,
precio Int,
Constraint FK_PAProveedor Foreign Key (codProveedor) References proveedor(codProveedor),
Constraint FK_PAAlmacen Foreign Key (codArticulo) References almacen(codArticulo)
)engine=innodb;

Create Table usuario(
id Int(11) auto_increment,
nombre Varchar(20),
contraseña Varchar(20),
sector Varchar(20),
Constraint PK_user Primary Key (id)
)engine=innodb;

Insert Into usuario Values
('', "Jefe", "1", "Administracion"),
('', "Contador", "1", "Contaduria"),
('', "Roberto", "1", "Otros");

CREATE TABLE Provincia(
provincia varchar(50),
CONSTRAINT PK_Provincia PRIMARY KEY (provincia)
)ENGINE=INNODB;

INSERT INTO Provincia VALUES
("Gran Buenos Aires"),
("CABA");

CREATE TABLE LocalidadCABA(
localidad varchar(50),
CONSTRAINT PK_LocalidadCABA PRIMARY KEY (localidad)
)ENGINE=INNODB;

INSERT INTO LocalidadCABA VALUES
("Agronomia"),
("Almagro"),
("Balvanera"),
("Barracas"),
("Belgrano"),
("Boedo"),
("Caballito"),
("Chacarita"),
("Coghlan"),
("Colegiales"),
("Constitucion"),
("Flores"),
("Floresta"),
("La Boca"),
("La Paternal"),
("Liniers"),
("Mataderos"),
("Monte Castro"),
("Monserrat"),
("Nueva Pompeya"),
("Nuniez"),
("Palermo"),
("Parque Avellaneda"),
("Parque Chacabuco"),
("Parque Chas"),
("Parque Patricios"),
("Puerto Madero"),
("Recoleta"),
("Retiro"),
("Saavedra"),
("San Cristobal"),
("San Nicolás"),
("San Telmo"),
("Velez Sarsfield"),
("Versalles"),
("Villa Crespo"),
("Villa del Parque"),
("Villa Devoto"),
("Villa General Mitre"),
("Villa Lugano"),
("Villa Luro"),
("Villa Ortuzar"),
("Villa Pueyrredón"),
("Villa Real"),
("Villa Riachuelo"),
("Villa Santa Rita"),
("Villa Soldati"),
("Villa Urquiza");

CREATE TABLE LocalidadGBA(
localidad varchar(50),
CONSTRAINT PK_LocalidadGBA PRIMARY KEY (localidad)
)ENGINE=INNODB;

INSERT INTO LocalidadGBA VALUES
("General San Martin"),
("San Isidro"),
("Vicente Lopez"),
("San Fernando"),
("Tigre"),
("Merlo"),
("Moreno"),
("Moron"),
("Tres de Febrero"),
("General Sarmiento"),
("La Matanza"),
("Almirante Brown"),
("Avellaneda"),
("Berazategui"),
("Esteban Echeverria"),
("Florencio Varela"),
("Lanus"),
("Lomas de Zamora"),
("Quilmes");

CREATE TABLE NP(
id int auto_increment,
idNP int,
codRT int,
codRTC int,
cantidad int,
articulo varchar(255),
preciounitario int,
total int,
detalle boolean,
bordado boolean,
CONSTRAINT PK_NP PRIMARY KEY (id)
)ENGINE=INNODB;

CREATE TABLE NPTOTAL(
id int auto_increment,
idNP int,
totaltotal int,
tiempo time,
CONSTRAINT PK_NPT PRIMARY KEY (id)
)ENGINE=INNODB;

CREATE TABLE NPDETALLE(
id int auto_increment,
idNP int,
codRTC int,
idDetalle int,
CONSTRAINT PK_NPD PRIMARY KEY(id)
)ENGINE=INNODB;

CREATE TABLE CONFECCION(
id int auto_increment,
idNP int,
cantidad int,
articulo varchar(255),
activa boolean,
CONSTRAINT PK_CONF PRIMARY KEY(id)
)ENGINE=INNODB;

CREATE TABLE CIERRECAJA(
id int auto_increment,
fecha date,
monto int,
CONSTRAINT PK_NCC PRIMARY KEY(id)
)ENGINE=INNODB;

INSERT INTO CIERRECAJA VALUES
('', "2017-10-10", 45000),
('', "2017-10-11", 50000);

Create Table ordenCompra(
idOCompra int auto_increment,
numRemitoP int,
codAlmacenColor int,
cantidad int,
Constraint PK_OCompra Primary Key (idOCompra),
Constraint FK_OrdenRemito Foreign Key (numRemitoP) references remitoProveedor (numRemitoP),
Constraint FK_OArtColor Foreign Key (codAlmacenColor) references almacenColor (codAlmacenColor)
)engine=innodb;

Create Table insertOCompra(
idgenerico int auto_increment,
idProveedor int,
idAlmColor int,
cant int,
total int,
Constraint PK_IOCompra Primary Key (idgenerico)
)engine=innodb;